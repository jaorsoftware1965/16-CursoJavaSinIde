// ------------------------------
// Curso de Java desde 0 sin IDE
// Clase 10 String Clase
// ------------------------------
 
// String es una clase, y podemos definir un objeto
// con ella.

// Un objeto puede tener propiedades y métodos
// Una clase puede tener métodos


// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {    
    // Se imprime el titulo de la Clase
    System.out.println("Clase 10 String Clase");

    // Declaramos objetos de String 
    String sNombre   = "Jose Juan";
    String sApellido = "      Perez      ";
    String sEdad     = "33";
    
    System.out.println("Nombre          : "+sNombre);
    System.out.println("Longitud        : "+sNombre.length());
    System.out.println("Nombre May      : "+sNombre.toUpperCase());
    System.out.println("Nombre Min      : "+sNombre.toLowerCase());
    System.out.println("Pos Juan        : "+sNombre.indexOf("Juan"));
    System.out.println("Pos Ultimo J    : "+sNombre.lastIndexOf("J"));
    System.out.println("Nombre Completo : "+sNombre.concat(sApellido));
    System.out.println("Caracter Pos 5  : "+sNombre.charAt(5));
    System.out.println("Contiene Juan   : " + sNombre.contains("Juan"));
    System.out.println("Termina con uan : " + sNombre.endsWith("uan"));
    System.out.println("Inicia  con Jose: " + sNombre.startsWith("Jose"));
    System.out.println("Es igual        : " + sNombre.equals("Alberto"));
    System.out.println("Esta vacia      : " + sNombre.isEmpty());
    System.out.println("Reemplazar Juan : " + sNombre.replace("Juan", "Alberto"));    
    System.out.println("Apellido        : " + sApellido.toString());    
    System.out.println("Elimina Espacios: " + sApellido.trim());
    System.out.println("Edad en valor   : " + String.valueOf(sEdad));
    System.out.println("Subcadena 0,5   : " + sNombre.substring(0,6));    
  }
}