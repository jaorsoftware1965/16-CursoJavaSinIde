// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 47 listaEnlazada
// -------------------------------------------------------

// Una listaEnlazada es una colección de datos similar al
// ArrayList, solo que este colección maneja el concepto
// de listas ligadas; en donde un elemento se encuentra 
// al inicio, otro al final; y
// todos los elementos tienen un elemento siguiente

// Se importa la librería
import java.util.LinkedList;
import java.util.Iterator;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Despliega
        System.out.println("Clase 47 LInkedList");
        
        
       /* Linked List Declaration */
       LinkedList<String> listaEnlazada = new LinkedList<String>();

       // Se añaden elementos
       listaEnlazada.add("Juan");
       listaEnlazada.add("Jose");
       listaEnlazada.add("Pedro");
       listaEnlazada.add("Miriam");
       listaEnlazada.add("Jesus");

       /*Display Linked List Content*/
       System.out.println("Contenido: " +listaEnlazada);

       /*Add First and Last Element*/
       listaEnlazada.addFirst("Adelante");
       listaEnlazada.addLast("Al Final");       
       System.out.println("Contenido: " +listaEnlazada);

       /*This is how to get and set Values*/
       String firstvar = listaEnlazada.get(0);
       System.out.println("Posicion 0: " +firstvar);
       listaEnlazada.set(0, "Cambiado el 0");

       /*Remove first and last element*/
       listaEnlazada.removeFirst();
       listaEnlazada.removeLast();
       System.out.println("Contenido: " +listaEnlazada);
       System.out.println("");

       // recorremos la lista con iterador
       Iterator<String> it = listaEnlazada.iterator();
       while(it.hasNext()) 
       {
           // Imprime el dato
           System.out.println(it.next());
       }
       System.out.println("");

       // recorremos con indice
       for (int indice=0; indice < listaEnlazada.size();indice++)
       {
           String dato = listaEnlazada.get(indice);
           System.out.println(dato);
       }
       System.out.println("");       
    }       
}