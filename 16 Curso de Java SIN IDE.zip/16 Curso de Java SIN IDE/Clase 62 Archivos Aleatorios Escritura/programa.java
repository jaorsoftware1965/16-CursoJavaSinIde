// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 62 Archivos Aleatorios
// -------------------------------------------------------

// Java proporciona una Clase para este propósito llamada 
// RandomAccessFile.
// Con esta clase podemos leer y escribir en cualquier parte 
// del archivoy desplazarnos hacia adelante y hacia atrás del 
// mismo.

// En esta clase veremos como escribir datos en un Archivo 
// Aleatorio; en diversas posiciones del Archivo.
	
// Librerías
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Despliega
        System.out.println("Clase 62 Archivos Aleatorios Escritura");

		// Declaramos un Objeto de la Clase
        RandomAccessFile xFileAleatorio;
        
        // Información a grabar en el archivo
        // Arreglo para almanenar 10 calificaciones
        String strCodigo ="9999";       //  4 Caracteres
        String strNombre ="Juan Perez"; // 10 Caracteres
        String strEdad   ="45";         //  2 Caracteres
        String strPeso   ="79.50";      //  5 Caracteres
        String strActivo =" ";          //  1 Caracter
        String strEOL    ="\n";         //  1 Caracter
                                        // 23 Longitud del Registro

    	        
        // Captura de Excepciones 
        try 
        {
        	        	
        	// Creamos el Archivo de Acceso Directo
        	xFileAleatorio = new RandomAccessFile( "Datos.txt","rw" );
            
        	// Desplegamos su longitud
        	System.out.println("Longitud del Archivo:"+xFileAleatorio.length());
        	System.out.println("Registros del Archivo:"+xFileAleatorio.length()/23);
        	
            // Nos vamos al final del fichero
        	xFileAleatorio.seek(xFileAleatorio.length());
        	        	
		    // Grabamos al Archivo
            xFileAleatorio.writeBytes( strCodigo );
            xFileAleatorio.writeBytes( strNombre );
            xFileAleatorio.writeBytes( strEdad );
            xFileAleatorio.writeBytes( strPeso );
            xFileAleatorio.writeBytes( strActivo );
            xFileAleatorio.writeBytes( strEOL );

			// Modificamos los datos
			strCodigo  = "1234";
			strNombre  = "Maru Perez";
			strEdad    = "34";
			strPeso    = "76.00";
			strActivo  = "*";

			// Grabamos al Archivo
            xFileAleatorio.writeBytes( strCodigo );
            xFileAleatorio.writeBytes( strNombre );
            xFileAleatorio.writeBytes( strEdad );
            xFileAleatorio.writeBytes( strPeso );
            xFileAleatorio.writeBytes( strActivo );
            xFileAleatorio.writeBytes( strEOL );
            
            // Mensaje
            System.out.println("Se han grabado 2 Registros en el Archivo");
                        
            // Cerramos el fichero
            xFileAleatorio.close();
            
		} 
        catch (FileNotFoundException e) 
        {
			e.printStackTrace();
		}
        catch (IOException e) 
		{
			e.printStackTrace();
		}
               
        // Mensaje Final
        System.out.println("Programa Terminado...");       
    }       
}