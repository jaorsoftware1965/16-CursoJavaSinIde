// ---------------------------------
// Curso de Java desde 0 sin IDE
// Clase 20 Arrays o Arreglos
// ---------------------------------

// Un Array o Arreglo es una colección de datos, los cuales se encuentran
// referenciados por un nombre, y a los cuales se accede a cada uno de ellos
// a través de un indice; el cual inicia con el valor de 0
 
// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
    // Mensaje de la Clase
    System.out.println("Clase 20 Arrays");

    // Declaramos un array de Enteros
    int[]    edades = { 23, 34, 56, 78, 60};

    // Declaramos un array de String
    String[] nombres = {"Juan", "Jose", "Maria", "Pedro","Abraham"};

    // Definiendo el Arreglo con tamaños especificos
    double[] pesos     = new double[5];
    float[]  estaturas = new float [5];

    // Asignamos algunos pesos y estaturas
    pesos[0]     = 56.78;
    estaturas[0] =  1.78f;

    pesos[1]     = 50.98;
    estaturas[1] =  1.57f;

    // Longitud
    System.out.println("Longitud de Edades    :"+edades.length);
    System.out.println("Longitud de Nombres   :"+nombres.length);
    System.out.println("Longitud de Pesos     :"+pesos.length);
    System.out.println("Longitud de Estaturas :"+estaturas.length);
    System.out.println();
    
    // Variable indice
    int indice;

    // Desplegamos los arreglos
    for (indice=0; indice < pesos.length; indice++)
    {
        System.out.println("edad    :" + edades[indice]);
        System.out.println("nombre  :" + nombres[indice]);
        System.out.println("peso    :" + pesos[indice]);
        System.out.println("estatura:" + estaturas[indice]);
        System.out.println();
    }

    // Lanza una excepción
    //edades[5]= 34;

  }
}