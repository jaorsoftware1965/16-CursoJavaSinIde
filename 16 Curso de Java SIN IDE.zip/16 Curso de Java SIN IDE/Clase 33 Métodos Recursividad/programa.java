// -------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 33 Métodos Recursividad
// -------------------------------------

// La Recursividad es la capacidad de una función
// de poder llamarse a si misma.

// En una función recursiva siempre tiene que haber
// un punto en el cual la recursividad finalice

// Ejemplo
// Sumatoria de 0 = 0
// Sumatoria de 1 = 1 + 0 = 1
// Sumatoria de 2 = 2 + 1 + 0 = 3 
//                  2 + Sumatoria de 1
// Sumatoria de 3 = 3 + 2 + 1 + 0 = 6
//                = 3 + Sumatoria de 2

// Clase se debe llamar igual que el archivo
public class programa
{  
  // Definimos un método dentro de la Clase
  static int fnSumatoria(int numero)
  {
      // Variable para el resultado
      int resultado;

      // Recursividad
      System.out.println("Sumatoria de :"+numero);    

      // Verifica que sea mayor que cero
      if (numero > 0) 
      {          
          // Ejecuta el Resultado con Recursividad
          resultado = numero + fnSumatoria(numero - 1);          
      } 
      else 
      {
          // retorna 0
          resultado = 0;
      }

      // Retorna el Resultado
      System.out.println("Resultado de Sumatoria de :"+numero+":"+resultado);    
      return resultado;
  }
  
  // Función main que es obligatorio
  public static void main(String args[])
  {          
      // Llamamos al Método que suma enteros
      System.out.println(fnSumatoria(10));
  }   
}