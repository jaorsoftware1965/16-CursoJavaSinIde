// --------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 38 POO Encapsulamiento
// Setter's and Getter's
// --------------------------------------------------

// El Encapsulamiento es una práctica que te permite
// ocultar los datos de origen al usuario de la clase
// y solamente permite manipularlos a través de 
// Métodos que le coloquen datos, o que obtengan datos

// Para poder realiza lo anterior, las propiedades
// deben ser declaradas privadas y se deben de crear
// métodos SET y GET para colocar y obtener datos
// de las variables

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    { 
        // Creamos un objeto de persona con valores default
        personas oPersona0 = new personas("Benito Bodoque",
                                          "Callejon Bote 5",
                                          'M', 4);

        // No podemos acceder a los datos directameente
        // porque son privados
        //System.out.println("Nombre:"+oPersona0.nombre);
        System.out.println("Nombre   :"+oPersona0.getNombre());
        System.out.println("Direccion:"+oPersona0.getDireccion());
        System.out.println("Genero   :"+oPersona0.getGenero());
        System.out.println("Edad     :"+oPersona0.getEdad());
        System.out.println("Indice   :"+oPersona0.getIndice());
        System.out.println("");               

        // Coloca datos con un Setter
        oPersona0.setNombre("Don Gato");
        oPersona0.setDireccion("Bote 1 Callejon Municipal");
        oPersona0.setGenero('H');
        oPersona0.setEdad(10);
        System.out.println("");

        System.out.println("Nombre   :"+oPersona0.getNombre());
        System.out.println("Direccion:"+oPersona0.getDireccion());
        System.out.println("Genero   :"+oPersona0.getGenero());
        System.out.println("Edad     :"+oPersona0.getEdad());
        System.out.println("Indice   :"+oPersona0.getIndice());
        System.out.println("");               

    }   
}