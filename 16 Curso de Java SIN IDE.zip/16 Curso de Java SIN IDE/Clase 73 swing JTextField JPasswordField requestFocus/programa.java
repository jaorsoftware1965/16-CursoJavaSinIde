// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 73 swing JTextField JPasswordField requestFocus
//                getText 
// -------------------------------------------------------

// Librería para swing
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

// Clase se debe llamar igual que el archivo
public class programa extends JFrame implements ActionListener
{   
    // Creamos los objetos
    private JTextField     txtUsuario;
    private JPasswordField txtClave;
    private JLabel         lblUsuario;
    private JLabel         lblClave;
    private JButton        btnAceptar;
    private JButton        btnCancelar;

    // Constructor
    public programa()
    {
        // Establece el Layout
        setLayout(null);

        // Crea los Objetos
        lblUsuario = new JLabel("Usuario:");
        lblUsuario.setBounds(20,10,100,30);
        lblClave   = new JLabel("Clave:");
        lblClave.setBounds(20,50,100,30);

        txtUsuario = new JTextField();
        txtUsuario.setBounds(200,10,100,20);
        txtClave   = new JPasswordField();
        txtClave.setBounds(200,50,100,20);
        
        btnAceptar = new JButton("Aceptar");
        btnAceptar.setBounds(20,100,100,30);
        btnCancelar = new JButton("Cancelar");
        btnCancelar.setBounds(200,100,100,30);

        // Añade los Objetos
        add(lblUsuario);    
        add(lblClave);    
        add(txtUsuario);    
        add(txtClave);                
        add(btnAceptar);
        add(btnCancelar);

        // Eventos
        btnAceptar.addActionListener(this);  
        btnCancelar.addActionListener(this); 
        txtUsuario.addActionListener(this); 
        txtClave.addActionListener(this); 
    }

    public void actionPerformed(ActionEvent e) 
    {
        if (e.getSource()==btnAceptar) 
        {
            // Obtiene los datos de Usuario y Clave
            String sUsuario=txtUsuario.getText();
            String sClave = String.valueOf(txtClave.getPassword());
            
            // Despliega el Mensaje
            JOptionPane.showMessageDialog(this, 
                                          "Los Datos Capturados son:\n" +
                                          "Usuario:"+sUsuario+"\n"+
                                          "Clave:"+sClave, 
                                          "Java desde 0 sin Ide", 
                                          JOptionPane.OK_OPTION);            
            
        }
        else
        if (e.getSource()==btnCancelar) 
        {
            // Finaliza la Ventana
            this.dispose();
        }
        else
        if (e.getSource()==txtUsuario) 
        {
            // Pasa el Control del Foco a la Clave
            txtClave.requestFocus();
        }
        else
        if (e.getSource()==txtClave) 
        {
            // Pasa el Control del Foco a la Clave
            btnAceptar.requestFocus();
        }
    }
                
    // Función main que es obligatorio
    public static void main(String args[])
    {   
        // Crea la Ventana
        programa ventana = new programa();
        ventana.setTitle("Clase 73 - swing JTextField JPasswordField requestFocus");
        ventana.setBounds(0,0,340,180);
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);        
        ventana.setLocationRelativeTo(null);
        ventana.setResizable(false);
    }       
}