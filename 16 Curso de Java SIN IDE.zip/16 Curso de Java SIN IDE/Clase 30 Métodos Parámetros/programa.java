// ---------------------------------
// Curso de Java desde 0 sin IDE
// Clase 30 Métodos Parámetros
// ---------------------------------

// Los parámetros son datos que necesita un método
// para funcionar.
// Cuando se define un Método, se indica que parámetros
// utilizará, y cuando la función es llamada, debe de
// incluir estos parámetros

// Clase se debe llamar igual que el archivo
public class programa
{
  // Definimos un método dentro de la Clase
  static void fnMensaje(String mensaje)
  {
      // Desplegamos el Mensaje
      System.out.println(mensaje);
  }

  static void fnTablaMultiplicar(int tabla, 
                                 int inicio,
                                 int fin )
  {
    // Mensaje
    System.out.println("Tabla del:" + tabla);
    
    // Ciclo para imprimir la tabla          
    for (int i = inicio; i <= fin; i++) 
    {
         System.out.println(tabla+" X "+ i + " = "+tabla * i);
    }
  }
  
  // Función main que es obligatorio
  public static void main(String args[])
  {    
      // Llamamos al Método de Main
      fnMensaje("Bienvenido al Sistema");

      // Llamamos al Segundo Método
      fnTablaMultiplicar(7,1,10);
  }
}