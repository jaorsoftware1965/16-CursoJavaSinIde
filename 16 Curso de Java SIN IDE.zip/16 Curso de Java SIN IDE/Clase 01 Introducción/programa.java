// ---------------------
// Curso de Java sin IDE
// Clase 01 Hola Mundo
// ---------------------
 
// Clase se debe llamar igual que el archivo
public class programa
{
    // Función main que es obligatorio
    public static void main(String args[])
    {
       // Desplegamos un Mensaje en la Pantalla
       System.out.println("Hola mundo");
    }
}