// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 58 Entrada de Datos por el Teclado
// -------------------------------------------------------

// Para realizar entrada de datos por el teclado, se utiliza
// la Clase Scanner

// Métodos disponibles de la clase
// nextBoolean()	   Reads a boolean value from the user
// nextByte()	      Reads a byte value from the user
// nextDouble()	   Reads a double value from the user
// nextFloat()	      Reads a float value from the user
// nextInt()	      Reads a int value from the user
// nextLine()	      Reads a String value from the user
// nextLong()	      Reads a long value from the user
// nextShort()	      Reads a short value from the user

// Importa las funciones
import java.util.Scanner;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Despliega
        System.out.println("Clase 58 Entrada de Datos");

        // Creamos un objeto de la Clase
        Scanner oEntrada = new Scanner(System.in);
        
        // Ciclo para controla la repetición
        while (true) 
        {
           // Mensaje de Soliccitud
           System.out.println("Capture datos de la Persona");
           System.out.println("Nombre:");
           String nombre = oEntrada.nextLine(); 

           // Si el nombre es vacío termina la captura
           if (nombre.length()==0)
              // Sale del Ciclo
              break;

           System.out.println("Edad:");
           Integer edad  = oEntrada.nextInt(); 

           System.out.println("Estatura:");
           Float   estatura  = oEntrada.nextFloat(); 

           System.out.println("Casado:");
           Boolean   casado  = oEntrada.nextBoolean(); 

           System.out.println("Los datos capturados son:");
           System.out.println("Nombre   :"+nombre);
           System.out.println("Edad     :"+edad);           
           System.out.println("Estatura :"+estatura);
           System.out.println("Casado   :"+casado+"\n");
           
           // Limpia el Buffer
           oEntrada.nextLine();          
        }
        
        // Cerramos el Objeto
        oEntrada.close();
        
        // Mensaje Final
        System.out.println("Programa Terminado...");       
    }       
}