// --------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase Cuadrado
// --------------------------------------------------

// Defino la clase abstracta
public class Cuadrado extends Figura
{
    // Propiedad Color Privada
    private double lado;

    // Constructor
    public Cuadrado(String color, double lado)
    {
        // llama al super
        super(color);

        // Asigna el lado
        this.lado = lado;
    }

    // Define el metodo abstracto 
    public double calcularArea()
    {
        return lado * lado;
    }
}