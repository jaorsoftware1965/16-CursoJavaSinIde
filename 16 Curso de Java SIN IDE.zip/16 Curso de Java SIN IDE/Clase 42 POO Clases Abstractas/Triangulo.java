// --------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase Triangulo
// --------------------------------------------------

// Defino la clase abstracta
public class Triangulo extends Figura
{
    // Propiedad Color Privada
    private double base;
    private double altura;

    // Constructor
    public Triangulo(String color, double base, double altura)
    {
        // Constructor super
        super(color);
        
        // Base y altura
        this.base = base;
        this.altura = altura;
    }

    // Define el Metodo abstracto heredado
    public double calcularArea()
    {
         // Calcula el area y lo devuelve
         return (base * altura) / 2;
    }
}