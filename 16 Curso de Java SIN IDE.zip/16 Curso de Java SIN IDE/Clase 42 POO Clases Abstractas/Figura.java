// --------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase Figura
// --------------------------------------------------

// Defino la clase abstracta
public abstract class Figura
{
    // Propiedad Color Privada
    private String color;

    // Constructor
    public Figura(String color)
    {
        // Asigna el Color
        this.color = color;
    }

    // Obtiene el Color
    public String getColor()
    {
        // retorna el color
        return color;
    }

    // Define el Metodo Abstracto que calcular el area
    public abstract double calcularArea();

}