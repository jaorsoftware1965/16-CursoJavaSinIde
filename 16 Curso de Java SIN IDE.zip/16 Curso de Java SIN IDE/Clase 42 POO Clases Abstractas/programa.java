// --------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 42 POO Abstracción
// --------------------------------------------------

// La abstracción es la forma de ocultar una clase al
// usuario programador y obligar a construir metodos 
// en subclases

// La palabra abstract hace inaccesible a la clase al
// usuario programador y solo la deja accesible para 
// las subclases a través de la herencia

// Los metodos que se definan abstractos, no tienen
// código y es obligatorio que se definan en las
// subclase

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // No podemos crear objeto de Figura
        // error: Figura is abstract; cannot be instantiated
        // Figura x = new Figura("azul");

        // creamos un objeto del Cuadrado
        Cuadrado cuadrado = new Cuadrado("rojo",2.5);
        System.out.printf("El Color del Cuadrado es: %s\n", cuadrado.getColor());
        System.out.printf("El Area  del Cuadrado es: %f\n\n", cuadrado.calcularArea());

        // creamos un objeto del Triangulo
        Triangulo triangulo = new Triangulo("azul",2.5,3.45);
        System.out.printf("El Color del Triangulo es: %s\n", triangulo.getColor());
        System.out.printf("El Area  del Triangulo es: %f\n", triangulo.calcularArea());    
    }   
}