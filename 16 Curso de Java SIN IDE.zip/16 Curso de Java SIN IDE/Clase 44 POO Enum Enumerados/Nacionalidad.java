// --------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase FacturaTipo
// --------------------------------------------------

// Defino la clase que implementa
public enum Nacionalidad
{
    MEXICANO,
    EXTRANJERO,
    NATURALIZADO
}