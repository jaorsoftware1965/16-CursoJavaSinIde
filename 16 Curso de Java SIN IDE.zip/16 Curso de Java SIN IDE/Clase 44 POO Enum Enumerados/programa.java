// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 44 POO Enum
// -------------------------------------------------------

// Los Enum; enumerados son un tipo de clase que permite
// establecer un grupo de constantes; es decir; variables
// finales

// Se sugiere que estos valores deben estar en MAYUSCULAS
// como se indicó en el tema correspondiente

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {

        // creamos un objeto de  Persona
        Persona persona = new Persona("Don Gato",
                                      "El Callejon",
                                      'M',
                                      7,
                                      Persona.EstadoCivil.SOLTERO,
                                      Nacionalidad.MEXICANO);

        // Imprime la Información
        persona.fnImprimeInformacion();       
        
        // Compara Nacionalidad
        if (persona.getNacionalidad()==Nacionalidad.MEXICANO)
        {
            // Despliega
            System.out.println("MEXICANO");
        }

        // Compara el Estado Civil
        if (persona.getEstado()==Persona.EstadoCivil.SOLTERO)
        {
            // Despliega
            System.out.println("Soltero");
        }        
    }   
}