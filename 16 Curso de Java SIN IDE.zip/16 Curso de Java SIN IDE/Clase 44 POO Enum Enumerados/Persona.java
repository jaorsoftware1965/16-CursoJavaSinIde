// --------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase Persona
// --------------------------------------------------

// Defino la clase que implementa
public class Persona
{
     // Contador de Personas
     private static int contador = 0;

     // Estado Civil
     enum EstadoCivil 
     {
        SOLTERO,
        UNIONLIBRE,
        CASADO,
        DIVORCIADO,
        VIUDO
     }
    
     // Propiedades de la clase
     private String       nombre     = "Juan Perez";
     private String       direccion  = "Conocido";
     private char         genero     = 'M';
     private int          edad       = 20;
     private EstadoCivil  estado;
     private Nacionalidad nacionalidad;
     private int          indice;                
     
     // Constructor
     Persona(String       nombre, 
             String       direccion, 
             char         genero, 
             int          edad,
             EstadoCivil  estado,
             Nacionalidad nacionalidad)
     {
        // Lo asigna
        this.nombre       = nombre;
        this.direccion    = direccion;
        this.genero       = genero;
        this.edad         = edad;
        this.estado       = estado;
        this.nacionalidad = nacionalidad;
         
         // Incrementamos el Contador
         contador++;
         indice = contador;
     }
 
     // Métodos Setter's
     void setNombre(String nombre)
     {
         if (nombre.length()>0)
            // Coloca el dato
            this.nombre = nombre;
         else   
            System.out.println("El Nombre no fue modificado");      
     }
     
     void setDireccion(String direccion)
     {
         if (direccion.length()>0)
            // Coloca el dato
            this.direccion = direccion;
         else
            System.out.println("La Direccion no fue modificada");      
     }
 
     void setGenero(char genero)
     {
         if (genero=='F' || genero == 'M')           
            // Coloca el dato
            this.genero = genero;
         else
            System.out.println("El Genero no fue modificado");   
     }
 
     void setEdad(int edad)
     {
         if (edad>=18)
            // Coloca el dato
            this.edad = edad;
         else
            System.out.println("La Edad no fue modificada");   
     }

     void setEstadoCivil(EstadoCivil estado)
     {
          this.estado = estado;
     }

     void setNacionalidad(Nacionalidad nacionalidad)
     {
          this.nacionalidad = nacionalidad;
     }

 
     // Métodos getters
     String getNombre()
     {
         // retorna el dato
         return nombre;
     }
 
     String getDireccion()
     {
         // retorna el dato
         return direccion;
     }
     
     char getGenero()
     {
         // retorna el dato
         return genero;
     }
 
     int getEdad()
     {
         // retorna el dato
         return edad;
     }
 
     int getIndice()
     {
         // retorna el dato
         return indice;
     }
     
     int getContador()
     {
         // retorna el dato
         return contador;
     }

     EstadoCivil getEstado()
     {
         // retorna el dato
         return estado;
     }

     Nacionalidad getNacionalidad()
     {
         // retorna el dato
         return nacionalidad;
     }
 
     // Métodos
     public void fnImprimeInformacion()
     {
         System.out.println("Informacion de Persona");
         System.out.println("Nombre       :"+nombre);
         System.out.println("Direccion    :"+direccion);
         System.out.println("Edad         :"+edad);
         System.out.println("Genero       :"+genero);
         System.out.println("Edo Civil    :"+estado);
         System.out.println("Nacionalidad :"+nacionalidad);
         System.out.println("Indice       :"+indice);
         System.out.println("Contador     :"+contador+"\n");
     }
}