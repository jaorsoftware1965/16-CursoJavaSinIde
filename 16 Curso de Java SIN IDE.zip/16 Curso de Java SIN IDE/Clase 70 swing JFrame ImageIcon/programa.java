// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 70 Swing JFrame ImageIcon
// -------------------------------------------------------

// Librería para swing
import javax.swing.JFrame;
import javax.swing.ImageIcon;

// Clase se debe llamar igual que el archivo
public class programa 
{           
    // Función main que es obligatorio
    public static void main(String args[])
    {   
        // Creamos un objeto JFrame             
        JFrame formulario = new JFrame();

        // COlocamos caracteristica
        formulario.setTitle("Clase 70 - Swing JFrame ImageIcon");
        formulario.setBounds(10,10,600,300);
        formulario.setVisible(true);
        formulario.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        
        // Centramos la ventana
        formulario.setLocationRelativeTo(null);
        formulario.setResizable(false);

        // Colocamos Icono
        ImageIcon icono = new ImageIcon("icono.png");
        formulario.setIconImage(icono.getImage());        
    }       
}