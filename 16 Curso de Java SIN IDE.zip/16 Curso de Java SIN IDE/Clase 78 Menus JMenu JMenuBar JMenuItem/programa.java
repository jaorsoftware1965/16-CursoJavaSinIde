// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 78 swing Menus JMenu JMenuBar JMenuItem
// -------------------------------------------------------

// Librerias
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;

public class programa extends JFrame implements ActionListener
{
    // Objetos
    private JMenuBar  mnbPrincipal;
    
    private JMenu     mnuSistema;
    private JMenuItem mniAcceso;
    private JMenuItem mniConfiguracion;
    private JMenuItem mniSalir;

    private JMenu     mnuCatalogos;
    private JMenuItem mniProductos;
    private JMenuItem mniProveedores;
    private JMenuItem mniClientes;
    
    // Constructor
    public programa() 
    {
        // Establece el Layout
        setLayout(null);

        // Carga un Icono
        ImageIcon icono = new ImageIcon("icono.png");

        // Barra de Menu
        mnbPrincipal = new JMenuBar();
        setJMenuBar(mnbPrincipal);

        // Crea el Menu Sistema        
        mnuSistema = new JMenu("Sistema");
        mnuSistema.setIcon(icono);
        mnbPrincipal.add(mnuSistema);

        // Crea las Opciones        
        mniAcceso=new JMenuItem("Acceso",icono);        
        mnuSistema.add(mniAcceso);

        mniConfiguracion=new JMenuItem("Configuracion");        
        mnuSistema.add(mniConfiguracion);

        // Añade un Separador
        mnuSistema.addSeparator();

        mniSalir = new JMenuItem("Salir");        
        mnuSistema.add(mniSalir);    

        // Crea el Menu Catalogos
        mnuCatalogos = new JMenu("Catalogos");
        mnbPrincipal.add(mnuCatalogos);

        // Crea las Opciones
        mniProductos=new JMenuItem("Productos");        
        mnuCatalogos.add(mniProductos);
        mniProveedores=new JMenuItem("Proveedores");        
        mnuCatalogos.add(mniProveedores);
        mniClientes=new JMenuItem("Clientes");        
        mnuCatalogos.add(mniClientes);    

        // Eventos
        mniAcceso.addActionListener(this);
        mniConfiguracion.addActionListener(this);
        mniSalir.addActionListener(this);
        mniProductos.addActionListener(this);
        mniProveedores.addActionListener(this);
        mniClientes.addActionListener(this);    
    }
    
    public void actionPerformed(ActionEvent e) 
    {
        String seleccionado = e.getActionCommand();
        // Despliega el Nombre
        JOptionPane.showMessageDialog(this, 
                                      "Seleccionaste:\n" +
                                      seleccionado,                                               
                                      "Java desde 0 sin Ide", 
                                      JOptionPane.OK_OPTION);            
        
        if (e.getSource()==mniSalir) {
            System.exit(0);
        }        
    }
    
    public static void main(String[] ar) 
    {
        // Crea la Ventana
        programa ventana = new programa();
        ventana.setTitle("Clase 78 - JMenu JMenuBar JMenuItem");
        ventana.setBounds(0,0,480,270);
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);        
        ventana.setLocationRelativeTo(null);
        ventana.setResizable(false);
    }    
}