// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 79 SubMenu new Color setsize getContentPane
// -------------------------------------------------------

// Librerias
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import java.awt.Color;


// Clase Principal
public class programa extends JFrame implements ActionListener
{
    // Objetos
    private JMenuBar  mnbPrincipal;
    private JMenu     mnuVentana;
    private JMenu     mnuDimensiones;
    private JMenu     mnuColor;
    private JMenuItem mniDimension640x480;
    private JMenuItem mniDimension1024x768;
    private JMenuItem mniColorRojo;
    private JMenuItem mniColorVerde;
    private JMenuItem mniColorAzul;

    // Constructor
    public programa() 
    {
        // Establece el Layout
        setLayout(null);

        // Barra de Menu Principal
        mnbPrincipal=new JMenuBar();
        setJMenuBar(mnbPrincipal);

        // Menus
        mnuVentana = new JMenu("Ventana");
        mnbPrincipal.add(mnuVentana);
        
        mnuDimensiones = new JMenu("Dimensiones");
        mnuVentana.add(mnuDimensiones);
        mnuColor = new JMenu("Color");
        mnuVentana.add(mnuColor);

        // Items Menu Ventana
        mniDimension640x480 = new JMenuItem("640*480");
        mnuDimensiones.add(mniDimension640x480);
        mniDimension1024x768 = new JMenuItem("1024*768");
        mnuDimensiones.add(mniDimension1024x768);        

        // Items Menu Color
        mniColorRojo = new JMenuItem("Rojo");
        mnuColor.add(mniColorRojo);        
        mniColorVerde = new JMenuItem("Verde");
        mnuColor.add(mniColorVerde);
        mniColorAzul = new JMenuItem("Azul");
        mnuColor.add(mniColorAzul);
        
        // Eventos
        mniDimension640x480.addActionListener(this);
        mniDimension1024x768.addActionListener(this);
        mniColorRojo.addActionListener(this);
        mniColorVerde.addActionListener(this);
        mniColorAzul.addActionListener(this);

    }
    
    public void actionPerformed(ActionEvent e) 
    {
        // Verifica Item Selecciona 
        if (e.getSource()==mniDimension640x480) 
        {
            // Establece el Tamaño de la Ventana
            setSize(640,480);
            setLocationRelativeTo(null);
        }

        if (e.getSource()==mniDimension1024x768)
        {
            // Establece el Tamaño de la Ventana
            setSize(1024,768);
            setLocationRelativeTo(null);
        }

        if (e.getSource()==mniColorRojo) 
        {
            // Establece el Color                     R  G B
            getContentPane().setBackground(new Color(255,0,0));
        }
        if (e.getSource()==mniColorVerde) 
        {
            // Establece el Color                    R  G  B 
            getContentPane().setBackground(new Color(0,255,0));
        }
        if (e.getSource()==mniColorAzul) 
        {
            // Establece el Color                    R G  B 
            getContentPane().setBackground(new Color(0,0,255));
        }
    }
    
    public static void main(String[] ar) 
    {
        // Crea la Ventana
        programa ventana = new programa();
        ventana.setTitle("Clase 79 - SubMenu");
        ventana.setBounds(0,0,480,270);
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);        
        ventana.setLocationRelativeTo(null);
        ventana.setResizable(false);
    }    
}