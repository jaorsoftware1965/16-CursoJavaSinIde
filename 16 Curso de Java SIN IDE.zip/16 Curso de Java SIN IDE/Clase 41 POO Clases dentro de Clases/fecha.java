// -----------------------------------------
// Curso de Java desde 0 sin IDE
// Archivo utilizado en Clase programa
// -----------------------------------------
public class fecha 
{
    // Definimos una clase dentro
    public class Dia 
    {
        // Propiedades
        private String dia;
        private String mes;
        private String anio;

        // Constructor
        Dia (String dia, String mes, String anio)
        {
            // Coloca los datos
            this.dia = dia;
            this.mes = mes;
            this.anio = anio;
        }

        // Obtiene la fechaHora
        public String get() 
        {
            // Retona la Fecha
            return dia+":"+mes+":"+anio;
        }
    }    
    
    public class Hora
    {
        // Propiedades
        private String hora;
        private String minuto;
        private String segundo;
        
        // Constructor
        Hora (String hora, String minuto, String segundo)
        {
             // Coloca los datos
             this.hora    = hora;
             this.minuto  = minuto;
             this.segundo = segundo;
        }

        // Obtiene la Hora
        public String get() 
        {
            // Retona la Hora
            return hora+":"+minuto+":"+segundo;
        }
    }

    // Declaro propiedades
    private Dia  dia;
    private Hora hora;

    // Constructor vacio
    fecha (String dia,  String mes,    String anio,
           String hora, String minuto, String segundo)
    {
          // Crea los objetos en base a los paramertros
          this.dia  = new Dia (dia, mes,anio);
          this.hora = new Hora(hora,minuto,segundo);
    }

    // Desplegamos la fecha
    public String get()
    {
        return dia.get()+" "+hora.get();        
    }
}

