// --------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 41 POO Clases dentro de Clases Inner Class
// --------------------------------------------------

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    { 
        // Creamos un objeto de fecha
        fecha oFecha = new fecha("01","01","2021","14","20","03");

        // Desplegamos la Fecha
        System.out.println("Fecha:"+oFecha.get());

        // Creamnos un objeto de Dia desde la clase Fecha
        fecha.Dia oDia = oFecha.new Dia("01","11","2020");

        // Desplegamos el dia
        System.out.println("Dia:"+oDia.get());

        // Creamnos un objeto de Dia desde la clase Fecha
        fecha.Hora oHora = oFecha.new Hora("14","10","30");

        // Desplegamos el dia
        System.out.println("Hora:"+oHora.get());
    }   
}