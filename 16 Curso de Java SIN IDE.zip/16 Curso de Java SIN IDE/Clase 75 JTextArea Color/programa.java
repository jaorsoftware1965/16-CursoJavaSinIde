// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 75 swing JTextArea Color
// -------------------------------------------------------

// Librería para swing
import javax.swing.JFrame;
import javax.swing.JTextArea;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

// Clase se debe llamar igual que el archivo
public class programa extends JFrame implements KeyListener
{   
    // Creamos los objetos
    private JTextArea txaEditor;
    
    // Constructor
    public programa()
    {
        // Establece el Layout
        setLayout(null);

        // Crea los Objetos
        txaEditor = new JTextArea("Texto Inicial\n");
        txaEditor.setBounds(10,10,560,340);  
        txaEditor.setText(txaEditor.getText()+"Esto lo acabo de poner");      
        
        // Create a new Color
        Color color = Color.cyan;
        txaEditor.setBackground(color);

        // Añade los Objetos
        add(txaEditor);    
        txaEditor.addKeyListener(this);
    }

    
    // Implementando los métodos obligatorios de KeyListener
    @Override
    public void keyPressed(KeyEvent e) 
    {
        // Despliega el Mensaje
        System.out.println("KeyPressed:"+e.getKeyCode());            
    }
 
    public void keyReleased(KeyEvent e) 
    {
        System.out.println("KeyReleased:"+e.getKeyCode());
        System.out.println("Longitud:"+txaEditor.getText().length());        
    }
 
    public void keyTyped(KeyEvent e) 
    {
        System.out.println("KeyTyped:"+e.getKeyCode()+"-"+e.getKeyChar());                 
    }

                
    // Función main que es obligatorio
    public static void main(String args[])
    {   
        // Crea la Ventana
        programa ventana = new programa();
        ventana.setTitle("Clase 75 - JTextArea Color");
        ventana.setBounds(0,0,600,400);
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);        
        ventana.setLocationRelativeTo(null);
        ventana.setResizable(false);
    }       
}