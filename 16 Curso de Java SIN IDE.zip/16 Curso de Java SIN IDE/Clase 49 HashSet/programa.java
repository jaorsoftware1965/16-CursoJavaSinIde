// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 49 HashSet
// -------------------------------------------------------

// Un HashSet es una colección de datos que son unicos;
// es decir que no se puede repetir


// Se importa la librería
import java.util.HashSet; 
import java.util.Iterator;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
       // Despliega
       System.out.println("Clase 49 HashSet");
       
       // Obtiene el valor del dato
       String dato;
       
       /// HashmSet
       HashSet<String> personas = new HashSet<String>();

       // Agrego valores
       personas.add("Juan");
       if (personas.add("Juan"))
          System.out.println("Se añade Juan");
       else
          System.out.println("Juan ya  existe");
       personas.add("Jose");
       personas.add("Maria");

       // Imprime el objeto
       System.out.println(personas);

       // Verifica si contiene
       if (personas.contains("Juan"))
          System.out.println("Si contiene Juan");
       else
          System.out.println("No contiene Juan");   
       
       if (personas.contains("Jesus"))
          System.out.println("Si contiene Jesus");
       else
          System.out.println("No contiene Jesus");   
       
       if (personas.remove("Juan"))   
          System.out.println("Juan Si fue eliminado");   
       else
          System.out.println("Juan No fue eliminado");      
       
        // Elimina a todos los elementos
        personas.clear();

        // Imprime el Objeto
        System.out.println(personas);

        if (personas.isEmpty())
           System.out.println("El Objeto si esta vacio");
        else
           System.out.println("El Objeto no esta vacio");

        personas.add("Juan");
        personas.add("Jose");
        personas.add("Maria");

        // recorremos con iterador
        Iterator<String> it = personas.iterator();
        
        // Ciclo
        while(it.hasNext())
        {
            // recorre los elementos
            System.out.println(it.next());
        }

        // recorrido con foreach
        for (String valor: personas)
        {
           System.out.println("Valor:"+valor);
        }
      
        // Recorremos los datos (Version 8 usando expresion lambda)
        personas.forEach((val) 
                          -> System.out.println("Dato: " + val)
                        );    
              
    }       
}