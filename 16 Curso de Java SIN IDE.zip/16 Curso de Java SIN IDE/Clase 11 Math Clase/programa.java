// ---------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 11 Funciones Matemáticas con Math
// ---------------------------------------

// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {   
    int x = 10;
    int z = 6; 
    System.out.println("Max    : " + Math.max(10,2));
    System.out.println("Min    : " + Math.min(x,z));
    System.out.println("Raiz   : " + Math.sqrt(64));
    System.out.println("Abs    : " + Math.abs(-10));
    System.out.println("Pow    : " + Math.pow(4,2));
    System.out.println("Round  : " + Math.round(10.5));
    System.out.println("Round  : " + Math.round(10.6));
    System.out.println("Random : " + Math.random());
    System.out.println("Random : " + Math.random()*101);
    System.out.println();
    System.out.println("Random : " + (int)(Math.random()*101));
    System.out.println("Random : " + (int)(Math.random()*101));
    System.out.println("Random : " + (int)(Math.random()*101)); 
    System.out.println("Random : " + (int)(Math.random()*101));
    System.out.println("Random : " + (int)(Math.random()*101));
  }
}