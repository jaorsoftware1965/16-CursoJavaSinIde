// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 66 Archivos Aleatorios con Datos Primitivos
// -------------------------------------------------------
	
// Librerías
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Ajusta un String
    static String fnStrAjusta(String cadena, 
                              int    longitud,
                              char   caracter)
    {
        // Obtiene la cadena inicial
        String resultado = cadena;

        // Verifica la longitud
        if (resultado.length()>longitud)
        {
           // Recorta la Cadena
           resultado = resultado.substring(0,longitud);
        }
        else
        {
           // Ciclo para ajustar la cadena
           while (resultado.length()<longitud)
                 resultado = resultado + caracter;  
        }

        // Retorna cadena
        return resultado;
    }

    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Despliega
        System.out.println("Clase 66 Archivos Aleatorios Con Datos Primitivos");

        try 
        {
            // Declaramos un Objeto de la Clase
            RandomAccessFile xFileAleatorio;

            // Creamos el Archivo de Acceso Directo
            xFileAleatorio = new RandomAccessFile( "articulos.txt","rw" );
            //xFileAleatorio.seek(xFileAleatorio.length());

            // Desplegamos su longitud
            System.out.println("Longitud del Archivo:"+xFileAleatorio.length());
            System.out.println("Registros del Archivo:"+xFileAleatorio.length()/110);
            
            // Información a grabar en el archivo
            int    ide;        //     4
            String clave;      // 10(20)
            String nombre;     // 30(60)
            String medida;     //  5(10)
            int    existencia; //     4       
            float  costo;      //     4
            double precio;     //     8
                               // ------
                               //   110
                        
            // Creamos un objeto de la Clase Entrada
            Scanner oEntrada = new Scanner(System.in); 

            // Mensaje de Grabar
            System.out.println("Grabando Articulos\n");

            // Ciclo para grabar datos
            while(true)
            {
                // Solicita identificador
                System.out.print("Ide (0-Salir):");
                ide = oEntrada.nextInt();
                oEntrada.nextLine();

                // Verifica si es 0
                if (ide == 0)
                {
                    // Deja un espacio
                    System.out.println("");

                    // Salir
                    break;
                }
                else
                {
                    // Solicita Clave
                    System.out.print("Clave:");
                    clave = oEntrada.nextLine();
                    clave = fnStrAjusta(clave, 10, ' ');
                    
                    // Solicita Nombre
                    System.out.print("Nombre:");
                    nombre = oEntrada.nextLine();
                    nombre = fnStrAjusta(nombre, 30, ' ');

                    // Solicita Medida
                    System.out.print("Medida:");
                    medida = oEntrada.nextLine();
                    medida = fnStrAjusta(medida, 5, ' ');

                    // Solicita Existencia
                    System.out.print("Existencia:");
                    existencia = oEntrada.nextInt();

                    // Solicita Costo
                    System.out.print("Costo:");
                    costo = oEntrada.nextFloat();

                    // Solicita Precio
                    System.out.print("Precio:");
                    precio = oEntrada.nextDouble();

                                    
                    // Despliega los datos a grabar
                    System.out.println("Los datos a grabar son:");
                    System.out.println("Ide        :"+ide);
                    System.out.println("Clave      :"+clave);
                    System.out.println("Nombre     :"+nombre);
                    System.out.println("Medida     :"+medida);
                    System.out.println("Existencia :"+existencia);
                    System.out.println("Costo      :"+costo);
                    System.out.println("Precio     :"+precio);                

                    // Se Graba al Archivo
                    xFileAleatorio.writeInt(ide);                    
                    xFileAleatorio.writeChars(clave);
                    xFileAleatorio.writeChars(nombre);
                    xFileAleatorio.writeChars(medida);
                    xFileAleatorio.writeInt(existencia);
                    xFileAleatorio.writeFloat(costo);
                    xFileAleatorio.writeDouble(precio);
                
                }
            }

            // Ciclo para leer datos
            while(true)
            {
                // Solicita el Registro a Leer
                System.out.print("Registro a Leer (0-Salir):");
                int iRegistro = oEntrada.nextInt();
                oEntrada.nextLine();

                // Verifica si es 0
                if (iRegistro == 0)
                {
                    // Salir
                    break;
                }
                else
                {
                    // Nos Movemos al Registro
                    xFileAleatorio.seek((iRegistro-1) * 110);

                    // Leemos los datos
                    ide = xFileAleatorio.readInt();
                    
                    // Inicializa Clave
                    clave = "";

                    // Lee los 10 caracteres de la Clave
                    for (int i=0;i<10;i++)
                    {
                        // Declara y lee un caracter
                        char caracter =  xFileAleatorio.readChar();
                        // Lo agrega a la Clave
                        clave = clave + caracter;
                    }

                    // Inicializa Nombre
                    nombre = "";

                    // Lee los 30 caracteres del Nombre
                    for (int i=0;i<30;i++)
                    {
                        // Declara y lee un caracter
                        char caracter =  xFileAleatorio.readChar();
                        // Lo agrega a la Clave
                        nombre = nombre + caracter;
                    }

                    // Inicializa Medida
                    medida = "";

                    // Lee los 5 caracteres de la Medida
                    for (int i=0;i<5;i++)
                    {
                        // Declara y lee un caracter
                        char caracter =  xFileAleatorio.readChar();
                        // Lo agrega a la Clave
                        medida = medida + caracter;
                    }

                    // Lee la existencia
                    existencia = xFileAleatorio.readInt();

                    // Lee el Costo
                    costo = xFileAleatorio.readFloat();

                    // Lee el precio
                    precio = xFileAleatorio.readDouble();

                    // Despliega los datos 
                    System.out.println("Los Datos leidos son:");
                    System.out.println("Ide        :"+ide);
                    System.out.println("Clave      :"+clave);
                    System.out.println("Nombre     :"+nombre);
                    System.out.println("Medida     :"+medida);
                    System.out.println("Existencia :"+existencia);
                    System.out.println("Costo      :"+costo);
                    System.out.println("Precio     :"+precio);                
                    System.out.println("");
                    
                }
            }

            // Cierra el Archivo
            xFileAleatorio.close();
        }
        catch (FileNotFoundException e) 
        {
		 	e.printStackTrace();
		}
        catch (IOException e) 
		{
			e.printStackTrace();
		}

               
        // Mensaje Final
        System.out.println("Programa Terminado...");       
    }       
}