// ------------------------------------------------
// Curso de Java desde 0 sin Ide
// Clase 98 JSplitPane Container
// ------------------------------------------------

// Librerías
import java.awt.Container;
import javax.swing.JSplitPane;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

// Programa Principal
public class programa extends JFrame 
{
    // Propiedades de la Clase
    JSplitPane    splitPane;
    JSplitPane    mainSplitPane;
    JList<String> list;
    JPanel        listPanel;
    JPanel        imagePanel;
    JLabel        img;
    Container     contentPane;
    
    // Lista de Datos
    String listData[] = {"HomeroAplaude","HomeroLlorando","HomeroPensando","HomeroPerdido","HomeroRosquillas","HomeroTomando"};
    
    // Area de Texto
    JTextArea textArea;
    
    // Constructor
    programa()
    {
        // Crea la Lista en Base a los datos
        list = new JList<String>(listData);

        // Agrega en Listener o COntrol de Eventos
        list.addListSelectionListener(new ListSelectionListener() 
        {    
            @Override
            public void valueChanged(ListSelectionEvent e) 
            {   
                // Coloca la opción Seleccionada en el textarea 
                textArea.setText("Esto es : "+list.getSelectedValue());
                
                // Local Images path
                img.setIcon(new ImageIcon("images\\"+list.getSelectedValue()+".jpg"));
            }
        });
        
        // Creamos el area de texto
        textArea = new JTextArea(4,30);
        
        // Adding ListPanel
        listPanel = new JPanel();
        listPanel.add(list);
                
        // Adding Image Pannel
        img = new JLabel();        
        imagePanel = new JPanel();
        imagePanel.add(img);
        

        // Creating SplitPanel
        splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                                   new JScrollPane(listPanel),
                                   new JScrollPane(imagePanel));
        splitPane.setDividerSize(10);
        splitPane.setOneTouchExpandable(true);

        // Split Pane Principal
        mainSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                                       splitPane,
                                       new JScrollPane(textArea));
        mainSplitPane.setDividerSize(10);
        mainSplitPane.setDividerLocation(150);

        // Obtenemos el Contenedor y Agregamos el Split
        contentPane = getContentPane();
        contentPane.add(mainSplitPane);                
    }
    
    public static void main(String[] args) 
    {
        // Crea la Ventana
        programa ventana = new programa();
        ventana.setTitle("98 JSplitPane Container");
        ventana.setSize(400, 275);
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setLocationRelativeTo(null);
    }

}