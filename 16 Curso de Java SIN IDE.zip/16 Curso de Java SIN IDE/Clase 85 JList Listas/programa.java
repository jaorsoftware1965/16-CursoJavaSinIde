// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 85 swing JList
// -------------------------------------------------------

// Librerias
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;

// Clase Principal
public class programa extends JFrame implements ActionListener 
{
    // Propiedades de la Clase	
	private JButton          btnAgregar;
	private JButton          btnDesplegar;
	private JButton          btnEliminar;
	private JButton          btnModificar;
	private JButton          btnSeleccionar;
	private JButton          btnLimpiar;
	private JLabel           lblMensaje;
	private JLabel           lblLenguaje;
	private JTextField       txtLenguaje;
	private JList<String>    lstLenguajes;
	private DefaultListModel<String> modelo;
	private JScrollPane      scrollLista;

	// Constructor
	public programa()
	{
		// Indico que no hay layout
		setLayout(null);

		// Mensaje		
		lblLenguaje = new JLabel("Lenguaje");
		lblLenguaje.setBounds(20, 10, 100, 20);
		
		// Texto para captura
		txtLenguaje= new JTextField();
		txtLenguaje.setBounds(20, 40, 260, 23);
			
		// Boton para Agregar
		btnAgregar= new JButton();
		btnAgregar.setText("Agregar");
		btnAgregar.setBounds(20, 210, 120, 23);
		btnAgregar.addActionListener(this);

		btnEliminar= new JButton();
		btnEliminar.setText("Eliminar");
		btnEliminar.setBounds(20, 240, 120, 23);
		btnEliminar.addActionListener(this);
		
		btnLimpiar= new JButton();
		btnLimpiar.setText("Limpiar");
		btnLimpiar.setBounds(160, 210, 120, 23);
		btnLimpiar.addActionListener(this);

		btnModificar = new JButton();
		btnModificar.setText("Modificar");
		btnModificar.setBounds(20, 270, 120, 23);
		btnModificar.addActionListener(this);

		// Boton para Desplegar Todos
		btnDesplegar = new JButton();
		btnDesplegar.setText("Ver Todos");
		btnDesplegar.setBounds(160, 270, 120, 23);
		btnDesplegar.addActionListener(this);
				
		btnSeleccionar = new JButton();
		btnSeleccionar.setText("Seleccionar");
		btnSeleccionar.setBounds(160, 240, 120, 23);
		btnSeleccionar.addActionListener(this);
		
        // El lblMensaje		
		lblMensaje= new JLabel("Mensajes...");
		lblMensaje.setBounds(20, 300, 280, 23);
		
		//instanciamos el modelo
		modelo = new DefaultListModel<String>();

		// Agregamos al Modelo
		modelo.addElement("C");
		modelo.addElement("C++");
		modelo.addElement("C#");
		modelo.addElement("Java");
		modelo.addElement("Python");
		modelo.addElement("Php");

		
		//instanciamos la lista
		lstLenguajes = new JList<String>();
		lstLenguajes.setModel(modelo);
		//lstLenguajes = new JList<String>(modelo);
		//lstLenguajes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION );		
	   	
		//instanciamos el Scroll que tendra la lista
	    scrollLista = new JScrollPane();
		scrollLista.setBounds(20, 70, 260, 130);
	    scrollLista.setViewportView(lstLenguajes);
		
		/*Agregamos los componentes al Contenedor*/
		add(lblLenguaje);
		add(txtLenguaje);
		add(btnAgregar);
		add(btnEliminar);
		add(btnLimpiar);
		add(btnModificar);
		add(btnSeleccionar);
		add(btnDesplegar);
		add(lblMensaje);
		add(scrollLista);

		lstLenguajes.addMouseListener(new MouseAdapter()  
        {  
            // El evento mouseClicked
            public void mouseClicked(MouseEvent e)  
            {  
				// Obtengo el dato seleccionado
				String dato = lstLenguajes.getSelectedValue();

				// Despliega el dato
                JOptionPane.showMessageDialog(null, 
                                              "Has Seleccionado :"+dato, 
                                              "Java desde 0 sin Ide", 
                                              JOptionPane.OK_OPTION);            

            }                          
        });
		
	}


	@Override
	public void actionPerformed(ActionEvent evento) 
	{
		// Verifica el Elemento
		if (evento.getSource()==btnAgregar)
		{
			// Obtiene el Dato			
			String dato = txtLenguaje.getText();

			// Verifica que haya algo capturado
			if(dato.length()>0)
			{
				// Agrega al Final
				modelo.addElement(dato);
				//modelo.add(0, dato);  // agrega en una posición

		        // Inicializa el Lenguaje
		        txtLenguaje.setText("");

				// Coloca el Mensaje
			    lblMensaje.setText("Se agrego un elemento");
			}
			else
			{
				// Coloca el foco en el texto
				txtLenguaje.requestFocus();

				// Mensaje
				JOptionPane.showMessageDialog(this, 
				                              "Capture el Lenguaje",
						                      "Curso de Java desde 0", 
											  JOptionPane.ERROR_MESSAGE);
				
				// Actualiza el Mensaje
			    lblMensaje.setText("Capture el Lenguaje");
			}
		    
		}
        else
		// Verifica botón de Eliminar
		if (evento.getSource()==btnEliminar)
		{
			// Obtiene el Indice
			int indice = lstLenguajes.getSelectedIndex();

			// Verifica que haya seleccionado
			if (indice>=0) 
			{
				// Elimina el Elemento
				modelo.removeElementAt(indice);	
				lblMensaje.setText("Se elimino un elemento");
			}
			else
			{
				JOptionPane.showMessageDialog(null, 
				                              "Debe seleccionar un indice",
						                      "Java Desde 0 sin Ide", 
											  JOptionPane.ERROR_MESSAGE);
				
			    lblMensaje.setText("No se ha eliminado elemento");
			}
	
		}
		else
		if (evento.getSource()==btnModificar)
		{
			// Obtiene el Indice
			int indice = lstLenguajes.getSelectedIndex();

			// Verifica que haya seleccionado
			if (indice>=0) 
			{
				// Verifica que haya texto para modificar
				// Obtiene el Dato			
			    String dato = txtLenguaje.getText();

			    // Verifica que haya algo capturado
			    if(dato.length()>0)
			    {
					// Elimina el Elemento
				    modelo.removeElementAt(indice);	

					// Inserta el elemento en la posición
					modelo.add(indice, dato);  // agrega en una posición
				
					// Mensaje
				    lblMensaje.setText("Se modifico un elemento");

					// Selecciona
					lstLenguajes.setSelectedIndex(indice);
				}
				else
				{
					// Mensaje de Error
					JOptionPane.showMessageDialog(null, 
				                              "Debe Capturar el Lenguaje",
						                      "Java Desde 0 sin Ide", 
											  JOptionPane.ERROR_MESSAGE);
				
			        lblMensaje.setText("Capture un Lenguaje");
				}
				
				
			}
			else
			{
				JOptionPane.showMessageDialog(null, 
				                              "Debe seleccionar un elemento",
						                      "Java Desde 0 sin Ide", 
											  JOptionPane.ERROR_MESSAGE);
				
			    lblMensaje.setText("Seleccione un Elemento a Modificar");
			}
			
		}
		else
		// Verifica botón de Seleccionar
		if (evento.getSource()==btnSeleccionar)
		{
			// Obtiene indice actual
			int indice = lstLenguajes.getSelectedIndex();
			
			// Obtiene el dato
			String dato = txtLenguaje.getText();
			System.out.println("Seleccionar");

			// Verifica que haya algo capturado
			if(dato.length()>0)
			{
				// Selecciona
				lstLenguajes.setSelectedValue(dato, true);

				// Verifica que haya seleccionado
				if (indice==lstLenguajes.getSelectedIndex())
				{
					// Mensajes
					JOptionPane.showMessageDialog(null, 
					"No se encontro elemento",
					"Java desde 0 sin Ide", 
					JOptionPane.ERROR_MESSAGE);
					// Mensaje
					lblMensaje.setText("No se selecciono");
				}
			}			
			else
			{
				// Mensaje
				JOptionPane.showMessageDialog(null, 
				                              "Debe Capturar el Lenguaje",
						                      "Java desde 0 sin Ide", 
											  JOptionPane.ERROR_MESSAGE);
				// Mensaje
			    lblMensaje.setText("Capture Lenguaje a Seleccionar");
			}	
		}
		else
		if (evento.getSource()==btnDesplegar)
		{
			// Vector para los datos
			int seleccionados[];
			seleccionados = lstLenguajes.getSelectedIndices();

			// Variable para seleccionados
			String selLenguajes="";

			// Ciclo para 
			for (int i=0; i< seleccionados.length;i++)
			{
				int pos = seleccionados[i];
				selLenguajes+=modelo.elementAt(pos)+"\n";
			}

			// Mensaje
			JOptionPane.showMessageDialog(this, 
			"Los Elementos Seleccionados:\n"+selLenguajes,
			"Java desde 0 sin Ide", 
			JOptionPane.OK_OPTION);

			lblMensaje.setText("Se Desplegaron los Seleccionados");
		}
		else
		if (evento.getSource()==btnLimpiar)
		{
			// Se eliminan todos los elementos
			modelo.clear();
			lblMensaje.setText("Se Limpio la Lista");
		}
		
	}
	
	public static void main(String[] args) 
	{
		/*Declaramos el objeto*/
		programa ventana;
		
		/*Instanciamos el objeto*/
		ventana= new programa();

		/*Hacemos que se cargue la ventana*/
		ventana.setVisible(true);

		/*Asigna un titulo a la barra de titulo*/
		ventana.setTitle("85 JList");

		/*tama�o de la ventana*/
		ventana.setSize(320,380);
		
		/*pone la ventana en el Centro de la pantalla*/
		ventana.setLocationRelativeTo(null);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
