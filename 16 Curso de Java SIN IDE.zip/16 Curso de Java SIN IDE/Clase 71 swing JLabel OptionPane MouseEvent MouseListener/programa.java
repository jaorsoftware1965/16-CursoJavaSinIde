// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 71 swing awt JLabel JOptionPane MouseListener
//          MouseEvent                 
// -------------------------------------------------------

// Librería para swing
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;



// Clase se debe llamar igual que el archivo
public class programa extends JFrame implements MouseListener
{   
    // Creamos los objetos
    private  JLabel  lblEtiqueta1;    
    private  JLabel  lblEtiqueta2;    

    // Constructor
    public programa()
    {
        // Establecemos el Layout
        setLayout(null);

        // Creamos los objetos
        lblEtiqueta1 = new JLabel("Pasa sobre mi y da Click sobre mi");
        lblEtiqueta2 = new JLabel("Pasa sobre mi y da Click sobre mi");

        // Establecemos posición y dimensiones
        lblEtiqueta1.setBounds(20,20,300,30);
        lblEtiqueta2.setBounds(20,50,200,30);

        // Colocamos Icono
        ImageIcon icono = new ImageIcon("icono.png");
        lblEtiqueta1.setIcon(icono);  
        
        // Controla el Evento Action
        lblEtiqueta1.addMouseListener(this);
        lblEtiqueta2.addMouseListener(this);
        
        // Añadimos los Objetos
        add(lblEtiqueta1);
        add(lblEtiqueta2);
        
    }
    
    // Para controlar el Click en la Etiqueta
    public void mouseClicked(MouseEvent evento) 
    {
        // Valida cual objeto
        if (evento.getSource()==lblEtiqueta1) 
        {
            JOptionPane.showMessageDialog(this, 
                                          "Evento mouseClicked en la Etiqueta", 
                                          "Java desde 0 sin Ide", 
                                          JOptionPane.OK_OPTION);            

        }
    }
    public void mouseExited(MouseEvent e) 
    {
        if (e.getSource()==lblEtiqueta1) 
        {
            JOptionPane.showMessageDialog(this, 
                                          "Evento mouseExited en la Etiqueta", 
                                          "Java desde 0 sin Ide", 
                                          JOptionPane.OK_OPTION);            

        }
    }

    public void mouseEntered(MouseEvent e) 
    {
        if (e.getSource()==lblEtiqueta1) 
        {
            JOptionPane.showMessageDialog(this, 
                                          "Event mouseEntered en la Etiqueta", 
                                          "Java desde 0 sin Ide", 
                                          JOptionPane.OK_OPTION);            

        }
        else
        if (e.getSource()==lblEtiqueta2) 
        {
            JOptionPane.showMessageDialog(this, 
                                          "Event mouseEntered en la Etiqueta 2", 
                                          "Java desde 0 sin Ide", 
                                          JOptionPane.OK_OPTION);            

        }

    }

    public void mouseReleased(MouseEvent e) 
    {
        if (e.getSource()==lblEtiqueta1) 
        {
            JOptionPane.showMessageDialog(this, 
                                          "Evento mouseReleased en la Etiqueta", 
                                          "Java desde 0 sin Ide", 
                                          JOptionPane.OK_OPTION);            

        }
    }

    public void mousePressed(MouseEvent e) 
    {
        if (e.getSource()==lblEtiqueta1) 
        {
            JOptionPane.showMessageDialog(this, 
                                          "Evento mousePressed en la Etiqueta", 
                                          "Java desde 0 sin Ide", 
                                          JOptionPane.OK_OPTION);            

        }
    }
                
    // Función main que es obligatorio
    public static void main(String args[])
    {   
        // Creamos el Formulario
        programa ventana = new programa();

        // COlocamos caracteristica
        ventana.setTitle("Clase 71 - Swing JLabel JOptionPane");
        ventana.setBounds(10,10,600,300);
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Centramos la ventana
        ventana.setLocationRelativeTo(null);
        ventana.setResizable(false);
    }       
}