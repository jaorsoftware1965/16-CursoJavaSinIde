// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 69 Libreria Swing
// -------------------------------------------------------

// Librería para swing
import javax.swing.JFrame;

// Clase se debe llamar igual que el archivo
public class programa extends JFrame
{           
    // Función main que es obligatorio
    public static void main(String args[])
    {                
        // Creamos un objeto Formulario
        programa formulario = new programa();
        
        // Colocamos el Título
        formulario.setTitle("Clase 69 - Interfaz Grafica con Swing");

        // Establecemos la dimensión y posición
        formulario.setBounds(10,10,400,300);

        // Establecemos que es visible
        formulario.setVisible(true);

        // Establecemos que finalize la aplicación al cerrar
        formulario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);    
    }       
}