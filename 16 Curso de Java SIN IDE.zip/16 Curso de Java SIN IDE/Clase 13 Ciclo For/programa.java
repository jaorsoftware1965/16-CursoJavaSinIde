// --------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 13 Ciclo For
// --------------------------------------

// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
    System.out.println("Clase 13 Ciclo for");      
    System.out.println("Ciclo for 1");   
    for (int i = 0; i < 5; i++) 
    {
         System.out.println(i);
    }
    System.out.println();

    System.out.println("Ciclo for 2");   
    for (int i = 0; i < 5; i=i+2) 
    {
         System.out.println(i);
    }
    System.out.println();

    System.out.println("Ciclo for 3");   
    for (int i = 10; i > 0; i--) 
    {
         System.out.println(i);
    }
    System.out.println();
    
    System.out.println("Ciclo for 4");   
    for (int i = 10; i > 0; i++) 
    {
         System.out.println(i);
         if (i>=20)
            i=-100;
    }
    System.out.println();

    System.out.println("Ciclo for 5");   
    for (int i = -10; i < 0; i++) 
    {
         System.out.println(i);
    }
    System.out.println();

  }    
}