// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 65 Archivos Binarios con Datos Primitivos
// -------------------------------------------------------
	
// Librerías
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.*;
import java.util.Scanner;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[]) throws IOException
    {
        // Despliega
        System.out.println("Clase 65 Archivos Binarios con Tipos Primarios");

        // Creamos objeto de Salida
		DataOutputStream salida=new DataOutputStream(new FileOutputStream("pedido.txt"));

        // Defimimos los datos a grabar
        double[] precios       = {1350, 400, 890, 6200, 8730}; // 8
        int[]    unidades      = {5, 7, 12, 8, 30};            // 4
        String[] descripciones = {"paquetes de papel   ",      //42
                                  "lapices marca Mirado", 
                                  "boligrafos          ", 
                                  "carteras            ", 
                                  "mesas               "};

        // Ciclo para grabar los registros                           
        for (int i=0; i<precios.length; i ++) 
        {
            // Despliega la Información a Grabar
            System.out.println("Registro:"+(i+1));
            System.out.println(descripciones[i]);
            System.out.println(unidades[i]);            
            System.out.println(precios[i]+ "\n");

            // Graba los datos
            salida.writeChars(descripciones[i]);
            salida.writeChar('\n');
            salida.writeInt(unidades[i]);
            salida.writeDouble(precios[i]);
        }
        
        // Cierra el Archivo
        salida.close();

        // Objeto para leer los datos del archivo
        DataInputStream entrada=new DataInputStream(new FileInputStream("pedido.txt"));

        // Variables para lectura
        double precio;
        int    unidad;
        String descripcion;
        double total=0.0;

        try 
        {
            // Saltamos el primer registro            
            while ((descripcion=entrada.readLine())!=null) 
            {
                // Leo el resto de los datos
                unidad=entrada.readInt();
                precio=entrada.readDouble();
                System.out.println("Has pedido "+unidad+" "+descripcion+" a "+precio+" pts.");
                total = total + unidad * precio;
            }
            System.out.println("Final del archivo");
        }
        catch (EOFException e) 
        {
            System.out.println("Excepción cuando se alcanza el final del archivo");
        }
        // Mensaje del Total
        System.out.println("Por un TOTAL de: "+total+" pts.");

        // Cierra la Entrada
        entrada.close();

        // Registro a Leer
        int iRegistroLeer;
        long salto;

        // Creamos un objeto de la Clase Entrada
        Scanner oEntrada = new Scanner(System.in);            

        // Ciclo para leer registros
        while (true)
        {
            // Indique el Registro a Leer
            System.out.print("Registro a Leer (0-Salir):");
            iRegistroLeer = oEntrada.nextInt();

            // Verifica que sea 0
            if (iRegistroLeer == 0)
               break;
            else
            {
                // Abrimos el archivo
                entrada = new DataInputStream(new FileInputStream("pedido.txt"));

                // Calculamos el Salto
                salto = (iRegistroLeer-1) * 54;

                try
                {
                    // Realiza el Salto
                    entrada.skip(salto);                  
                    
                    // Lee los datos
                    descripcion = entrada.readLine();
                    unidad      = entrada.readInt();
                    precio      = entrada.readDouble();

                    // Despliega los datos
                    System.out.println("Descripcion:"+descripcion);
                    System.out.println("Unidad     :"+unidad);
                    System.out.println("Precio     :"+precio+"\n");                    
                }
                catch(java.io.EOFException e)
                {
                    // error
                    System.out.println("Error en Registro\n");
                }                            
                
                // Cierra el Archivo
                entrada.close();                
            }                           
        }
                                		       
        // Mensaje Final
        System.out.println("Programa Terminado...");       
    }       
}