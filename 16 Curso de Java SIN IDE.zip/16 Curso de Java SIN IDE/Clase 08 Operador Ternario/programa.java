// ----------------------------------
// Curso de Java desde 0 sin IDE
// Clase 08 Operador Ternario
// ----------------------------------

// El operador ternario es un operador condicional.
// El operador ternario es representado mediante los  
// símbolos ?:

// La estructura del operador ternario es:
// resultado = (expresion) ? valorSitrue : valorSifalse;

// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
    int x = 5;
    int y = 4;  
    int resultado;
    
    resultado =  x > y ? x : y;
    System.out.println("El mayor es : " + resultado);

    resultado = y > x ? x * 5 : y * 10;
    System.out.println("El menor o igual multiplicado por 10 : " + resultado);

    System.out.println( true  ? "Verdad" : "Falso");
    System.out.println( false ? "Verdad" : "Falso");

    boolean res =  x > y ? x > y : x <= y;
    System.out.println("Res : "+ res);

    res =  x < y ? x > y : x <= y;
    System.out.println("Res : "+ res);
  }
}