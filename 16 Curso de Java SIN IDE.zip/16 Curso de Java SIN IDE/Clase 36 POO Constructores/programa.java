// -----------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 36 POO Constructores
// -----------------------------------------

// Un Constructor es un método que su nombre
// debe ser igual al de la clase; y que se 
// ejecuta al momento de crear un objeto; 
// es decir al usar la palabra
// reservada new

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    { 
        // Creamos un objeto de persona con valores default
        personas oPersona0 = new personas();
        
        // Imprimimos la Información
        oPersona0.fnImprimeInformacion();
        System.out.println("");       

        // Creamos un objeto de persona
        personas oPersona1 = new personas("","",' ',12);

        // Imprimimos la Información
        oPersona1.fnImprimeInformacion();
        System.out.println("");       
        
        // Creamos otro de persona
        personas oPersona2 = new personas("Juan Escutia","Juarez 24",'M',15);
        oPersona2.fnImprimeInformacion();
        System.out.println("");            

        // Creamos otro de persona
        personas oPersona3 = new personas("Maria Morales","Centro No. 15",'F',18);
        oPersona3.fnImprimeInformacion();
        System.out.println("");  

        oPersona1.fnImprimeInformacion();
        System.out.println("");  
        
        
    }   
}