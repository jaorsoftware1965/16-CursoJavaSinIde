// -------------------------
// Curso de Java sin IDE
// Clase 14 Sentencia switch
// ------------------------- 

// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
    // Variable del dia
    int dia = 14;
    
    // Verifica el dia
    switch (dia) 
    {
      case 1:
        System.out.println("Lunes");
        break;
      case 2:
        System.out.println("Martes");
        break;
      case 3:
        System.out.println("Miercoles");
        break;
      case 4:
        System.out.println("Jueves");
        break;
      case 5:
        System.out.println("Viernes");
        break;
      case 6:
        System.out.println("Sabado");
        break;
      case 7:
        System.out.println("Domingo");
        break;
      default:
        System.out.println("Numero incorrecto");
        break;  
    }

    // Variable para el Nombre del Dia
    String diaNombre = "Miercolesss";

    switch (diaNombre) 
    {
      case "Lunes":
        System.out.println(1);
        break;
      case "Martes":
        System.out.println(2);
        break;  
      case "Miercoles":
        System.out.println(3);
        break;
      case "Jueves":
        System.out.println(4);
        break;
      case "Viernes":
        System.out.println(5);
        break;
      case "Sabado":
        System.out.println(6);
        break;
      case "Domingo":
        System.out.println(7);
        break;     
      default:
        System.out.println("Nombre desconocido");
        break;     
    }
   
  }
}