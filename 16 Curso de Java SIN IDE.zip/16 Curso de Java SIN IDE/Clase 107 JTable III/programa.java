// ------------------------------------------------------
// Curso de Java desde 0 sin Ide
// 107 JTable III
// Clase Final
// ------------------------------------------------------

// Librerias
import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JRootPane;
import javax.swing.table.DefaultTableModel;

import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.JTableHeader;

import java.awt.Color;
import java.awt.Component;

// Clase Principal
public class programa extends JFrame
{
    // Propiedades
    JTable       tblDatos;
    TableColumn  tcol;
    JPanel       panelFrame;
    JScrollPane  panelDatos;
    JTableHeader header;
    
    // Constructor
    public programa()
    {           
        // Establece los datos
        String data[][] = 
        {            
            {"Vinicio" ,"Computacion","3"},
            {"Raul"    ,"Historia"   ,"2"},
            {"Manoella","Biologia"   ,"4"},
            {"Samuel"  ,"Progamacion","5"}
        };

        // Columnas
        String col [] = {"Alumno","Curso","Semestre"};

        // Genera el Modelo de datos
        DefaultTableModel model = new DefaultTableModel(data,col);
        
        // Crea la Tabla
        tblDatos = new JTable(model);

        // Cambia el Cell Renderer de las Columna
        tcol = tblDatos.getColumnModel().getColumn(0);
        tcol.setCellRenderer(new ControlCeldas());

        tcol = tblDatos.getColumnModel().getColumn(1);
        tcol.setCellRenderer(new ControlCeldas());

        tcol = tblDatos.getColumnModel().getColumn(2);
        tcol.setCellRenderer(new ControlCeldas());

        // Obtiene el Header de la Tabla y lo coloca en Amarillo
        header = tblDatos.getTableHeader();
        header.setBackground(Color.yellow);

        // Crea el Scroll con la Tabla
        panelDatos = new JScrollPane(tblDatos);

        // Crea un Panel     
        panelFrame = new JPanel();

        // Añade al Panel el Scroll
        panelFrame.add(panelDatos);

        // Añade el panel al Frame
        add(panelFrame);        
    }

    // Clase para la Celda
    public class ControlCeldas extends DefaultTableCellRenderer
    {
        // Metodo que se debe implementar
        public Component getTableCellRendererComponent (JTable  table, 
                                                        Object  obj, 
                                                        boolean isSelected, 
                                                        boolean hasFocus, 
                                                        int     row, 
                                                        int     column) 
        {
            // Obtiene la referencia a la celda
            Component cell = super.getTableCellRendererComponent(
            table, obj, isSelected, hasFocus, row, column);

            // Verifica si está seleccionada
            if (isSelected) 
            {
                // Cambias el Color a Verde
                cell.setBackground(Color.green);
            } 
            else 
            {   
                // Verifica si es par
                if (row % 2 == 0) 
                {
                    // Cyan si es par
                    cell.setBackground(Color.cyan);
                }
                else     
                {
                    // Lightgray si es impar
                    cell.setBackground(Color.lightGray);
                }
            }

            if (hasFocus) 
            {
                // Cambias el Color a Rojo
                cell.setBackground(Color.red);
            }
            
            // Devuelve la Celda
            return cell;
        }
    }

    public static void main(String[] args) 
    {
        // Crea una ventana del Programa
        programa ventana = new programa();

        // Establece las Caracteristicas de la Ventana
        ventana.setTitle("Creating a Custom Cell Reanderer!");
        ventana.setSize(500,480);
        ventana.setUndecorated(true);
        ventana.getRootPane().setWindowDecorationStyle(JRootPane.PLAIN_DIALOG);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);
    }    
}