// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 88 BoxLayout
// -------------------------------------------------------

// Librerias
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.BoxLayout;


// Librerias
public class programa extends JFrame 
{
   // Creamos 4 objetos botones
   private JButton btn01;
   private JButton btn02;
   private JButton btn03;
   private JButton btn04;

    // Constructor
    public programa() 
    {

       // Creamos los botones
       btn01 = new JButton("Boton 01");
       btn02 = new JButton("Boton 02");
       btn03 = new JButton("Boton 03");
       btn04 = new JButton("Boton 04");

       // Agrega los botones
       add(btn01);
       add(btn02);
       add(btn03);
       add(btn04);

       // Establecemos caracteristicas del Frame
       setTitle("88 BoxLayout");
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);     
       //setSize(600,400);       
       setVisible(true);      
       setLayout(new BoxLayout(getContentPane(),BoxLayout.Y_AXIS));
       pack();

       // Centra
       setLocationRelativeTo( null );
       
    }

    
    public static void main(String args[]) 
    {
       // Creamos un Objeto del Programa
       new programa();
    }
 }