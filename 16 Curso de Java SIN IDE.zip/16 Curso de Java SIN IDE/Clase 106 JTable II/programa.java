// ------------------------------------------------------
// Curso de Java desde 0 sin Ide
// Clase 106 JTable II
// ------------------------------------------------------

// Librerias
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane; 
import javax.swing.event.ListSelectionEvent;  
import javax.swing.event.ListSelectionListener;

// Clase Principal
public class programa extends JFrame
{
    // Propiedades
    JTable tblDatos;

    // Constructor
    public programa()
    {
        //headers for the table
        String[] columns = new String[] {
            "Id", "Name", "Hourly Rate", "Part Time"
        };
         
        //actual data for the table in a 2d array
        Object[][] data = new Object[][] {
            {1, "John", 40.0, false },
            {2, "Rambo", 70.0, false },
            {3, "Zorro", 60.0, true },
        };
         
        final Class[] columnClass = new Class[] 
        {
            Integer.class, 
            String.class, 
            Double.class, 
            Boolean.class
        };
        
        //create table model with data
        DefaultTableModel model = new DefaultTableModel(data, columns) 
        {
            @Override
            public boolean isCellEditable(int row, int column)
            {
                if (column==1)
                   return true;
                else   
                   return false;
            }
            @Override
            public Class<?> getColumnClass(int columnIndex)
            {
                return columnClass[columnIndex];
            }
        };
        
        // Crea la Tabla usando el Modelo
        tblDatos = new JTable(model);

        // Habilitas seleccion por row
        tblDatos.setRowSelectionAllowed(true);
        
        // Controla el Evento de Click en la Tabla
        tblDatos.getSelectionModel().addListSelectionListener(new ListSelectionListener() 
        {  
            // Evento de que valor cambio
            public void valueChanged(ListSelectionEvent e) 
            {  
                String dato;
                int renglon = tblDatos.getSelectedRow();
                int columna = tblDatos.getSelectedColumn();
        
                // Verifica que sea positivo
                if (renglon >- 1)
                {
                    // Obtiene el dato
                    dato = tblDatos.getValueAt(renglon, columna).toString();
        
                    // Muestra el dato seleccionado
                    JOptionPane.showMessageDialog(null, 
                                                  "Seleccionaste:\n" +
                                                  dato,
                                                  "Java desde 0 sin Ide", 
                                                  JOptionPane.OK_OPTION);                
                }
            }       
        });
                         
        //add the table to the frame
        add(new JScrollPane(tblDatos));              
    }
     
    public static void main(String[] args)
    {
        // Crea una ventana del programa
        programa ventana = new programa();

        // Establece caracteristicas
        ventana.setTitle("106 JTable II");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);       
        ventana.pack();
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);        
    }   
}