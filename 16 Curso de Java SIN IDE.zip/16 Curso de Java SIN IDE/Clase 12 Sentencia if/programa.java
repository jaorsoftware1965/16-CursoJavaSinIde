// ---------------------
// Curso de Java sin IDE
// Clase 12 Sentencia if
// ---------------------

// if (condicion) 
// {
//    Sentencias si condición si es verdad
// } 
// else 
// {
//    Sentencias si condición no es verdad
// }

// if (condicion) 
// {
//    Sentencias si condición es verdad
// } 
// else if (condicion2)
// {
//    Sentencias si condición2 si es verdad
// }
// else 
// {
//    Sentencias si condición2 no es verdad
// }

 

// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
    // Variable Entera
    int x = 10;
    int y = 20;

    if (x > y)
    {
      System.out.println("x > y");
    }
    else if(x < y)
    {
      System.out.println("y > x");
    }
    else
    {
      System.out.println("y == x");
    }

    y = 5;

    if (x > y)
    {
      System.out.println("x > y");
    }
    else if( x < y)
    {
      System.out.println("y > x");
    }
    else
    {
      System.out.println("y == x");
    }

    y = x;

    if (x > y)
    {
      System.out.println("x > y");
    }
    else if(x < y)
    {
      System.out.println("y > x");
    }
    else
    {
      System.out.println("y == x");
    }

    // Variable para nombre
    String sNombre = "Jose Juan Perez Rodriguez";
    int    iEdad   = 33;

    if (sNombre.contains("Perez") && iEdad >= 18)  
    {
       System.out.println("Se apellida Perez y es mayor de edad");
    }
    else if (sNombre.contains("Perez"))
    {
       System.out.println("No es mayor de Edad");
    }
    else
    {
       System.out.println("No se apellida Perez");
    }

    sNombre = "Jose Juan Rodriguez";

    if (sNombre.contains("Perez") && iEdad >= 18)  
    {
       System.out.println("Se apellida Perez y es mayor de edad");
    }
    else if (sNombre.contains("Perez"))
    {
       System.out.println("No es mayor de Edad");
    }
    else
    {
       System.out.println("No se apellida Perez");
    }

    iEdad = 17;

    if (sNombre.contains("Jose") && iEdad >= 18)  
    {
       System.out.println("Se llama Jose y es mayor de edad");
    }
    else if (sNombre.contains("Jose"))
    {
       System.out.println("No es mayor de Edad");
    }
    else
    {
       System.out.println("No se llama Jose");
    }
  }
}