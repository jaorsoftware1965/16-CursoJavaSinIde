// -----------------------------
// Curso de Java desde 0 sin IDE
// Clase 05 Operadores Lógicos
// -----------------------------

// Los operadores lógicos se utilizan para evaluar
// valores booleanos y su resultado tambien es 
// un valor booleano

// Operador && And Lógico	
// Operando1  Operador  Operando2   Resultado
// True       &&        True        True
// True       &&        False       False
// False      &&        True        False
// False      &&        False       False

// Operador || Or Lógico	
// Operando1  Operador  Operando2   Resultado
// True       ||        True        True
// True       ||        False       True
// False      ||        True        True
// False      ||        False       False

// Operador Not Lógico 
// Operador   Operando  Resultado
// !          True      False
// !          False     True  


// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
    
    System.out.println("true && true         :" + (true && true));
    System.out.println("true || true         :" + (true || true));
    System.out.println("! true               :" + (! true));
    System.out.println("10 > 5 && 10 > 8     :" +  (10 > 5 && 10 > 8));
    System.out.println("10 > 5 && 10 < 8     :" +  (10 > 5 && 10 < 8));
    System.out.println("10 < 5 || 10 < 8     :" +  (10 < 5 || 10 < 8));
    System.out.println("10 > 5 || 10 < 8     :" +  (10 > 5 || 10 < 8));
    System.out.println("! (10 > 5)           :" +  ! (10 > 5));
    System.out.println("! (10 < 5 && 10 < 8) :" +  ! (10 < 5 && 10 < 8));
  }
}