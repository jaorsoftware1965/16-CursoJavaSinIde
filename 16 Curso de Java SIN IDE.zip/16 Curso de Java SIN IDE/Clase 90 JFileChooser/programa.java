// --------------------------------------
// Curso de Java desde 0 sin IDE
// 90 JFileChooser printStackTrace
// --------------------------------------

//Librerias
import javax.swing.JFrame;    
import javax.swing.JMenuBar;    
import javax.swing.JMenu;    
import javax.swing.JMenuItem;    
import javax.swing.JTextArea;    
import javax.swing.JFileChooser;    
import java.awt.event.ActionListener;    
import java.awt.event.ActionEvent;    
import java.io.File;    
import java.io.FileReader;    
import java.io.BufferedReader;    

// Clase Principal
public class programa extends JFrame implements ActionListener
{    
    // Propiedades de la Clase
    JMenuBar    mnuBarraPrincipal;    
    JMenu       mnuFile;    
    JMenuItem   mniAbrir;    
    JTextArea   txaEditor;    

    // Constructor
    programa()
    {   
        // Se crea la barra principal 
        mnuBarraPrincipal=new JMenuBar();    
        mnuBarraPrincipal.setBounds(0,0,600,20);    

        // Se crea el Menu Archivo y se agrega
        mnuFile=new JMenu("Archivo");                
        mnuBarraPrincipal.add(mnuFile);              

        // Crea la Opcion Abrir y lo agrega
        mniAbrir=new JMenuItem("Abrir");    
        mnuFile.add(mniAbrir); 
        
        // Establece le Evento
        mniAbrir.addActionListener(this);                            
        
        // Crea el TextArea
        txaEditor=new JTextArea(800,800);    
        txaEditor.setBounds(0,20,800,800);              

        // Agrega la Barra y el Text Area al Frame
        add(mnuBarraPrincipal);    
        add(txaEditor);              
    }    

    // Accion del Boton
    public void actionPerformed(ActionEvent e) 
    {    
        // VAlida opcion Abrir
        if (e.getSource()==mniAbrir)
        {    
            // Crea el Objeto FileChosser
            JFileChooser dlgArchivo = new JFileChooser();    

            // Ejecuta el dialogo y obtiene la respuesta
            int respuesta = dlgArchivo.showOpenDialog(this);    
            
            // Verifica respuesta
            if (respuesta == JFileChooser.APPROVE_OPTION)
            {    
                // Obtiene el archivo Seleccionado
                File fArchivo = dlgArchivo.getSelectedFile();    

                // Obtiene la Ruta-Nombre del Archivo
                String archivoRuta = fArchivo.getPath();    

                try
                {  
                    // Crea buffer de Lectura y Lee
                    BufferedReader bufLectura=new BufferedReader(new FileReader(archivoRuta));
                    
                    // Variables para leer del Archivo
                    String sLinea = "";
                    String sArchivoCompleto="";               

                    while((sLinea = bufLectura.readLine())!=null)
                    {    
                        // Agrega la linea a Archivo Completo
                        sArchivoCompleto+=sLinea+"\n";    
                    }    
                    
                    // Coloca el Archivo Completo en Editor
                    txaEditor.setText(sArchivoCompleto);    
                    
                    // Cierra el Buffer de LEctura
                    bufLectura.close();    
                }
                // Captura el Error
                catch (Exception ex) 
                {
                    // Trace del Error
                    ex.printStackTrace();  
                }    
            }             
        }    
    }    
             
    public static void main(String[] args) 
    {  
        // Crea el objeto de la Clase  
        programa ventana = new programa();  
        ventana.setTitle("90 JFileChooser");  
        ventana.setSize(800,600);    
        ventana.setLayout(null);    
        ventana.setVisible(true);    
        ventana.setDefaultCloseOperation(EXIT_ON_CLOSE);    
        ventana.setLocationRelativeTo(null);
    }    
}