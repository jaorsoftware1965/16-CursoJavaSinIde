// -----------------------------------
// Curso de Java sin IDE
// Clase 02 Variables y Tipos de Datos
// -----------------------------------
 
// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {     
     // Declarando variables de tipos de datos
     byte    xByte   = 127;          // 1b -128 a 127
     short   xShort  = 13450;        // 2b -32768 a 32767
     int     xInt    = 5;            // 4b -2,147,483,648 to 2,147,483,647
     long    xLong   = 12345679l;    // 8b -9,223,372,036,854,775,808 a 9,223,372,036,854,775,807
     float   xFloat  = 5.99f;        // 4b 3.4e−038 a 3.4e+038 de 6 a 7 decimales
     double  xDouble = 3.1416d;      // 8b 1.7e−308 a 1.7e+308 hasta 15 decimales  
     char    xChar   = 'D';          // 2b Caracteres
     boolean xBool   = true;         // 1b true / false
    
     // Imprimiendo las variables
     System.out.println("xByte   :" + xByte);
     System.out.println("xShot   :" + xShort);
     System.out.println("xInt    :" + xInt);
     System.out.println("xLong   :" + xLong);
     System.out.println("xFloat  :" + xFloat);
     System.out.println("xDouble :" + xDouble);
     System.out.println("xChar   :" + xChar);
     System.out.println("xBool   :" + xBool + "\n");

     // Modificando los valores
     xByte   = 127;             // -128 a 127
     xShort  = -13450;           // -32768 a 32767
     xInt    = -15;              // -2,147,483,648 to 2,147,483,647
     xLong   = -45679L;          // -9,223,372,036,854,775,808 to 9,223,372,036,854,775,807
     xFloat  = -1345.99f;        // 3.4e−038 a 3.4e+038 de 6 a 7 decimales
     xDouble = -1233.2221416d;   // 1.7e−308 a 1.7e+308 hasta 15 decimales  
     xChar   = 'X';              // Caracteres
     xBool   = false;            // true / false

     // Imprimiendo las variables
     System.out.println("xByte   :" + xByte);
     System.out.println("xShot   :" + xShort);
     System.out.println("xInt    :" + xInt);
     System.out.println("xLong   :" + xLong);
     System.out.println("xFloat  :" + xFloat);
     System.out.println("xDouble :" + xDouble);
     System.out.println("xChar   :" + xChar);
     System.out.println("xBool   :" + xBool);     
  }
}