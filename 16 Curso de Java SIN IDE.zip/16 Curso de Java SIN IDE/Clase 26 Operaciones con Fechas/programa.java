// ---------------------------------
// Curso de Java desde 0 sin IDE
// Clase 26 Operaciones con Fechas
// ---------------------------------

// Importamos las librerias
import java.time.LocalDate; 
import java.time.Period;
import static java.time.temporal.ChronoUnit.DAYS;
import static java.time.temporal.ChronoUnit.MONTHS;
import static java.time.temporal.ChronoUnit.YEARS;


// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
    // Creando una fecha específica
    //LocalDate date = LocalDate.parse("2018-10-30");
    LocalDate date = LocalDate.of(2018, 10,30);

    System.out.println("Fecha Creada:"+date);
    System.out.println();

    // Agregandole dias
    LocalDate newDate = date.plusDays(10);    
    System.out.println("Fecha Mas 10 Dias:"+newDate);
    System.out.println();

    // Agregandole Meses
    newDate = date.plusMonths(2);    
    System.out.println("Fecha Mas 2 Meses:"+newDate);
    System.out.println();

    // Agregando Años
    newDate = date.plusYears(5);    
    System.out.println("Fecha Mas 5 Anios:"+newDate);
    System.out.println();

    // Disminuyendo Años
    newDate = date.minusYears(5);    
    System.out.println("Fecha Menos 5 Anios:"+newDate);
    System.out.println();

    // Disminuyendo Semanas
    newDate = date.minusWeeks(5);    
    System.out.println("Fecha Menos 5 Semanas:"+newDate);
    System.out.println();

    // Sumando Semanas
    newDate = date.plusWeeks(5);    
    System.out.println("Fecha Mas 5 Semanas:"+newDate);
    System.out.println();


    // Valida si un año es bisiesto
    System.out.println("Es bisiesto 2018:"+date.isLeapYear());
    System.out.println();

    // Verificar si una fecha es anterior a otra
    System.out.println("Es anterior:"+date.isBefore(newDate));  
    System.out.println();

    // Verificar si una fecha es anterior a otra
    System.out.println("Es posterior:"+date.isAfter(newDate));  
    System.out.println();

    // Obtener el dia de la semana
    date = LocalDate.now();
    System.out.println("El dia de la semana de hoy:"+date.getDayOfWeek());  
    System.out.println();

    System.out.println("El dia del mes de hoy:"+date.getDayOfMonth());  
    System.out.println();

    System.out.println("El dia del anio de hoy:"+date.getDayOfYear());  
    System.out.println();

    System.out.println("El mes de hoy:"+date.getMonth());  
    System.out.println();

    System.out.println("El mes de hoy:"+date.getMonthValue());  
    System.out.println();

    System.out.println("El Anio hoy:"+date.getYear());  
    System.out.println();

    System.out.println("Longitud del Mes:"+date.lengthOfMonth());  
    System.out.println();

    System.out.println("Longitud del Anio:"+date.lengthOfYear());  
    System.out.println();

    // Compara    
    newDate = date.plusMonths(5);
    System.out.println("Comparacion:"+date.compareTo(newDate));  
    System.out.println("Comparacion:"+date.compareTo(date));  
    System.out.println();

    // Verifica igualdad
    System.out.println("Es igual:"+date.equals(newDate));  
    System.out.println("Es igual:"+date.equals(date));  
    System.out.println();

    // Diferencia
    System.out.println("date    :"+date);  
    System.out.println("newDate :"+newDate);  
    Period diferencia = date.until(newDate);
    System.out.println("Diferencia en dias :"+diferencia.getDays());  
    System.out.println("Diferencia en Meses:"+diferencia.getMonths());  
    System.out.println("Diferencia en Anios:"+diferencia.getYears());  
    System.out.println(diferencia.getUnits().toString());  
    System.out.println();
    
    long difEnDias = date.until(newDate,DAYS);
    System.out.println("Diferencia en Dias :"+difEnDias);  
    
    long difEnMeses = date.until(newDate,MONTHS);
    System.out.println("Diferencia en Meses :"+difEnMeses);  

    long difEnAnios = date.until(newDate,YEARS);
    System.out.println("Diferencia en Anios :"+difEnAnios);  
    System.out.println();
  }
}