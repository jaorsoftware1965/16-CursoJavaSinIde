// ---------------------------------
// Curso de Java desde 0 sin IDE
// Clase 25 Fecha y Hora
// ---------------------------------

// LocalDate	        date (year, month, day (yyyy-MM-dd))
// LocalTime	        time (hour, minute, second and nanoseconds (HH-mm-ss-ns))
// LocalDateTime	    date and a time (yyyy-MM-dd-HH-mm-ss-ns)
// DateTimeFormatter	Formatter 

// Importamos las librerias
import java.time.LocalDate; 
import java.time.LocalTime; 
import java.time.LocalDateTime; 
import java.time.format.DateTimeFormatter;

// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
    // Desplegando la Fecha Unicamente
    LocalDate oFecha = LocalDate.now(); 
    System.out.println("Fecha:"); 
    System.out.println(oFecha); 
    System.out.println(); 

    LocalTime oHora = LocalTime.now();
    System.out.println("Hora:"); 
    System.out.println(oHora); 
    System.out.println(); 

    LocalDateTime oFechaHora = LocalDateTime.now();
    System.out.println("Fecha y Hora:"); 
    System.out.println(oFechaHora);
    System.out.println(); 

    // Formateador
    DateTimeFormatter oFormateador = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
    String strFechaHora = oFechaHora.format(oFormateador);
    System.out.println("Fecha y Hora con Formato: " + strFechaHora);

    oFormateador = DateTimeFormatter.ofPattern("yyyy.MM.dd HH.mm.ss");
    strFechaHora = oFechaHora.format(oFormateador);
    System.out.println("Fecha y Hora con Formato: " + strFechaHora);
    
    oFormateador = DateTimeFormatter.ofPattern("yyyy.MM.dd");
    strFechaHora = oFecha.format(oFormateador);
    System.out.println("Fecha con Formato: " + strFechaHora);

    oFormateador = DateTimeFormatter.ofPattern("HH.mm.ss:SSS");
    strFechaHora = oHora.format(oFormateador);
    System.out.println("Hora con Formato: " + strFechaHora);
  }
}