// ---------------------------------
// Curso de Java desde 0 sin IDE
// Clase 15 Sentencia de Ciclo While
// ---------------------------------
 
// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
    // Variable entera
    int i = 0;

    // Ciclo
    while (i < 5) 
    {
       System.out.println(i);
       i++;
    }

    // Dejamos una linea en blanco
    System.out.println();

    // Incializamos
    i = 0;

    // Ciclo 
    do 
    {
      System.out.println(i);
      i++;
    }
    while (i < 5);    // Condición al final    
  }
}