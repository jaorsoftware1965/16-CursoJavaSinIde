// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 63 Archivos Aleatorios Lectura
// -------------------------------------------------------
	
// Librerías
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Despliega
        System.out.println("Clase 63 Archivos Aleatorios Lectura");

		// Declaramos un Objeto de la Clase
        RandomAccessFile xFileAleatorio;
        
        // Variable para leer del Archivo
        String strLinea;

        // Registro a Desplegar
        int    iRegistro=1;

        // Captura de Excepciones 
        try 
        {   
            // Creamos un objeto de la Clase Entrada
            Scanner oEntrada = new Scanner(System.in);            

        	// Leemos el Archivo de Acceso Directo
        	xFileAleatorio = new RandomAccessFile( "Datos.txt","r" );
            
        	// Desplegamos su longitud
        	System.out.println("Longitud del Archivo:"+xFileAleatorio.length());
        	System.out.println("Registros del Archivo:"+xFileAleatorio.length()/23);
        	

            // Ciclo para leer registros
            while (iRegistro!=0)
            {
                // Indique el Registro a Leer
                System.out.print("Registro a Leer (0-Salir):");
                iRegistro = oEntrada.nextInt();

                // Verifica que sea mayor que 0 y menor cantidad
                if (iRegistro>0 && iRegistro<=xFileAleatorio.length()/23)
                {
                    // Nos movemos al principio del Archivo
        	        xFileAleatorio.seek((iRegistro-1) *23);
                    

                    // Leemos una Linea     
                    strLinea=xFileAleatorio.readLine();
                    xFileAleatorio.readLine();
            
                    // Mensaje
                    System.out.println(strLinea);
                    
                    // Verifica activo o borrado
                    if (strLinea.substring(21, 22).equals("*"))                       
                        System.out.println("Borrado");                         	
                    else                    
                        System.out.println("Activo");                    
                }
                else
                   if (iRegistro<=0 || iRegistro>xFileAleatorio.length()/23)
                      System.out.println("Error en Registro");                                    
            }
        	                        
            // Cerramos el fichero
            xFileAleatorio.close();
            
            
		} 
        catch (FileNotFoundException e) 
        {
        	System.out.println("Ocurrió un Error de Not File");
			e.printStackTrace();
		}
        catch (IOException e) 
        {
        	System.out.println("Ocurrió un Error Exception");
    		
			e.printStackTrace();
		}

        // Mensaje Final
        System.out.println("Programa Terminado...");       
    }       
}