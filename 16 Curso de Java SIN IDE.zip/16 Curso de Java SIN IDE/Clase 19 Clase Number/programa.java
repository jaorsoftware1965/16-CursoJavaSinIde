// ---------------------------------
// Curso de Java desde 0 sin IDE
// Clase 19 Clase Number
// ---------------------------------

// Java tiene implementadas clases para los tipos de datos
// Byte, Integer, Short, Long, Double y Float; y todas estas
// Clases derivan de una Clase Principal Llamada Number

// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
    // Declaramos objetos de los Tipos de Datos de Number
    Byte    oByte    = 127;      
    Short   oShort   = 13450;    
    Integer oInteger = 5;        
    Long    oLong    = 12345679l;
    Float   oFloat   = 5.99f;    
    Double  oDouble  = 3.1416d;  
    
    System.out.println("oByte     :" + oByte);
    System.out.println("oShort    :" + oShort);
    System.out.println("oInteger  :" + oInteger);
    System.out.println("oLong     :" + oLong);
    System.out.println("oFloat    :" + oFloat);
    System.out.println("oDouble   :" + oDouble);
    System.out.println("");

    // Métodos de la Clase Number
    System.out.println("oByte.byteValue        :" + oByte.byteValue());
    System.out.println("oShort.shortValue      :" + oShort.byteValue());
    System.out.println("oShort.shortValue      :" + oShort.shortValue());
    System.out.println("oInteger.integerValue  :" + oInteger.intValue());
    System.out.println("oLong.longValue        :" + oLong.longValue());
    System.out.println("oFloat.floatValue      :" + oFloat.floatValue());
    System.out.println("oDouble.doubleValue    :" + oDouble.doubleValue());
    System.out.println("");

    
    System.out.println("oInteger.tocompare()  :" + oInteger.compareTo(10));
    System.out.println("oInteger.tocompare()  :" + oInteger.compareTo(1));
    System.out.println("oInteger.tocompare()  :" + oInteger.compareTo(5));
    // Si son iguales 0
    // Si el entero es menor -1
    // Si el entero es mayor  1
    System.out.println("");

    System.out.println("oInteger.equals()  :" + oInteger.equals(1));
    System.out.println("oInteger.equals()  :" + oInteger.equals(5));
    System.out.println("oInteger.equals()  :" + oInteger.equals(5.0));
    // Si son iguales en valor y tipo true
    // Si no son iguales false
    System.out.println("");

    System.out.println("Integer.valueOf()  :" + Integer.valueOf("14"));
    System.out.println("Double.valueOf()   :" + Double.valueOf(5));
    System.out.println("Float.valueOf()    :" + Float.valueOf("88.50"));
    System.out.println("Integer.valueOf()  :" + Integer.valueOf("13",16));
    System.out.println("");

    System.out.println("oInteger.toString()  :" + oInteger.toString());
    System.out.println("oDouble.toString()   :" + oDouble.toString());
    System.out.println("Integer.equals()     :" + Integer.toString(50));
    // Si son iguales en valor y tipotrue
    // Si no son iguales false
    System.out.println("");

    System.out.println("Integer.parseInt()   :" + Integer.parseInt("13"));
    System.out.println("Double.parseDouble() :" + Double.parseDouble("13.34"));
    System.out.println("Float.parseFloat()   :" + Float.parseFloat("34.56"));
    // Si son iguales en valor y tipotrue
    // Si no son iguales false
    System.out.println("");
  }
}