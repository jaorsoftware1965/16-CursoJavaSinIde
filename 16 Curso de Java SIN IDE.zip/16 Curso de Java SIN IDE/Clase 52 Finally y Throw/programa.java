// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 52 Finally y Throw Excepciones de Usuario
// -------------------------------------------------------

// Cuando se captura una excepción se puede especificar
// una sección de código que se ejecutará cuando la
// instrucción try-catch haya finalizado, utilizando
// la palabra reservada finally

// Es posible generar tus propias excepciones de usuario
// utilizando la palabra reservada throw. Esta se utiliza
// en conjunto con alguna de las excepciones de error que
// ya existen en Java

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Definimos un método que valida la edad
    static void fnValidaEdad(int edad)
    {
       // Verificamos la edad
       if (edad<18)
          // lanzamos una excepción de usuario
          throw new ArithmeticException("Edad no valida");
       else
          System.out.println("Edad verificada:"+edad);
    }

    // Función main que es obligatorio
    public static void main(String args[])
    {        
        // Despliega
        System.out.println("Clase 52 Finally Throw Excepciones de Usuario");           
        
        // Llamamos a la Función
        //fnValidaEdad(19);
        //fnValidaEdad(13);

        // Llamamos a la función
        try 
        {
            // Llamamos a la función que valida edad
            fnValidaEdad(19);
            fnValidaEdad(13);
        } 
        catch (java.lang.ArithmeticException e)
        {
            System.out.println("Error Aritmetico:"+e.getMessage());           
        }
        finally
        {
            System.out.println("Ha finalizado try-catch");           
        }        
        // Mensaje de finalizacion
        System.out.println("Programa Terminado");
    }       
}