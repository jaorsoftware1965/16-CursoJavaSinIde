// ------------------------------------------------
// Curso de Java desde 0 sin Ide
// Clase 97 JSlider 
// ------------------------------------------------

// Librerías
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.event.ChangeListener;  
import javax.swing.event.ChangeEvent;  
import javax.swing.BoxLayout;
import java.awt.Color;

// La Clase Principal
public class programa extends JFrame
{  
    // Propiedades
    JLabel   lblRed;
    JLabel   lblGreen;
    JLabel   lblBlue;
    JSlider  sldRed;
    JSlider  sldGreen;
    JSlider  sldBlue;

    // Constructor
    public programa()
    {
        // Establece el Layout del Frame
        setLayout(new BoxLayout(getContentPane(),BoxLayout.Y_AXIS));

        // Crea las Etiquetas
        lblRed   = new JLabel("Rojo");                    
        lblRed.setHorizontalAlignment(JLabel.RIGHT);    
        
        lblGreen = new JLabel("Verde");                 
        lblGreen.setHorizontalAlignment(JLabel.RIGHT);       
        
        lblBlue  = new JLabel("Azul");                  
        lblBlue.setHorizontalAlignment(JLabel.RIGHT);      
                
        // Los Slider
        sldRed   = new JSlider(JSlider.HORIZONTAL, 0, 255, 238);  
        sldRed.setMinorTickSpacing(2);  
        sldRed.setMajorTickSpacing(10);  
        sldRed.setPaintTicks(true);  
        sldRed.setPaintLabels(true);

        sldGreen = new JSlider(JSlider.HORIZONTAL, 0, 255, 238);  
        sldGreen.setMinorTickSpacing(2);  
        sldGreen.setMajorTickSpacing(10);  
        sldGreen.setPaintTicks(true);  
        sldGreen.setPaintLabels(true);

        sldBlue  = new JSlider(JSlider.HORIZONTAL, 0, 255, 238);  
        sldBlue.setMinorTickSpacing(2);  
        sldBlue.setMajorTickSpacing(10);  
        sldBlue.setPaintTicks(true);  
        sldBlue.setPaintLabels(true);        
        
        // Agregamos las Etiquetas y Spinner's al Frame
        add(lblRed);
        add(sldRed);  
        add(lblGreen);
        add(sldGreen);
        add(lblBlue);
        add(sldBlue);  
        
        // Obtiene el Color
        Color color = getBackground();

        // Obtiene los colores por separado
        int rojo  = color.getRed();
        int verde = color.getGreen();
        int azul  = color.getBlue();

        // Coloca los valores en spinner
        sldRed.setValue(rojo);
        sldGreen.setValue(verde);
        sldBlue.setValue(azul);

        // Captura el Evento del Spinner
        sldRed.addChangeListener(new ChangeListener() 
        {  
            // Evento que se dispara en el Spinner
            public void stateChanged(ChangeEvent e) 
            {  
                // Actualiza el Color
                actualizaColor(); 
            }  
        });  

        sldGreen.addChangeListener(new ChangeListener() 
        {  
            // Evento que se dispara en el Spinner
            public void stateChanged(ChangeEvent e) 
            {  
                // Actualiza el Color
                actualizaColor(); 
            }  
        });  

        // Evento que se dispara en el Spinner
        sldBlue.addChangeListener(new ChangeListener() 
        {  
            public void stateChanged(ChangeEvent e) 
            {  
                // Actualiza el Color
                actualizaColor();      
            }  
        });  

        
    }

    // Actualiza el Color
    private void actualizaColor()
    {
      int rojo;
      int verde;
      int azul;

      // Obtien el Color
      rojo  = sldRed.getValue();
      verde = sldGreen.getValue();
      azul  = sldBlue.getValue();

       // Cambia el Color
       getContentPane().setBackground(new Color(rojo,verde,azul));
    }

    public static void main(String[] args) 
    {    
       // Crea la Ventana y Establece sus características 
       programa ventana = new programa();    
       ventana.setTitle("97 JSlider");
       ventana.setSize(700,250);
       ventana.setLocationRelativeTo(null);
       ventana.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
       ventana.setVisible(true);       
    }  
}

