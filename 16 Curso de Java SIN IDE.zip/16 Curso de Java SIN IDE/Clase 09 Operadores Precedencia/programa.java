// -----------------------------------
// Curso de Java desde 0 sin IDE
// Clase 09 Precedencia de Operadores
// -----------------------------------

// 5 + 4 * 3 = 17

// Operador
// ++ -- (postfijo)
// ++ -- + - ~ ! (prefijo y unarios)
// * / %
// + -
// << >> >>>
// < > <= >= instanceof
// == !=
// &
// ^
// |
// &&
// ||
// ? :
// = += -= *= /= %=
// &= ^= |= <<= >>= 

// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
    int a = 10;
    int b = 5;
    int c = 1;
    int resultado;
    
    // Calcula un resultado
    resultado = a - ++c - ++b;
    //         10 -   2 -   6 = 2
    System.out.println(resultado);
    
    b = 5;
    c = 1;
    resultado = a - ++c * ++b;
    //         10 -   2 *   6 = 10 - 12 = -2
    System.out.println(resultado);

    b = 5;
    c = 1;
    resultado = (a - ++c) / ++b;
    //         (10 -   2) /   6 = 8 / 6 = 1
    System.out.println(resultado);
  }
}