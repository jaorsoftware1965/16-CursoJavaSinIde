// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 68 Uso de Throws
// -------------------------------------------------------

// Librerías
import java.io.IOException;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Definimos un método que valida la edad
    static void fnGrabarArchivo() throws IOException
    {
       System.out.println("Grabando al Archivo");
    }

    // Función main que es obligatorio
    public static void main(String args[]) throws IOException
    {        
        // Despliega
        System.out.println("Clase 68 Throws");           
        
        // Llamamos a la Función
        fnGrabarArchivo();        

        // // Llamamos a la función
        // try 
        // {
        //     // Llamamos a la función que valida edad
        //     fnGrabarArchivo();
        // } 
        // catch (IOException e)
        // {
        //     System.out.println("Error Al grabar:"+e.getMessage());           
        // }
        // finally
        // {
        //     System.out.println("Ha finalizado try-catch");           
        // }

        // // Mensaje de finalizacion
        System.out.println("Programa Terminado");
    }       
}