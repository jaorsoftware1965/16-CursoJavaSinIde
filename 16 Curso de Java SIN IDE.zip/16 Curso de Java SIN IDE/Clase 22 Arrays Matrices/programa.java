// --------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 22 Arrays Multidimensionales; Matrices
// --------------------------------------------

// Un Arreglo mutidimensional es simplemente un arreglo
// que contiene otros arreglos.

// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
    int[][] arrMulti = { {1, 2, 3, 4}, 
                         {5, 6, 7},
                         {8, 9,10,11,12} };

    int[][] matriz   = { {11, 12, 13, 14}, 
                         {21, 22, 23, 24} };
    
    int[][] arrMulti2 = new int[2][4]; 
    
    // Coloco los elementos
    arrMulti2[0][0] = 10;
    arrMulti2[0][1] = 20;
    arrMulti2[0][2] = 30;
    arrMulti2[0][3] = 40;
    
    arrMulti2[1][0] = 50;
    arrMulti2[1][1] = 60;
    arrMulti2[1][2] = 70;
    arrMulti2[1][3] = 80;

    System.out.println("Arreglo Multidimensional");
    for (int i = 0; i < arrMulti.length; ++i) 
    {
      for(int j = 0; j < arrMulti[i].length; ++j) 
      {
        System.out.print(arrMulti[i][j]+" ");
      }
      System.out.println();
    }
    System.out.println();

    System.out.println("Matriz");
    for (int i = 0; i < matriz.length; ++i) 
    {
      for(int j = 0; j < matriz[i].length; ++j) 
      {
        System.out.print(matriz[i][j]+" ");
      }
      System.out.println();
    }
    System.out.println();

    System.out.println("Arreglo Multidimensional 2");
    for (int i = 0; i < arrMulti2.length; ++i) 
    {
      for(int j = 0; j < arrMulti2[i].length; ++j) 
      {
        System.out.print(arrMulti2[i][j]+" ");
      }
      System.out.println();
    }
    System.out.println();


  }
}