// ------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 24 Arrays Métodos
// ------------------------------------

// La Clase Arrays nos proporciona métodos para realizar
// operaciones con los arreglos

// Importamos la librería Arrays
import java.util.Arrays; 

// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
      // Declaramos arreglos de diversos Tipos
      byte   byteArr[]   = {10,20,15,22,35}; 
      char   charArr[]   = {'g','p','q','c','i'}; 
      int    intArr[]    = {10,20,15,22,35}; 
      double doubleArr[] = {10.2,15.1,2.2,3.5}; 
      float  floatArr[]  = {10.2f,15.1f,2.2f,3.5f}; 
      short  shortArr[]  = {10,20,15,22,35}; 

      // Los Ordenamos todos 
      Arrays.sort(byteArr); 
      Arrays.sort(charArr); 
      Arrays.sort(intArr); 
      Arrays.sort(doubleArr); 
      Arrays.sort(floatArr); 
      Arrays.sort(shortArr); 

      // Mostramos el Arreglo de bytes
      System.out.println("Arreglo Byte");
      for (byte xByte: byteArr)
          System.out.print(xByte+" ");
      System.out.println();
      System.out.println();

      // Mostramos el Arreglo de Chars
      System.out.println("Arreglo Char");
      for (char xChar: charArr)
          System.out.print(xChar+" ");
      System.out.println();
      System.out.println();

      // Mostramos el Arreglo de Integers
      System.out.println("Arreglo Integers");
      for (int xInt: intArr)
          System.out.print(xInt+" ");
      System.out.println();
      System.out.println();

      // Mostramos el Arreglo de Doubles
      System.out.println("Arreglo Doubles");
      for (double xDouble: doubleArr)
          System.out.print(xDouble+" ");
      System.out.println();
      System.out.println();

      // Mostramos el Arreglo de Floats
      System.out.println("Arreglo Floats");
      for (float xFloat: floatArr)
          System.out.print(xFloat+" ");
      System.out.println();
      System.out.println();

      // Mostramos el Arreglo de Shorts
      System.out.println("Arreglo Shorts");
      for (short xShort: shortArr)
          System.out.print(xShort+" ");
      System.out.println();
      System.out.println();



      // Definimos variables de cada tipo
      byte   byteKey   = 35; 
      char   charKey   = 'g'; 
      int    intKey    = 22; 
      double doubleKey = 1.5; 
      float  floatKey  = 35.0f; 
      short  shortKey  = 5; 
      

      // Realizamos busquedas de las Llaves
      System.out.println("Busquedas..");
      System.out.println(byteKey + " encontrado en indice = "
                          +Arrays.binarySearch(byteArr,byteKey)); 
      System.out.println(charKey + " encontrado en indice = "
                          +Arrays.binarySearch(charArr,charKey)); 
      System.out.println(intKey + " encontrado en indice = "
                          +Arrays.binarySearch(intArr,intKey)); 
      System.out.println(doubleKey + " encontrado en indice = "
                          +Arrays.binarySearch(doubleArr,doubleKey)); 
      System.out.println(floatKey + " encontrado en indice = "
                          +Arrays.binarySearch(floatArr,floatKey)); 
      System.out.println(shortKey + " encontrado en indice = "
                          +Arrays.binarySearch(shortArr,shortKey));

      System.out.println("");
      // Rellenamos el arreglo de Bytes con un dato especifico
      byte xReemplazo=127;
      Arrays.fill(byteArr,xReemplazo);

      // Mostramos el Arreglod e bytes
      System.out.println("El Vector reemplazado..");
      for (byte xByte: byteArr)
          System.out.print(xByte+" ");
      System.out.println();
      System.out.println();

      // Averigua si es igual
      System.out.println("Verificando Igualdad");
      System.out.println(Arrays.equals(byteArr,byteArr));
      System.out.println("");

      // Convierte a string
      String arrEnString;
      arrEnString = Arrays.toString(byteArr);

      System.out.println("Arreglo en String:"+arrEnString);

  }
}