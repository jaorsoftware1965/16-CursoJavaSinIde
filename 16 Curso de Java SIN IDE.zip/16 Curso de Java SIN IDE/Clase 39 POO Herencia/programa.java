// --------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 39 POO Herencia
// Uso de extends y super
// --------------------------------------------------

// La Herencia es la capacidad de crear una clase e
// indicar que esta hereda Atributos y Métodos de otra
// clase.

// La clase que hereda es llamada subclase o clase hija;
// y la clase de la que se hereda se le llama superclase
// o clase padre

// Para crear una clase e indicar que esta hereda o es 
// hija de otra, se usa la palabra reservada extends y
// posteriormente se indica la superclase o clase padre
// de la cual heredará.

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    { 
        // Creamos un Empleado con el constructor vacio
        empleados oEmpleado0 = new empleados();

        // Desplegamos su informacion
        oEmpleado0.fnImprimeInformacion();
        oEmpleado0.fnImprimeInformacionEmpleado();

        // Creamos un Empleado 
        empleados oEmpleado1 = new empleados("James Paul",
                                             "Liverpool",
                                             'M',
                                             45,
                                             "Contabilidad",
                                             16540);

        // Desplegamos su informacion
        oEmpleado1.fnImprimeInformacionEmpleado();
        
        
        // Creamos un objeto de persona
        personas oPersona = new personas("Benito Bodoque",
                                         "Callejon Bote 5",
                                         'M', 44);

        // Imprimimos la informacion
        oPersona.fnImprimeInformacion();     

        // Creamos un Empleado con el constructor vacio
        empleados oEmpleado3 = new empleados("Jhon Patrick",
                                             "Inglaterra",
                                             'M',
                                             47,
                                             "Sistemas",
                                             19540);

        // Desplegamos su informacion
        oEmpleado3.fnImprimeInformacionEmpleado();

        // Modificamos datos del Empleado 3
        oEmpleado3.setNombre("Oficial Matute");
        oEmpleado3.setDireccion("En un lugar");
        oEmpleado3.setEdad(54);
        oEmpleado3.setGenero('M');
        oEmpleado3.setArea("Sistemas");
        oEmpleado3.setSueldo(34500.90f);        

        // Desplegamos su informacion
        oEmpleado3.fnImprimeInformacionEmpleado();

    }   
}