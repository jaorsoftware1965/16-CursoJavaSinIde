// -----------------------------------------
// Curso de Java desde 0 sin IDE
// Archivo utilizado en Clase programa
// -----------------------------------------
public class empleados extends personas
{
    // Contador de Empleados
    private static int contador = 0;
    
    // Propiedades de la clase
    private int    numero;
    private String area = "General";
    private float  sueldo = 4500;
    
    // Constructor vacio
    empleados()
    {
        // Llama al Constructor de SuperClase
        super();
        // Incrementamos el Contador
        contador++;
        numero = contador;
    }

    // Constructor solicitando todos los datos
    empleados(String nombre, 
              String direccion, 
              char   genero, 
              int    edad,
              String area,
              float  sueldo)
    {
        // Llama al constructor de la superclase
        super(nombre, direccion, genero, edad);

        // Incrementa el contador de Empleados
        contador++;

        // Coloca el dato en el numero
        numero = contador;

        // Valida el area
        if (area.equals("Contabilidad") ||
            area.equals("Sistemas") ||
            area.equals("Ventas") ||
            area.equals("Recursos Humanos")||
            area.equals("Administracion"))
        {
            // Coloca el area   
            this.area = area;
        }
        else
        {
            // Menasje
            System.out.println("El Area no es correcta");
            System.out.println("Queda General\n"); 
        }
        
        // Validamos el Sueldo
        if (sueldo>=4500)
        {            
            // Lo asigna
            this.sueldo = sueldo;
        }
        else
        {
            // Mensaje de error en Sueldo
            System.out.println("Sueldo erroneo");
            System.out.println("Queda como 4500\n");            
        }       
    }
    

    // Imprime la información del Empleado
    void fnImprimeInformacionEmpleado()
    {
        // Imprime la información de la persona
        fnImprimeInformacion();
        System.out.println("Informacion de Empleado");
        System.out.println("Numero :"+numero);
        System.out.println("Area   :"+area);
        System.out.println("Sueldo :"+sueldo+ "\n");
    }

    public int getNumero() {
        return numero;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) 
    {
        // Valida el area
        if (area.equals("Contabilidad") ||
            area.equals("Sistemas") ||
            area.equals("Ventas") ||
            area.equals("Recursos Humanos")||
            area.equals("Administracion"))
        {
            // Coloca el area   
            this.area = area;
        }
        else
        {
            // Mensaje de error en Sueldo
            System.out.println("Area erronea");
            System.out.println("No se ha modificado\n");            
        }
    }

    public float getSueldo() {
        return sueldo;
    }

    public void setSueldo(float sueldo) {
        if (sueldo>=4500)
        {            
            // Lo asigna
            this.sueldo = sueldo;
        }
        else
        {
            // Mensaje de error en Sueldo
            System.out.println("Sueldo erroneo");
            System.out.println("No se ha modificado\n");            
        } 
    }    
}

