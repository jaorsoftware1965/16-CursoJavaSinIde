// -----------------------------------
// Curso de Java desde 0 sin IDE
// Clase 21 Ciclo for para arrays
// ----------------------------------

// El ciclo for nos permite acceder a cada uno de los elementos
// de un arreglo sin hacer uso de sus indices

// for (type variable : arrayname) 
// {
//    ...
// }
 
// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
    // Declaramos un array de Enteros
    int[]    edades = { 23, 34, 56, 78, 60};

    // Declaramos un array de String
    String[] nombres = {"Juan", "Jose", "Maria", "Pedro","Abraham"};
    
    // Variable indice
    int indice;

    // Desplegamos los arreglos
    for (indice=0; indice < edades.length; indice++)
    {
        System.out.println("edad    :" + edades[indice]);
        System.out.println("nombre  :" + nombres[indice]);
        System.out.println("");
    }

    // Desplegamos las edades usando foreach
    for (int edad : edades) 
    {
        // Despliega el Dato
        System.out.println(edad);
    }
    System.out.println("");

    // Desplegamos los nombres usando forecha
    for (String nombre : nombres) 
    {
        // Despliega el Dato
        System.out.println(nombre);
    }
  }
}