// -------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 31 Métodos que retornan Valores
// -------------------------------------

// Una función puede retornar un valor el cual puede
// ser de los diferentes tipos que se han estudiado
// El Tipo de dato que retorna la función se indica
// en la definición de la función
// Para devolver el valor, se utiliza la palabra
// reservada return

// Clase se debe llamar igual que el archivo
public class programa
{
  // Definimos un método dentro de la Clase
  static int fnDobleNumero(int numero)
  {
      // Desplegamos el Mensaje
      return (numero * 2);
  }
 
  // Definimos un método dentro de la Clase
  static int fnSumar(int numero1, int numero2)
  {
      // Desplegamos el Mensaje
      return (numero1 + numero2);
  }

  static boolean fnBoolEsMayor(int numero1, 
                               int numero2)
  {
    if (numero1 > numero2)
       return (true);
    else
       return (false);
       
  }

  static boolean fnBoolEsPar(int numero)
  {
     // Valida y retorna
     return (numero % 2 == 0);
  }
 
  // Función main que es obligatorio
  public static void main(String args[])
  {          
      // Llamamos al Segundo Método
      System.out.println(fnDobleNumero(10));
      System.out.println(fnSumar(10,20));
      System.out.println(fnBoolEsMayor(10,5));
      System.out.println(fnBoolEsMayor(10,20));
      System.out.println(fnBoolEsPar(10));
      System.out.println(fnBoolEsPar(7));
  }   
}