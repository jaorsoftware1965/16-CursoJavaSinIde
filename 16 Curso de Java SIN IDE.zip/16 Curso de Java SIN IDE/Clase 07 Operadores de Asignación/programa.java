// ---------------------------------
// Curso de Java desde 0 sin IDE
// Clase 07 Operadores de Asignación
// ---------------------------------
 
// Los operadores de asignación son formas simplificadas
// de escribir una asignación y una operación al mismo
// tiempo

// Operador	    Ejemplo     Igual que   
// =	          x = 5	
// +=	          x += 3	    x = x + 3	
// -=	          x -= 3	    x = x - 3	
// *=	          x *= 3	    x = x * 3	
// /=	          x /= 3	    x = x / 3	
// %=	          x %= 3	    x = x % 3	
// &=	          x &= 3	    x = x & 3	
// |=	          x |= 3	    x = x | 3	
// ^=	          x ^= 3	    x = x ^ 3	
// >>=	        x >>= 3	    x = x >> 3	
// <<=	        x <<= 3	    x = x << 3

// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
    // Desplegamos un Mensaje en la Pantalla
    int x;
    
    x = 5;
    System.out.print  ("x += 3 : ");
    System.out.println(x += 3);
    
    x = 5;
    System.out.print  ("x -= 3 : ");
    System.out.println(x -= 3);
    
    x = 5;
    System.out.print  ("x *= 3 : ");
    System.out.println(x *= 3);

    x = 5;
    System.out.print  ("x /= 3 : ");
    System.out.println(x /= 3);
    
    x = 5;
    System.out.print  ("x %= 3 : ");
    System.out.println(x %= 3);

    x = 5;
    System.out.print  ("x &= 3 : ");
    System.out.println(x &= 3);

    x = 5;
    System.out.print  ("x |= 3 : ");
    System.out.println(x |= 3);

    x = 5;
    System.out.print  ("x ^= 3 : ");
    System.out.println(x ^= 3);

    x = 5;
    System.out.print  ("x /= 3 : ");
    System.out.println(x /= 3);

    x = 5;
    System.out.print  ("x << 3 : ");
    System.out.println(x << 3);

    x = 5;
    System.out.print  ("x >> 3 : ");
    System.out.println(x >> 3);


  }
}