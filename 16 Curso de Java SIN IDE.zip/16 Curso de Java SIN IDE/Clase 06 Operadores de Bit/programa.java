// ------------------------------
// Curso de Java desde 0 sin IDE
// Clase 06 Operadores de Bit
// -----------------------------

// Operador   Nombre    Ejemplo   En Binario    Res Binario   Res Decimal
// &	        AND 	    5 & 1	    0101 & 0001	  0001	        1
// |	        OR        5 | 1	    0101 | 0001	  0101	        5
// ~	        NOT       ~ 5	     ~0101	        1010	        -6
// ^	        XOR       5 ^ 1	    0101 ^ 0001	  0100	        4
// <<	     left shift   9 << 1	  1001 << 1	   10010	        18
// >>	     right shift  9 >> 1	  1001 >> 1	    0100	        4


// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
    System.out.print("5 & 1   : ");
    System.out.println(5 & 1);
    System.out.print("5 | 1   : ");
    System.out.println(5 | 1);
    System.out.print("~5      : ");
    System.out.println(~5);
    System.out.print("5 ^ 1   : ");
    System.out.println(5 ^ 1);
    System.out.print("9 << 1  : ");
    System.out.println(9 << 1);
    System.out.print("9 >> 1  : ");
    System.out.println(9 >> 1);
  }
}