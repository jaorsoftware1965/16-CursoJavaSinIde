// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 64 Archivos Binarios Lectura y Escritura
// -------------------------------------------------------
	
// Librerías
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Despliega
        System.out.println("Clase 64 Archivps Binarios");

		try
        {
            // Se abre el archivo original para lectura
            FileInputStream fileInput = new FileInputStream("programa.class");
            BufferedInputStream bufferedInput = new BufferedInputStream(fileInput);
 
            // Se abre el archivo destino para escritura
            FileOutputStream fileOutput = new FileOutputStream ("programa2.class");
            BufferedOutputStream bufferedOutput = new BufferedOutputStream(fileOutput);
 
            // Bucle para leer de un archivo y escribir en el otro.
            byte [] array = new byte[1000];
            int leidos = bufferedInput.read(array);
 
            // Contar cuanos bytes lee
			int iCuenta=0;

			// Ciclo 
            while (leidos > 0) 
			{
				// Escribe en el Archivo de Salida
                bufferedOutput.write(array,0,leidos);
				iCuenta+=leidos;				
                leidos=bufferedInput.read(array);
            }

			// Bytes Copiados
			System.out.println("Bytes Leidos y Copiados:"+iCuenta);
 
            // Cierre de los archivo
            bufferedInput.close();
            bufferedOutput.close();

        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }

		       
        // Mensaje Final
        System.out.println("Programa Terminado...");       
    }       
}