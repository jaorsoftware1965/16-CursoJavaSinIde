// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 67 Eliminación de Archivos y Directorios
// -------------------------------------------------------
	
// Librerías
import java.io.File;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Despliega
        System.out.println("Clase 67 Archivos Aleatorios Con Datos Primitivos");

        // Creamos un objeto file
        File myObj = new File("programa.txt"); 
        if (myObj.delete()) 
        {
           System.out.println("Se ha Eliminado el Archivo: " + myObj.getName());
        } 
        else 
        {
           System.out.println("Falla al borrar el Archivo.");
        }
        
        // Creamos un objeto file
        myObj = new File("directorioVacio"); 
        if (myObj.delete()) 
        {
           System.out.println("Se ha Eliminado el Directorio: " + myObj.getName());
        } 
        else 
        {
           System.out.println("Falla al borrar el Directorio.");
        }

        // Mensaje Final
        System.out.println("Programa Terminado...");       
    }       
}