// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 54 Monitoreando Threads Hilos
// -------------------------------------------------------

// Los Métodos resume, pause, destroy y stop han sido 
// depreciados en Java

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
       // Despliega
       System.out.println("Clase 54 Monitoreando Hilos");
       
       // Creando un thread de la tabla del 5
       Contador contador = new Contador();
       contador.start();       
       System.out.println("Id:"+contador.getId()+" Name:"+contador.getName());
       
       // Cuenta segundos
       int iCuentaSegundos=0;

       // Monitoreando
       while (contador.isAlive())
       {                       
           // Incrementa el Contador de Segundos
           iCuentaSegundos++;

           try
           {
              //Espera 1 segundos
              Thread.sleep(1000);
           }

           catch (Exception e) 
           {
              System.out.println("Error Inesperado:"+e.getMessage());           
           }

           // Verifica para pausar
           if (iCuentaSegundos == 5)    
           {
               // Detiene el 5
               contador.pausar();
           }

           // Verifica para detención
           if (iCuentaSegundos == 10)    
           {
               // Reanudar el 5
               contador.reanudar();
           }

           // Verifica para detención
           //if (iCuentaSegundos == 15)    
           //{
           //   // Reanudar el 5
           //   contador.detener();
           //}        
       }

       // El programa finalizara
       System.out.println("Programa Terminado");
    }       
}