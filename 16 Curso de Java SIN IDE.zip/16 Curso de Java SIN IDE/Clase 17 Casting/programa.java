// -----------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 17 Casting Conversión entre tipos de datos
// -----------------------------------------------------

// Casting es cuando tu cambias un tipo de dato por otro
// En Java hay 2 tipos

// Automatico - Cuando conviertes de un tipo menor a uno mayor
// byte -> short -> char -> int -> long -> float -> double

// Manual - Cuanto conviertes de un tipo mayor a menor
// double -> float -> long -> int -> char -> short -> byte

// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
    // Ejemplo de automático
    int    xInt    = 9;
    double xDouble = xInt; // Automaticamente cambia double

    // Comprobamos
    System.out.println(xInt);      // Salida 9
    System.out.println(xDouble);   // Salida 9.0

    // Ejemplode manual
    xDouble = 9.78;
    xInt =  xDouble;           // Casting Manual de double to int

    System.out.println(xDouble);   // Salida 9.78
    System.out.println(xInt);      // Salida 9
  }
}