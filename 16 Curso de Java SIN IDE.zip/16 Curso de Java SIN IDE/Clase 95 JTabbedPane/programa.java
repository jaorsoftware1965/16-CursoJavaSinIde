// ------------------------------------------------
// Curso de Java desde 0 sin Ide
// Clase 95 JTabbedPaned
// ------------------------------------------------

// Librerías
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import java.awt.FlowLayout;

// Clase Principal
class programa extends JFrame 
{
    // Propiedades
    JTabbedPane            tabGeneral;
    panelCursos            pnlCursos;
    panelSeleccionarCursos pnlSeleccionar;

    // Constructor
    programa() 
    {        
        // Setting the JTabbedPane Position and Layout as Wrap
        tabGeneral = new JTabbedPane(JTabbedPane.TOP, JTabbedPane.WRAP_TAB_LAYOUT);
        //tabGeneral = new JTabbedPane(JTabbedPane.TOP,JTabbedPane.SCROLL_TAB_LAYOUT);
        //tabGeneral = new JTabbedPane(JTabbedPane.LEFT,JTabbedPane.SCROLL_TAB_LAYOUT);
        
        // Crea el panel de Cursos y el de Seleccionar
        pnlCursos      = new panelCursos();
        pnlSeleccionar = new panelSeleccionarCursos();

        // Añado los paneles al tabPanned
        tabGeneral.addTab("Cursos"   , pnlCursos);
        tabGeneral.addTab("Lenguajes", pnlSeleccionar);
        
        // Añade las demás pestañas
        tabGeneral.addTab("Listados"   , new JPanel());
        tabGeneral.addTab("Comentario" , new JTextArea(10, 40));
        tabGeneral.addTab("Registro"   , new JPanel());
        tabGeneral.addTab("Contactanos", new JPanel());
        tabGeneral.addTab("Mas .."     , new JPanel());
        
        // Añade el tabPanned
        getContentPane().add(tabGeneral);
    }
    public static void main(String args[]) throws Exception 
    {
        // Crea la ventana
        programa ventana = new programa();

        // Establece las Caracteristicas de la Ventana
        ventana.setTitle("95 JTabbedPane");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);        
        ventana.setSize(400, 400);
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);
    }
}

/*Creating panelCursos by extending JPanel*/
class panelCursos extends JPanel 
{
    // Propiedades de la Clase
    JButton btnInsertarCurso;
    JButton btnLimpiar;

    // Constructor
    panelCursos() 
    {
        // Creamos los 2 botones
        btnInsertarCurso = new JButton("Agregar Curso");
        btnLimpiar = new JButton("Limpiar");

        // Establecemos FlowLayot
        setLayout(new FlowLayout());

        // Insertamos los 2 botones
        add(btnInsertarCurso);
        add(btnLimpiar);
    }
}

/* Panel para Seleccionar Cursos */
class panelSeleccionarCursos extends JPanel 
{
    // Propiedades de la Clase
    JCheckBox lenguajeJava;
    JCheckBox lenguajeC;
    JCheckBox lenguajePhp;

    // Constructor
    panelSeleccionarCursos() 
    {
        // Se crean los CheckBox
        lenguajeJava = new JCheckBox("Java");
        lenguajeC    = new JCheckBox("C");
        lenguajePhp  = new JCheckBox("Php");

        // Establece el Layout
        setLayout(new FlowLayout());

        // Agrega los checkbox al panel
        add(lenguajeJava);
        add(lenguajeC);
        add(lenguajePhp);
    }    
}