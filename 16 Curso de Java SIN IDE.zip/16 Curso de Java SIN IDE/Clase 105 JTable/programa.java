// ------------------------------------------------------
// Curso de Java desde 0 sin Ide
// Clase 105 JTable
// ------------------------------------------------------

// Librerias
import javax.swing.JFrame;    
import javax.swing.ListSelectionModel; 
import javax.swing.JScrollPane;          
import java.awt.event.ActionListener;  
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane; 
import javax.swing.JSplitPane;
import javax.swing.JPanel;
import javax.swing.JButton;

import javax.swing.JTable; 
import javax.swing.table.DefaultTableModel;
import javax.swing.event.ListSelectionEvent;  
import javax.swing.event.ListSelectionListener;


// Extiende de la Clase Principal
public class programa extends JFrame implements ActionListener
{    
    // Propiedades

    // Constantes
    final int COL_REN = 0;
    final int COL_NOM = 1;
    final int COL_SAL = 2;

    // Objetos
    JSplitPane  pnlDivisor;
    JTable      tblDatos;
    JPanel      pnlBotones;
    JScrollPane pnlDatos;
    JButton     btnInsertar;
    JButton     btnEliminar;
    JButton     btnModificar;
    JButton     btnBuscar;
    JButton     btnLimpiar;
    DefaultTableModel modelo;

    // Constructor
    public programa()
    {
        // Vector para los datos
        Object data[][]={ {"1","Amanda","670000"},    
                          {"2","Javier","780000"},    
                          {"3","Saalvador","700000"}};    

        // Vector de las Columnas                  
        Object column[]={"Renglon","Nombre","Salario"};         
        
        // Tabla de Datos    
        tblDatos = new JTable(new DefaultTableModel(data, column));

        // Establece que se pueden seleccionar
        tblDatos.setCellSelectionEnabled(true);  

        // Obtiene el Modelo
        ListSelectionModel select= tblDatos.getSelectionModel(); 

        // Establece el Modo de Selección
        select.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);  
        
        // Controla el Evento de Click en la Tabla
        select.addListSelectionListener(new ListSelectionListener() 
        {  
            // Evento de que valor cambio
            public void valueChanged(ListSelectionEvent e) 
            {  
                String dato;
                int renglon = tblDatos.getSelectedRow();
                int columna = tblDatos.getSelectedColumn();

                // Verifica que sea positivo
                if (renglon >- 1)
                {
                   // Obtiene el dato
                   dato = tblDatos.getValueAt(renglon, columna).toString();

                   // Muestra el dato seleccionado
                   JOptionPane.showMessageDialog(null, 
                                              "Seleccionaste:\n" +
                                               dato,
                                               "Java desde 0 sin Ide", 
                                               JOptionPane.OK_OPTION);                
                }
            }       
        });

        // Crea el Panel para la Tabla de Datos    
        pnlDatos = new JScrollPane(tblDatos);          

        // crea el Panel de los Botones
        pnlBotones = new JPanel();

        // Crea los Botones
        btnInsertar  = new JButton("Insertar");
        btnModificar = new JButton("Modificar");
        btnEliminar  = new JButton("Eliminar");
        btnBuscar    = new JButton("Buscar");
        btnLimpiar   = new JButton("Limpiar");

        // Eventos
        btnInsertar.addActionListener(this);
        btnModificar.addActionListener(this);
        btnEliminar.addActionListener(this);
        btnBuscar.addActionListener(this);
        btnLimpiar.addActionListener(this);
        
        // Añade los Botones al panel
        pnlBotones.add(btnInsertar);
        pnlBotones.add(btnModificar);
        pnlBotones.add(btnEliminar);
        pnlBotones.add(btnBuscar);
        pnlBotones.add(btnLimpiar);

        // Split Pane Principal
        pnlDivisor = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                                    pnlDatos,
                                    pnlBotones);

        // Establece tamaño del Divisor                            
        pnlDivisor.setDividerSize(10);
        
        // Altura del Area Superior
        pnlDivisor.setDividerLocation(315);        

        // Obtenemos pnlDivisor
        add(pnlDivisor);          
    }

    // Método para controlar los Eventos Action de los Objetos
    public void actionPerformed(ActionEvent e) 
    {

        // Verificamos si es el boton de Insertar
        if (e.getSource()==btnInsertar) 
        {
            // Deshabilita el Boton
            btnInsertar.setEnabled(false);

            // Variable con los datos a Insertar
            String[] nvaFila = new String[3];
            String fila;

            // Coloca datos
            fila = String.valueOf(tblDatos.getRowCount()+1);
            nvaFila[COL_REN] = fila;
            nvaFila[COL_NOM] = "Nombre Agregado "+ fila;
            nvaFila[COL_SAL] = "34500"+fila;
            
            // Inserta en la tabla
            modelo = (DefaultTableModel) tblDatos.getModel();
            modelo.addRow(nvaFila);            

            // Deshabilita el Boton
            btnInsertar.setEnabled(true);
        }
        else
        // Verificamos que objeto hizo el evento
        if (e.getSource()==btnModificar) 
        {
            // Deshabilita el Boton
            btnModificar.setEnabled(false);

            // Obtiene Seleccionado
            int renglon = tblDatos.getSelectedRow();
            int columna = tblDatos.getSelectedColumn();

            // Verifica que sea positivo
            if (renglon >- 1)
            {
                String dato;
                dato = JOptionPane.showInputDialog("Capture el Dato para Modificar");
                
                // Modifica la celda
                modelo = (DefaultTableModel) tblDatos.getModel();
                modelo.setValueAt(dato, renglon, columna);
            }
            else
                // Mensaje
                JOptionPane.showMessageDialog(this, 
                                            "Seleccione una Celda", 
                                            "Java desde 0 sin Ide", 
                                            JOptionPane.OK_OPTION);            
            
            // Habilita el Boton
            btnModificar.setEnabled(true);            
        }
        else
        if (e.getSource()==btnEliminar) 
        {
            // Deshabilita el Boton
            btnEliminar.setEnabled(false); 

            // Obtiene el Renglon a eliminar
            int renglon = tblDatos.getSelectedRow();

            // Verifica 
            if (renglon>-1)
            {
                // Elimina
                modelo = (DefaultTableModel) tblDatos.getModel();
                modelo.removeRow(renglon);
            }
            else
                // Mensaje
                JOptionPane.showMessageDialog(this, 
                                              "Seleccione para eliminar el Renglon", 
                                              "Java desde 0 sin Ide", 
                                              JOptionPane.OK_OPTION);            
       
            // Habilita el Boton
            btnEliminar.setEnabled(true);            
        }

        // El Boton de Buscar
        if (e.getSource()==btnBuscar) 
        {
            // Deshabilita el Boton
            btnBuscar.setEnabled(false);

            // La variable para el dato
            String dato;
            boolean encontrado = false;
            int ren=0;
            int col=0;
            
            String datoBuscar;
            datoBuscar = JOptionPane.showInputDialog("Capture el Dato a Buscar--->");


            // Obtiene el Modelo
            modelo = (DefaultTableModel) tblDatos.getModel();

            for (ren = 0; ren < modelo.getRowCount(); ren++)               
            {
                for (col = 0; col < modelo.getColumnCount(); col++) 
                {  
                   // Obtiene el Dato
                   dato = tblDatos.getValueAt(ren, col).toString();  

                   // Compara
                   if (dato.equals(datoBuscar))
                   {
                       // Cambia el Resultado
                       encontrado = true;
                       
                       // Sale del Ciclo
                       break;
                   }
                } 
                // Verifica si lo encontró para salir
                if (encontrado)
                    break;             
            }

            if (encontrado)               
                // Mensaje
                JOptionPane.showMessageDialog(this, 
                "El dato fue encontrado en la celda\n"+
                "Ren:"+String.valueOf(ren)+", Col:"+String.valueOf(col), 
                "Java desde 0 sin Ide", 
                JOptionPane.OK_OPTION);                           
            else
                // Mensaje
                JOptionPane.showMessageDialog(this, 
                "El dato NO fue encontrado ", 
                "Java desde 0 sin Ide", 
                JOptionPane.OK_OPTION); 

            // Habilita el Boton
            btnBuscar.setEnabled(true);            
        }

        // Limpiar
        if (e.getSource()==btnLimpiar) 
        {
            // Deshabilita el Boton
            btnLimpiar.setEnabled(false);            

            // Obtiene el Modelo
            modelo = (DefaultTableModel) tblDatos.getModel();
            modelo.setRowCount(0);
            
            // Habilita el Boton
            btnLimpiar.setEnabled(true);            
        }
    }

    public static void main(String[] a) 
    {  
        // Cre la Ventana
        programa ventana = new programa();

        // Establece las caracteristicas de la Ventana
        ventana.setTitle("105 JTable");
        ventana.setSize(600, 400);  
        ventana.setVisible(true);  
        ventana.setLocationRelativeTo(null);   
        ventana.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }  
} 
