// -----------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 34 POO Clases y Objetos
// -----------------------------------------

// Una Clase es como un manual para construir
// algo; y ese algo es el Objeto.

// Ejemplo:
// Un Manual para Construir un Auto    = Clase
// El Auto construido usando el manual = Objeto

// Las Clases tienen Atributos (Variables) y
// Métodos (Funciones)

class auto
{
    // Propiedades
    String marca="ford";
    
    // Métodos
    void fnImprimeMarca()
    {
        System.out.println("Marca:"+marca);
    }
}

// Clase se debe llamar igual que el archivo
public class programa
{ 
    // Propiedad
    int valor;

    // Definimos un método dentro de la Clase
    void fnImprimeValor()
    {
      // Imprime mensaje
      System.out.println("Valor:"+valor);    
    }     

  
    // Función main que es obligatorio
    public static void main(String args[])
    { 
        // Creamos un objeto
        programa xObjeto = new programa();         

        // HAcemos uso de las propiedades
        xObjeto.valor = 10;

        // Imprimimos el Objeto
        xObjeto.fnImprimeValor();      

        // Creamos un objeto de la clase auto
        auto xAuto = new auto();
        xAuto.marca ="Totoya";
        xAuto.fnImprimeMarca();

        // Creamos un objeto de bicicleta
        bicicleta xBicicleta = new bicicleta();
        xBicicleta.marca="GEnerica";
        xBicicleta.fnImprimeMarca();

    }   
}