// -----------------------------------------
// Curso de Java desde 0 sin IDE
// Archivo utilizado en Clase programa
// -----------------------------------------
public class bicicleta
{
    // Propiedades
    String marca="benoto";
    
    // Métodos
    void fnImprimeMarca()
    {
        System.out.println("Marca:"+marca);
    }
}

