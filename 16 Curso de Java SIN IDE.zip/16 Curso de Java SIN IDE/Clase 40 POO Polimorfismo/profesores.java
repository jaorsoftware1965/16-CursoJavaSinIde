// -----------------------------------------
// Curso de Java desde 0 sin IDE
// Archivo utilizado en Clase programa
// -----------------------------------------
public class profesores extends empleados
{
    // Contador de Estudiantes
    private static int contador = 0;
    
    // Propiedades de la clase
    private String carrera  = "Sistemas";
    private char   turno    = 'M';
    
    public profesores() 
    {
    }

    public profesores(String carrera, char turno) {
        this.carrera = carrera;
        this.turno = turno;
    }

    public profesores(String carrera) {
        this.carrera = carrera;
    }

    public static int getContador() {
        return contador;
    }

    public static void setContador(int contador) {
        profesores.contador = contador;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public char getTurno() {
        return turno;
    }

    public void setTurno(char turno) {
        this.turno = turno;
    }

    
}

