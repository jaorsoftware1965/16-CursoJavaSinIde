// -----------------------------------------
// Curso de Java desde 0 sin IDE
// Archivo utilizado en Clase programa
// -----------------------------------------
public class estudiantes extends personas
{
    // Contador de Estudiantes
    private static int contador = 0;
    
    // Propiedades de la clase
    private int    numero;
    private String carrera  = "Sistemas";
    private int    semestre = 1;
    
    // Constructor vacio
    estudiantes()
    {
        // Llama al Constructor de SuperClase
        super();
        // Incrementamos el Contador
        contador++;
        numero = contador;
    }

    // Constructor solicitando todos los datos
    estudiantes(String nombre, 
                String direccion, 
                char   genero, 
                int    edad,
                String carrera,
                int    semestre)
    {
        // Llama al constructor de la superclase
        super(nombre, direccion, genero, edad);

        // Incrementa el contador de Empleados
        contador++;

        // Coloca el dato en el numero
        numero = contador;

        // Valida la carrera
        if (carrera.equals("Contabilidad") ||
            carrera.equals("Sistemas") ||
            carrera.equals("Leyes") ||
            carrera.equals("Medicina")||
            carrera.equals("Administracion"))
        {
            // Coloca la carrera   
            this.carrera = carrera;
        }
        else
        {
            // Menasje
            System.out.println("La Carrera no es correcta");
            System.out.println("Queda Sistemas\n"); 
        }
        
        // Validamos el Semestre
        if (semestre >= 1 && semestre <=8)
        {            
            // Lo asigna
            this.semestre = semestre;
        }
        else
        {
            // Mensaje de error en Semestre
            System.out.println("Semestre erroneo");
            System.out.println("Queda como 1\n");            
        }       
    }
    

    // Imprime la información del Empleado
    public void fnImprimeInformacion()
    {
        // Imprime la información de la persona        
        System.out.println("Informacion de Estudiante");
        System.out.println("Nombre    :"+getNombre());
        System.out.println("Direccion :"+getDireccion());
        System.out.println("Edad      :"+getEdad());
        System.out.println("Genero    :"+getGenero());
        System.out.println("Indice    :"+getIndice());
        System.out.println("Contador  :"+getContador());
        System.out.println("Numero    :"+numero);
        System.out.println("Carrera   :"+carrera);
        System.out.println("Semestre  :"+semestre+ "\n");
    }

    public int getNumero() {
        return numero;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) 
    {
        // Valida la carrera
        if (carrera.equals("Contabilidad") ||
            carrera.equals("Sistemas") ||
            carrera.equals("Leyes") ||
            carrera.equals("Medicina")||
            carrera.equals("Administracion"))
        {
            // Coloca carrera
            this.carrera = carrera;
        }
        else
        {
            // Mensaje de error en Carrera
            System.out.println("Carrera erronea");
            System.out.println("No se ha modificado\n");            
        }
    }

    public int getSemestre() {
        return semestre;
    }

    public void setSemestre(int semestre) {
        if (semestre >=1 && semestre <=8)
        {            
            // Lo asigna
            this.semestre = semestre;
        }
        else
        {
            // Mensaje de error en Semestre
            System.out.println("Semestre erroneo");
            System.out.println("No se ha modificado\n");            
        } 
    }    
}

