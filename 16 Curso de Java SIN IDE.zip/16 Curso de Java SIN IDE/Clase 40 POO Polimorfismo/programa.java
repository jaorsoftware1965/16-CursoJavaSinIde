// --------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 40 POO Polimorfismo
// --------------------------------------------------

// El Polimorfismo es la capacidad de sobrecargar métodos
// en SuperClases y SubClases; es decir; que el nombre
// del Método es el mismo en la Super Clase y en la
// SubClase. JAOR


// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    { 
        // Creamos un objeto de persona
        personas oPersona = new personas("Benito Bodoque",
                                         "Callejon Bote 5",
                                         'M', 44);

        // Imprimimos la informacion
        oPersona.fnImprimeInformacion();     

        // Creamos un Empleado
        empleados oEmpleado = new empleados("Vicente Fernandez",
                                            "En su Rancho",
                                             'M',65,"Contabilidad",
                                             34567);

        // Desplegamos su informacion
        oEmpleado.fnImprimeInformacion();

        // Creamos un Estudiante
        estudiantes oEstudiante = new estudiantes("Pepito",
                                                  "Los cuentos",
                                                  'M',25,"Leyes",
                                                  3);

        // Imprime Informacion
        oEstudiante.fnImprimeInformacion();                                             

        //empleados x = new personas();
        personas  oPersonaComoEmpleado = new empleados("Maria Morales",
                                                       "En su Casa",
                                                       'F',75,
                                                       "Ventas",
                                                       4567);

        // Imprime la información
        oPersonaComoEmpleado.fnImprimeInformacion();


    }   
}