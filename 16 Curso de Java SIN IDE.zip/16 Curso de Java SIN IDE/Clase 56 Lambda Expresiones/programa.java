// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 56 Expresiones Lambda
// -------------------------------------------------------

// Las expresiones lambda fueron añadidas en Java 8
// Una expresión lambda es un bloque de código corto, el
// cual toma parametros de entrada y devuelve diversos
// valores de retorno

// La sintaxis es:
// parameter -> expresion
// (parametro1, parametro2) -> expresion

// Las expresiones son limitadas, tienen que devolver valores
// inmediatamente, no pueden contener variables, asignaciones
// o instrucciones como if o ciclos for

// Importamos la libreria de ArrayList
import java.util.ArrayList;
import java.util.function.Consumer;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
       // Despliega
       System.out.println("Clase 56 Expresiones Lambda");

       // Creamos un ArrayList de Numeros
       ArrayList<Integer> numeros = new ArrayList<Integer>();

       // Agregamos datos
       numeros.add(5);
       numeros.add(9);
       numeros.add(8);
       numeros.add(1);

       // Usamos una expresion lambda para imprimirlos
       System.out.println("Impresion con Lambda");
       numeros.forEach
       ( 
           // Numero tomara cada valor de numeros
           (numero) -> 
           { 
              // Imprime el Numero
              System.out.println(numero); 
           } 
       );  // Todo esto se ejecuta en una instrucción
       System.out.println("");

       Consumer<Integer> metodoConsumidor = (numero) -> 
       { 
           System.out.println(numero); 
       };
       System.out.println("Impresion con Lambda Metodo Consumidor");
       numeros.forEach(metodoConsumidor);
    }       
}