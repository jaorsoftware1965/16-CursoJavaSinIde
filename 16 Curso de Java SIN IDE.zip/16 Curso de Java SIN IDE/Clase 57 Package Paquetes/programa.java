// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 57 Package Paquetes
// -------------------------------------------------------

// La definición de un paquete se hace con la instrucción
// "package" la cual debe estar al inicio del
// archivo de la Clase.

// El nombre del paquete, debe corresponder a su ubicación
// en el directorio del proyecto; es decir; el directorio
// en el que se encuentra. Para distinguir un directorio 
// de otro se utiliza el "."

// Para poder utilizar las clases de un paquete, se utiliza
// la instruccion "import".

// Se pueden importar todas las clase de un paquete utlizando
// el caracter *; o se se puede especificar exactamente la
// que se necesite

// Importa todas las funciones
//import funciones.*;

// Importa las funciones
import funciones.Matematicas;
import funciones.Mensajes;

// Importamos base de datos
import funciones.basedatos.Conexion;


// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Despliega
        System.out.println("Clase 57 Packages Paquetes");

        // Verifica si un numero es par
        if (Matematicas.esPar(5))
           System.out.println("El 5 es par");
        else
           System.out.println("El 5 no es par");

        // Verifica si un numero es par
        System.out.println("El Doble de 5 :"+Matematicas.doble(5));
        System.out.println("Suma 5 + 8 :"+Matematicas.suma(5,8));
        System.out.println("");

        // Mensajes
        Mensajes.hola("JAOR");
        Mensajes.advertencia("Sistema ContaPlus 1.10","Debes realizar el cierre de Mes");
        System.out.println("");

        // Creamos un objeto de Conexion
        Conexion conn = new Conexion("Host","User","Pass","BaseDatos");

        // Intentamos conectar
        if (conn.Conectar())
           System.out.println("Conexion Relizada");
        else
           System.out.println(conn.getError());
    }       
}