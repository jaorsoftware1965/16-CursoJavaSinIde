// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase Mensajes
// -------------------------------------------------------

// Defino el Paquete
package funciones;

// Clase se debe llamar igual que el archivo
public class Mensajes
{   
    // Saludo
    public static void hola(String usuario)       
    {
        System.out.println("Hola "+usuario);
    }

    // Saludo
    public static void advertencia(String sistema,
                                   String mensaje)       
    {
        // Despliega el Sistema y el mensaje
        System.out.println(sistema);
        System.out.println(mensaje);
    }
}