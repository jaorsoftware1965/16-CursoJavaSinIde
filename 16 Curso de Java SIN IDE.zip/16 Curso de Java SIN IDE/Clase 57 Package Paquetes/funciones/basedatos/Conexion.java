// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase Conexion
// -------------------------------------------------------

// Defino el Paquete
package funciones.basedatos;


// Clase se debe llamar igual que el archivo
public class Conexion
{   
    // Para mensaje de Error
    private String error="";

    // Doble de un Numero
    public Conexion(String host, 
                    String user,
                    String pass,
                    String baseDatos)       
    {
        // Mensaje
        System.out.println("Conexion Preparada");
    }

    // Intenta conectar
    public boolean Conectar()
    {
        // Colocamos un mensaje de error
        error = "Error: Local Host rechazo conexion";
        return false;
    }

    // Getter de Error
    public String getError()
    {
        // Retornamos el Error
        return error;
    }    
}