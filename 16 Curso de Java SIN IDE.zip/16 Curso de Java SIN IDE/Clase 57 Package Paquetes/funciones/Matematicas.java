// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase Matematicas
// -------------------------------------------------------

// Defino el Paquete
package funciones;

// Clase se debe llamar igual que el archivo
public class Matematicas
{   
    // Doble de un Numero
    public static int doble(int x)       
    {
        return (x*2);
    }
    
    // Suma 2 enteros
    public static int suma(int x, int y)       
    {
        return (x+y);
    }

    // Verifica si es par
    public static boolean esPar(int x)
    {
        // Realiza la operación
        return x % 2==0;
    }

}