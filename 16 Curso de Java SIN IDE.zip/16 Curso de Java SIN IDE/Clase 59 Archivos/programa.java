// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 59 Archivos
// -------------------------------------------------------

// Librerías
import java.io.File;
import java.io.IOException;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Despliega
        System.out.println("Clase 59 Archivos");

        // Creamos un Archivo
		File fPrueba = new File("src");
		
		// Desplegamos la información del Archivo que proporciona la Clase
		System.out.println("pathSeparator: "+File.pathSeparator);		
		System.out.println("pathSeparatorChar: "+File.pathSeparatorChar);
		System.out.println("separator: "+File.separator);
		System.out.println("separatorChar: "+File.separatorChar);

        try 
		{
			System.out.println("canRead():"+fPrueba.canRead());
			System.out.println("canWrite():"+fPrueba.canWrite());
			System.out.println("exists():"+fPrueba.exists());
			System.out.println("getAbsolutePath():"+fPrueba.getAbsolutePath());
			System.out.println("getCanonicalPath():"+fPrueba.getCanonicalPath());
			System.out.println("getName():"+fPrueba.getName());
			System.out.println("getParent():"+fPrueba.getParent());
			System.out.println("getPath():"+fPrueba.getPath());
			System.out.println("hashCode():"+fPrueba.hashCode());
			System.out.println("isAbsolute():"+	fPrueba.isAbsolute());
			System.out.println("isDirectory():"+fPrueba.isDirectory());
			System.out.println("isFile():"+fPrueba.isFile());
			System.out.println("lastModified():"+fPrueba.lastModified());
			System.out.println("length():"+fPrueba.length());
		} 
		// Captura el Error de Entrada y Salida (Input-Output)
		catch (IOException e) 
		{
			System.out.println(e); 
		}
       
        // Mensaje Final
        System.out.println("Programa Terminado...");       
    }       
}