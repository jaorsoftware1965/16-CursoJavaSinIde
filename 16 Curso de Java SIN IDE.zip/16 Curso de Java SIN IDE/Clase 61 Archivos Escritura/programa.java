// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 61 Archivos Escritura
// -------------------------------------------------------

// En esta clase veremos como poder realizar la Escritura 
// de un Archivo de  Texto.
		
// Utilizaremos la Clase FileWriter, que es la contraparte 
// de la Clase FileReader utilizada para leer archivos.
		
// Utilizaremos la Clase BufferedWriter; contraparte de 
// BufferedReader; la cual está  diseñada específicamente 
// para realizar escrituras en un archivo de Texto; y una
// clase adicional llamada PrintWriter la cual nos permite 
// grabar en el archivo  utilizando la función tradicional 
// println.	

// Librerías
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;


// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Despliega
        System.out.println("Clase 61 Archivos Escritura");

		try 
		{
			// Variables para grabar en el Archivo
			int    xInt    = 345;
			char   xChar   = 'X';
			float  xFloat  = 454123.56f;
			double xDouble = 456.34343;
			
			// Variable para poder escribir en un Archivo
			// Agregar true para append
			FileWriter xFile = new FileWriter("Salida.txt",true);
						
			// Creamos el objeto para el Buffer de Escritura
			BufferedWriter xEscritor = new BufferedWriter(xFile);
			
			// Mensaje
			System.out.println("Grabando el Archivo Salida.txt");
			
			// Grabamos al Archivo
			xEscritor.write("Primera Línea 1 del Archivo\n");
			xEscritor.write("Segunda Línea 2 del Archivo\n");
			
			// Grabamos las Variables
			xEscritor.write(xInt);
			xEscritor.newLine();
			xEscritor.write(xChar);
			xEscritor.newLine();	
							

			// Crea un PrintWrite para poder usar print
			PrintWriter xPrintWriter = new PrintWriter(xEscritor);
			
			// Grabamos todo de Nuevo
			xPrintWriter.println("Tercera Línea");
            xPrintWriter.println(xInt);
            xPrintWriter.println(xChar);
            xPrintWriter.println(xFloat);
            xPrintWriter.println(xDouble);
             

			// Mensaje de Cierre
			System.out.println("Se ha finalizado de grabar");

			// Cierra el Print, Escritor y Archivo
			xPrintWriter.close();
			xEscritor.close();			
			xFile.close();
						
		}
		catch(java.io.IOException ioex) 
		{ 
			// Despliega el Error
			System.out.println(ioex.getMessage());			
		}
        
       
        // Mensaje Final
        System.out.println("Programa Terminado...");       
    }       
}