// --------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 23 Arrays 3 Dimensiones
// --------------------------------------------

// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
    int[][][] arrMulti = { { 
                             {1, 2}, 
                             {3, 4, 5},
                             {6 }
                           },
                           {
                             {7, 8}, 
                             {9, 14, 17},
                             {8 }
                           },
                         };

    System.out.println("Arreglo Multidimensional");
    for (int i = 0; i < arrMulti.length; ++i) 
    {
      for(int j = 0; j < arrMulti[i].length; ++j) 
      {
        for(int k = 0; k < arrMulti[i][j].length; ++k) 
        {
           System.out.print("["+i+"]["+j+"]["+k+"] ");
           System.out.print(arrMulti[i][j][k]+" ");
        }
        System.out.println();
      }
      System.out.println();
    }
    System.out.println();


    int[][][] arrMulti2 = new int[2][3][4];                     

    arrMulti2[0][1][2]=123;

    System.out.println("Arreglo Multidimensional Cuadrado");
    for (int i = 0; i < arrMulti2.length; ++i) 
    {
      for(int j = 0; j < arrMulti2[i].length; ++j) 
      {
        for(int k = 0; k < arrMulti2[i][j].length; ++k) 
        {
           System.out.print("["+i+"]["+j+"]["+k+"] ");
           System.out.print(arrMulti2[i][j][k]+" ");
        }
        System.out.println();
      }
      System.out.println();
    }
    System.out.println();

    


  }
}