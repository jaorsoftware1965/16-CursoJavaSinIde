// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 51 Excepciones
// -------------------------------------------------------

// En elaboración de un programa, puede ocurrir distintos
// errores.

// Cuando un error ocurre, Java detiene su ejecución y 
// genera y despliega un mensaje de error; en terminos
// técnicos "throw an exception"; lanza una excepcion

// La instruccion try-catch permite definir una sección
// de código que se ejecutará cuando una excepción ocurra
// y de esta forma impedir que el programa se detenga
// abruptamente



// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Definimos un vector
        int[] numeros = {1, 2, 3};

        // Definimos una variable
        int valor=10;

        // Despliega
        System.out.println("Clase 51 Excepciones");

        // Intentamos dividir entre 0
        //valor = valor / 0;
        //valor = numeros[5];

        try 
        {
          //valor = valor / 0;
          valor = numeros[5];
        } 
        catch (java.lang.ArithmeticException e)
        {
            System.out.println("Error Aritmetico:"+e.getMessage());           
        }
        catch (java.lang.ArrayIndexOutOfBoundsException e)
        {
            System.out.println("Error en Indices:"+e.getMessage());           
        }
         
        catch (Exception e) 
        {
            System.out.println("Error Inesperado:"+e.getMessage());           
        }     
        
        // Mensaje de finalizacion
        System.out.println("Programa Terminado");
    }       
}