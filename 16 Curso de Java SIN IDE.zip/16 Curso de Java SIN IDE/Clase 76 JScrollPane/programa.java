// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 76 JScrollPane Font Insets setMargin select
// -------------------------------------------------------

// Librería para swing
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import java.awt.Insets;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


// Clase se debe llamar igual que el archivo
public class programa extends JFrame implements ActionListener,
                                                KeyListener
{   
    // Creamos los objetos
    private JLabel      lblLineas;    
    private JTextField  txtLineas;
    private JLabel      lblCaracteres;    
    private JTextField  txtCaracteres;
    private JTextField  txtBuscar;
    private JButton     btnBuscar;
    private JButton     btnBorrar;
    private JTextArea   txaEditor;
    private JScrollPane pnlEditor;
    
    // Constructor
    public programa()
    {
        // Establece el Layout
        setLayout(null);

        // Crea los Objetos
        txaEditor = new JTextArea("Texto Inicial\n");        
        txaEditor.setText(txaEditor.getText()+"Esto lo acabo de poner");      
        txaEditor.setSelectionStart(5);
        txaEditor.setSelectionEnd(20);
        
        lblLineas = new JLabel("Lineas:");
        lblLineas.setBounds(10,320,50,30);
        
        txtLineas = new JTextField(String.valueOf(txaEditor.getLineCount()));
        txtLineas.setHorizontalAlignment(JTextField.RIGHT);
        txtLineas.setBounds(30,300,50,30);

        txtLineas = new JTextField(String.valueOf(txaEditor.getLineCount()));
        txtLineas.setHorizontalAlignment(JTextField.RIGHT);
        txtLineas.setBounds(55,320,40,30);

        lblCaracteres = new JLabel("Chars:");
        lblCaracteres.setBounds(100,320,100,30);

        txtCaracteres = new JTextField(String.valueOf(txaEditor.getText().length()));
        txtCaracteres.setHorizontalAlignment(JTextField.RIGHT);
        txtCaracteres.setBounds(140,320,40,30);


        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(190,320,80,30);  
        
        txtBuscar = new JTextField();
        txtBuscar.setBounds(278,320,200,30);
        
        btnBorrar = new JButton("Borrar");
        btnBorrar.setBounds(488,320,80,30);  

        // Creamos una fuente
        Font fuente=new Font("Lucida Console", Font.PLAIN, 18);
        txaEditor.setFont(fuente);
        txaEditor.setMargin(new Insets(20, 20, 20, 20));
                
        // Creo el Panel indicando que inserte el JTextArea
        pnlEditor = new JScrollPane(txaEditor);   
        pnlEditor.setBounds(10,10,560,300);  

        // Añade los Objetos
        add(lblLineas);        
        add(txtLineas);
        add(lblCaracteres);
        add(txtCaracteres);
        add(btnBuscar);
        add(txtBuscar);
        add(btnBorrar);
        add(pnlEditor);    

        // Asignamos los Eventos
        btnBuscar.addActionListener(this);
        txtBuscar.addActionListener(this);
        btnBorrar.addActionListener(this);
        txaEditor.addKeyListener(this);
        
    }

    // Implementando los métodos obligatorios de KeyListener
    @Override
    public void keyPressed(KeyEvent e) 
    {

    }
 
    public void keyReleased(KeyEvent e) 
    {
        // Cuenta los caracteres
        txtCaracteres.setText(String.valueOf(txaEditor.getText().length()));
    }
 
    public void keyTyped(KeyEvent e) 
    {
        // Actualiza las Lineas
        txtLineas.setText(String.valueOf(txaEditor.getLineCount()));
    }

    // Control de Action en los Botones y Text de Busqueda
    public void actionPerformed(ActionEvent e)
    {
        // Verifica si es el de buscar
        if (e.getSource()==btnBuscar || e.getSource()==txtBuscar)
        {
            // Variable para el Contenido
            String contenido = txaEditor.getText();
            String buscar    = txtBuscar.getText();

            // Ciclo para buscar y seleccionar
            int posicion = contenido.indexOf(buscar);

            // Verifica que haya encontrado
            if (posicion>=0)
            {
                // Selecciona
                txaEditor.requestFocusInWindow();
                //txaEditor.setSelectionStart(posicion);
                //txaEditor.setSelectionEnd(posicion+buscar.length());
                txaEditor.select(posicion, posicion+buscar.length());                
            }
            else
            {
                JOptionPane.showMessageDialog(this, 
                                              "El Texto:\n" +
                                              buscar+"\nno fue encontrado",                                               
                                              "Java desde 0 sin Ide", 
                                              JOptionPane.OK_OPTION);            
            }

        }
        else
        if (e.getSource()==btnBorrar)
        {
           // Borra el Contenido del textArea
           txaEditor.setText("");
           
           // Variables para conteo
           int ctaCaracteres = txaEditor.getText().length();
           int ctaLineas     = txaEditor.getLineCount();
         
           // Cuenta los caracteres
           txtCaracteres.setText(String.valueOf(ctaCaracteres));
            
           // Actualiza las Lineas
           txtLineas.setText(String.valueOf(ctaLineas));           
        }
    }
                
    // Función main que es obligatorio
    public static void main(String args[])
    {   
        // Crea la Ventana
        programa ventana = new programa();
        ventana.setTitle("Clase 76 - JScrollPane Font Inserts setMargin select");
        ventana.setBounds(0,0,600,400);
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);        
        ventana.setLocationRelativeTo(null);
        ventana.setResizable(false);
    }       
}