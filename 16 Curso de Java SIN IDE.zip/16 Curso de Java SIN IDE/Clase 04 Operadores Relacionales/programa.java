// --------------------------------
// Curso de Java sin IDE
// Clase 04 Operadores Relacionales
// --------------------------------

// Son similares a los tradicionales de Matemáticas

// Operador	Nombre            Ejemplo	
// ==	      Igual               x == y	
// !=	      Distinto            x != y	
// >	      Mayor que           x > y	
// <	      Menor que           x < y	
// >=	      Mayor o Igual que   x >= y	
// <=	      Menor o Igual que   x <= y

// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
     // Variables
     int x = 10;
     int y = 5;

     System.out.println("a)"+ (x == y));
     System.out.println("b)"+ (x != y));
     System.out.println("c)"+ (x >  y));
     System.out.println("d)"+ (x >= y));
     System.out.println("e)"+ (x <  y));
     System.out.println("f)"+ (x <= y));          
  }
}








