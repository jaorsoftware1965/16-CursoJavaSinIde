// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 45 ArrayList
// -------------------------------------------------------

// ArrayList es una clase incluida en las librerias
// del Lenguaje, que nos permite manejar arreglos en forma
// dinámica; es decir que su dimensión se aumenta o disminuye
// en tiempo de ejecución

// Se importa la librería
import java.util.ArrayList;
import java.util.Collections; 

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Despliega
        System.out.println("Clase 45 ArrayList");
        
        // Definimos un arreglo de String
        ArrayList<String> personas = new ArrayList<String>(); 

        // agregamos elementos al Arreglo
        personas.add("Juan");
        personas.add("Jose");
        personas.add("Maria");

        // Imprimimos el ArrayList
        System.out.println("a) Los elementos del Arreglo:");
        System.out.println(personas);
        System.out.println("");
        

        // Imprimiendo uno por uno
        System.out.println("b) Los elementos del Arreglo:");
        
        // Accediendo uno por uno
        for (int indice=0; indice < personas.size(); indice++)
        {
            // Accediendo por indice
            System.out.println(personas.get(indice));
        }
        System.out.println("");

        System.out.println("c) Los elementos del Arreglo:");
        // Usando foreach
        for (String persona : personas) 
        {
            System.out.println(persona);
        }
        System.out.println("");

        // Insertar en una posicion especifica
        personas.add(2,"El Segundo");

        // Añadiendo desde una colección
        personas.addAll(personas);
        
        // Añadiendo varias desde una posición
        personas.addAll(2,personas);

        // Cambiamos un dato
        personas.set(0,"Rene");

        // Variable para resultado
        boolean resultado;
        
        // Verifica si contiene
        resultado = personas.contains("Rene");

        // Incrementa la capacidad del arreglo
        personas.ensureCapacity(25);

        // Variable para posiciones
        int posicion;

        //Busca el Dato y devuelve posicion
        posicion = personas.indexOf("Jose");

        // Verifica si está vacía
        resultado = personas.isEmpty();

        //Busca el Dato y devuelve la utlimoa posicion
        posicion = personas.lastIndexOf("Jose");

        // Eliminamos un elemento
        personas.remove(1);
        personas.remove("Maria");

        // Elimina todos
        personas.removeAll(personas);

        // agregamos elementos al Arreglo
        personas.add("Juan");
        personas.add("Alberto");
        personas.add("Bonificacio");

        
        // eliminar todos
        personas.clear();

        // agregamos elementos al Arreglo
        personas.add("Juan");
        personas.add("Alberto");
        personas.add("Bonificacio");

        // Los ordena
        Collections.sort(personas);

        // Arreglo de Edades
        ArrayList<Integer> edades = new ArrayList<Integer>();
        edades.add(100);
        edades.add(75);
        edades.add(20);
        edades.add(25);
        System.out.println(edades);
        
        // Creamos desde una lista
        ArrayList<Integer> edades2 = new ArrayList<Integer>(edades);
        System.out.println(edades2);
                
    }   
}