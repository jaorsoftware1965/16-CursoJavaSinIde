// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 48 HashMap
// -------------------------------------------------------

// Un HashMap es una colección de pares de datos "key-value"
// donde key es la llave del valor, y no puede estar repetida

// Puedes acceder a los elementos a través de la llave
// Las llaves y los valores pueden ser de cualquier tipo

// Se importa la librería
import java.util.HashMap; 

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
       // Despliega
       System.out.println("Clase 48 HashMap");
                
       /// hashmap
       HashMap<String, String> capitales = new HashMap<String, String>();

       // Obtiene el valor del dato
       String dato;
       
       // Add keys and values (capital, Estado)
       capitales.put("Jalapa", "Veracruz");
       capitales.put("Oaxaca", "Oaxaca");
       capitales.put("Toluca", "Mexico");       
       dato = capitales.put("Puebla", "Puebla");
       System.out.println("a) Dato:"+dato);

       // Cuando ya existe devuelve el valor
       dato = capitales.put("Puebla", "Puebla");              
       System.out.println("b) Dato:"+dato);
       System.out.println(capitales);
       
       dato = capitales.get("Colima");       
       System.out.println("c) Dato:"+dato);
       dato = capitales.get("Puebla");
       System.out.println("d) Dato:"+dato);

       dato = capitales.replace("Puebla","Tehuacan");
       System.out.println("e) Dato:"+dato);
       
       boolean resultado = capitales.containsKey("Puebla");
       System.out.println("f) Resultado:"+resultado);
       resultado = capitales.containsValue("Toluca");
       System.out.println("g) Resultado:"+resultado);

       resultado = capitales.isEmpty();
       System.out.println("h) Resultado:"+resultado);
       
       
       // Eliminamos un elemento; devuelve null si no
       dato = capitales.remove("Puebla");
       System.out.println("i) Dato:"+dato);
       
       // recorremos
       for (String key: capitales.keySet())
       {
           System.out.println("Key:"+key);
           dato = capitales.get(key);
           System.out.println("Valor:"+dato);
       }

       // recorrido por valores
       for (String valor: capitales.values())
       {
           System.out.println("Valor:"+valor);
       }
      
       // Otro mapa de personas
       HashMap<String, Integer> personas = new HashMap<String, Integer>();

       // Nombre y Edades
       personas.put("Juan", 32);
       personas.put("Jose", 30);
       personas.put("Jesus", 33);

       for (String i : personas.keySet()) 
       {
          System.out.println("key: " + i + " value: " + personas.get(i));
       }

       // Recorremos los datos (Version 8 usando expresion lambda)
       capitales.forEach((key,value) 
                          -> System.out.println("Key: " + key + ": Value: " + value)
                        );    
              
       // Eliminamos todos los elementos
       capitales.clear();  
       System.out.println(capitales);                      
    }       
}