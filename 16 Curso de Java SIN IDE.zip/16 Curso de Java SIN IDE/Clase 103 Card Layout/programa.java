// ------------------------------------------------------
// Curso de Java desde 0 sin Ide
// Clase 103 CardLayout
// ------------------------------------------------------

// Librerias
import java.awt.CardLayout;  
import java.awt.Container; 
import javax.swing.ImageIcon;   
import javax.swing.Icon;  
import java.awt.event.ActionListener;  
import java.awt.event.ActionEvent;  
import javax.swing.JFrame;  
import javax.swing.JButton;  
  
public class programa extends JFrame implements ActionListener
{  
    // Propiedades de la Clase
    CardLayout card;  
    JButton    button1;
    JButton    button2;
    JButton    button3;
    Container  contenedor;  

    // Constructor
    programa()
    {            
        // Obtengo el ContentPane
        contenedor = getContentPane();  
        
        // CardLayout 
        card = new CardLayout();  
        
        // Coloco el Latout en el Contenedor
        contenedor.setLayout(card);  
        
        // Se crean los botones con iconos        
        Icon icon = new ImageIcon("images\\manzana.jpg");
        button1 = new JButton(icon);          
        
        icon = new ImageIcon("images\\casa.jpg");
        button2 = new JButton(icon);  

        icon = new ImageIcon("images\\gato.jpg");
        button3 = new JButton(icon);  

        // Define el control de Eventos
        button1.addActionListener(this);  
        button2.addActionListener(this);  
        button3.addActionListener(this);  
              
        // Agrego los botones al contenedor
        contenedor.add("a",button1);
        contenedor.add("b",button2);
        contenedor.add("c",button3);  
                          
    }  

    // El Evento ActionPerfomed
    public void actionPerformed(ActionEvent e) 
    {  
        // Visualiza el Siguiente
        card.next(contenedor);  
    }  
  
    public static void main(String[] args) 
    {
        // Crea la Ventana  
        programa ventana = new programa();  
        // Establece caracteristicas
        ventana.setTitle("103 Card Layout");
        ventana.setSize(400,400);  
        ventana.setVisible(true);  
        ventana.setDefaultCloseOperation(EXIT_ON_CLOSE);  
        ventana.setLocationRelativeTo(null);
    }  
}  