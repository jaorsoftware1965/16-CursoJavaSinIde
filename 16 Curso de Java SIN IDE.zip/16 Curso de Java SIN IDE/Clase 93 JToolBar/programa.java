// --------------------------------------
// Curso de Java desde 0 sin IDE
// 93 JToolBar
// --------------------------------------

//Librerias
import javax.swing.JToolBar;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JToggleButton;
import javax.swing.JComboBox;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import java.awt.BorderLayout;
import javax.swing.SwingConstants;

// La clase del Programa
class programa extends JFrame 
{
    JToolBar          toolbar;
    JButton           New;
    JButton           Open; 
    JButton           Save;
    JToggleButton     Left;
    JToggleButton     Center;
    JToggleButton     Right;
    JComboBox<String> fonts;
    ButtonGroup       group;

    // Constructor
    programa() 
    {
        // Crea la ToolBar
        toolbar = new JToolBar();
        toolbar.setOrientation(SwingConstants.VERTICAL);

        // Crea los Botones
        New = new JButton(new ImageIcon(
                "images/nuevo.png"));
        
        // Crea el boton de Abrir
        Open = new JButton(new ImageIcon(
                "images/abrir.png"));
        
        // Crea el boton de Guardar
        Save = new JButton(new ImageIcon(
                "images/guardar.png"));

        // El Boton de Izquierda        
        Left = new JToggleButton(new ImageIcon(
                "images\\Izquierda.png"));

        // Boton de Centrar        
        Center = new JToggleButton(
                new ImageIcon(
                        "images\\Centro.png"));
        
        // Botón de Derecha
        Right = new JToggleButton(new ImageIcon(
                "images\\Derecha.png"));

        // Boton de Grupo
        group = new ButtonGroup();

        // Agrega los botones al Grupo
        group.add(Left);
        group.add(Center);
        group.add(Right);

        // Crea el Combo para las fuentes
        fonts = new JComboBox<String>();

        // Establece la Fuente
        fonts.addItem("Arial");
        fonts.addItem("Times New Roman");
        fonts.addItem("Comic Sans Ms");

        // Agrega los botones a la barra de herramientas
        toolbar.add(New);
        toolbar.add(Open);
        toolbar.addSeparator();
        toolbar.add(Save);
        toolbar.addSeparator();
        toolbar.add(Left);
        toolbar.add(Center);
        toolbar.add(Right);
        toolbar.addSeparator();
        toolbar.add(fonts);
        
        // Agrega la barra de herramientas arriba        
        getContentPane().add(toolbar, BorderLayout.EAST);
        //add(toolbar, BorderLayout.NORTH);
    }
 
    public static void main(String args[]) throws Exception 
    {
        programa ventana = new programa();    
        ventana.setTitle("93 JToolBar");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.pack();
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);
    }
}
