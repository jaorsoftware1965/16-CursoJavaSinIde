// -----------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 35 POO Propiedades y Métodos Static
// -----------------------------------------

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    { 
        // Creamos un objeto de persona
        personas oPersona1 = new personas();

        // Establecemos los datos
        oPersona1.Nombre    = "Juan Perez";
        oPersona1.Direccion = "Conocido";
        oPersona1.Edad      = 34;        
        oPersona1.contador  = 1;

        // Imprimimos los datos de la Persona
        oPersona1.fnImprimeNombre();
        oPersona1.fnImprimeDireccion();
        oPersona1.fnImprimeEdad();
        oPersona1.fnImprimeContador();        
        System.out.println("");        
        System.out.println("");       
        
        // Creamos otro de persona
        personas oPersona2 = new personas();

        // Establecemos los datos
        oPersona2.Nombre    = "Pedro Juarez";
        oPersona2.Direccion = "Conocido";
        oPersona2.Edad      = 34;        
        oPersona2.contador  = 2;

        // Imprimimos los datos de la Persona
        oPersona2.fnImprimeNombre();
        oPersona2.fnImprimeDireccion();
        oPersona2.fnImprimeEdad();
        oPersona2.fnImprimeContador();    
        System.out.println("");        
        System.out.println("");       
         
        // Imprimimos el Contador desde la clase
        personas.fnImprimeContador();
        

        // Creamos un nuevo objeto
        personas oPersona3 = new personas();

        oPersona3.fnImprimeNombre();
        oPersona3.fnImprimeDireccion();
        oPersona3.fnImprimeEdad();
        
        oPersona3.fnImprimeContador();
        oPersona1.fnImprimeContador();
        oPersona2.fnImprimeContador();
        personas.fnImprimeContador();
        
        personas.contador = 5;
        oPersona3.fnImprimeContador();
        oPersona1.fnImprimeContador();
        oPersona2.fnImprimeContador();
        personas.fnImprimeContador();


    }   
}