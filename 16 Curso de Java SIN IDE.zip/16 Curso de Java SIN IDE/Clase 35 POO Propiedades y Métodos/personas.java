// -----------------------------------------
// Curso de Java desde 0 sin IDE
// Archivo utilizado en Clase programa
// -----------------------------------------
public class personas
{
    // Contador de Personas
    static int contador = 0;
    
    // Propiedades de la clase
    String Nombre    = "Sin Nombre";
    String Direccion = "Sin Direccion";
    int    Edad      = -1;

    // Métodos
    void fnImprimeNombre()
    {
        System.out.println("Nombre:"+Nombre);
    }

    // Métodos
    void fnImprimeDireccion()
    {
        System.out.println("Direccion:"+Direccion);
    }

    // Métodos
    void fnImprimeEdad()
    {
        System.out.println("Edad:"+Edad);
    }

    // Imprime el contador
    static void fnImprimeContador()
    {
        System.out.println("Contador:"+contador);
        //System.out.prntln(Edad);
    }
}

