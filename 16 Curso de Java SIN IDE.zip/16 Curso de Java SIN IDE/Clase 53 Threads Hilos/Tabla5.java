// -------------------------------------------------------
// Clase Tabla5
// -------------------------------------------------------

// Clase se debe llamar igual que el archivo
public class Tabla5 extends Thread
{   
    public void run() 
    {
        System.out.println("Imprimiendo tabla del 5 en extend Threads... ");
        for (int indice=1; indice <=10; indice++)
        {
            // Imprime 
            System.out.println("5 x "+indice + " = "+ 5 * indice);
            
            try
            {
               //Espera 5 segundos
               sleep(5000);
            }
            catch (Exception e) 
            {
                System.out.println("Error Inesperado:"+e.getMessage());           
            }             
        }
        System.out.println("Se termino de Imprimir tabla del 5");           
    }
}