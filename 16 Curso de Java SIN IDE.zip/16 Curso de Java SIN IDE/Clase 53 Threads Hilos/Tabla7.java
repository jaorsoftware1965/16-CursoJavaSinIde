// -------------------------------------------------------
// Clase Tabla7
// -------------------------------------------------------

// Clase se debe llamar igual que el archivo
public class Tabla7 implements Runnable
{   
    public void run() 
    {
        System.out.println("Imprimiendo tabla del 7 en implements Runnable... ");
        for (int indice=1; indice <=15; indice++)
        {
            // Imprime 
            System.out.println("7 x "+indice + " = "+ 7 * indice);
            
            try
            {
               //Espera 1 segundos
               Thread.sleep(1000);
            }
            catch (Exception e) 
            {
                System.out.println("Error Inesperado:"+e.getMessage());           
            }
        }
        System.out.println("Se termino de Imprimir tabla del 7");           
    }
}