// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 53 Threads - Hilos
// -------------------------------------------------------

// Un thread o hilo, es una sección de código que se lanza
// en forma independiente del programa principal

// Hay 2 formas de crear un Thread
// La primera es heredando de la clase Thread
// La segunda es implementando de la clase Runnable

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
       // Despliega
       System.out.println("Clase 53 Thread - Hilos");
       
       // Creando un thread de la tabla del 5
       Tabla5 thread5 = new Tabla5();
       thread5.start();
       System.out.println("Corriendo Tabla del 5 ...");

       // Creando un thread de la tabla del 7
       Tabla7 obj     = new Tabla7();
       Thread thread7 = new Thread(obj);
       thread7.start();
       System.out.println("Corriendo Tabla del 7 ...");

       // El programa finalizara
       System.out.println("Programa Terminado");
    }       
}