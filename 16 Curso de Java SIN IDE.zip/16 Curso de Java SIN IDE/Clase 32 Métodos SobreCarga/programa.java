// -------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 32 Métodos SobreCarga
// -------------------------------------

// Sobrecargar un Método significa que lo definimos
// mas de una vez, pero con diferentes parámetros y
// esto es lo que hace distinto en cada definición.

// Clase se debe llamar igual que el archivo
public class programa
{  
  // Definimos un método dentro de la Clase
  static int fnSumar(int numero1, int numero2)
  {
      // Desplegamos el Mensaje
      return (numero1 + numero2);
  }

  // Sorbecargamos el mismo método
  static double fnSumar(double numero1, double numero2)
  {
      // Desplegamos el Mensaje
      return (numero1 + numero2);
  }
 
  // Sorbecargamos el mismo método
  static String fnSumar(String cadena1, String cadena2)
  {
      // Desplegamos el Mensaje
      return (cadena1 + cadena2);
  }

  // Función main que es obligatorio
  public static void main(String args[])
  {          
      int    a = 10,    b = 20;
      double c = 23.45, d = 3.1416;

      // Llamamos al Método que suma enteros
      System.out.println(fnSumar(a,b));
      System.out.println(fnSumar(c,d));
      System.out.println(fnSumar(a,c)); 
      System.out.println(fnSumar("Hola ","Mundo")); 
      System.out.println(fnSumar("a","Mundo")); 
  }   
}