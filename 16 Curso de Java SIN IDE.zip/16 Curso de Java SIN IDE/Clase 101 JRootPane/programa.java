// ------------------------------------------------------
// Curso de Java desde 0 sin Ide
// Clase 101 JRootPane
// ------------------------------------------------------

// Librerias
import javax.swing.JButton;  
import javax.swing.JFrame;  
import javax.swing.JMenu;  
import javax.swing.JMenuBar;  
import javax.swing.JRootPane;  

// Clase Principal
public class programa extends JFrame
{  
    // Propiedades Privadas
    JRootPane root;
    JMenuBar  bar;
    JMenu     menu;

    // Constructor
    public programa()
    {
        // Crea el RootPane obteniendolo del Frame
        JRootPane root = getRootPane();  
  
        // Create a menu bar  
        JMenuBar bar = new JMenuBar();  
        JMenu    menu = new JMenu("File");  
        bar.add(menu);  
        menu.add("Open");  
        menu.add("Close");  
        root.setJMenuBar(bar);  

        // Add a button to the content pane  
        root.getContentPane().add(new JButton("Presioname"));  
    }

    public static void main(String[] args) 
    {  
        // Crea la Ventana
        programa ventana = new programa();

        // Establece las caracteristicas de la Ventana
        ventana.setTitle("101 JRootPane");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setLocationRelativeTo(null);
        ventana.pack();
        ventana.setVisible(true);
    }  
}  