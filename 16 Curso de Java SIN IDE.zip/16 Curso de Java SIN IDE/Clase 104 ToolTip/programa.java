// ------------------------------------------------------
// Curso de Java desde 0 sin Ide
// Clase 104 ToolTip
// Se puede usar para cualquier JComponent
// ------------------------------------------------------

// Librerias
import javax.swing.JFrame;    
import javax.swing.JPasswordField;    
import javax.swing.JLabel; 

public class programa extends JFrame 
{  
    // Propiedades
    JPasswordField txpPassword;
    JLabel         lblPassword;

    // Constructor
    public programa()
    {
        // Crea el Password Field
        JPasswordField txpPassword = new JPasswordField();   
        txpPassword.setBounds(100,100,100,30);    
        txpPassword.setToolTipText("Enter your Password");  

        // Crea la Etiqueta
        JLabel lblPassword = new JLabel("Password:");    
        lblPassword.setBounds(20,100, 80,30);  
        lblPassword.setToolTipText("Esta es una etiqueta");  
        
        // Añade la Etiqueta y el PasswordField
        add(txpPassword);
        add(lblPassword);       

    }

    // función main
    public static void main(String[] args) 
    {
        // Crea la Ventana
        programa ventana = new programa();

        // Establece las caracteristicas
        ventana.setTitle("104 ToolTip");    
        ventana.setSize(300,300);    
        ventana.setLayout(null);    
        ventana.setVisible(true);      
        ventana.setLocationRelativeTo(null);
    }  
}  