// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 83 swing JPanel Border BorderFactory TitleBorder
//                EtchedBorder
// -------------------------------------------------------

// Librerias
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.Color;

import javax.swing.BorderFactory; 
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;



// Clase Principal
public class programa extends JFrame implements ChangeListener
{
    // Objetos de la Clase
    JPanel        pnlDemo;
    ButtonGroup   bgBordes;
    JRadioButton  rbBlackline;
    JRadioButton  rbRaisedetched;
    JRadioButton  rbLoweredetched;
    JRadioButton  rbRaisedbevel;
    JRadioButton  rbLoweredbevel;
    JRadioButton  rbEmpty;
  
    
    // Constructor
    public programa()
    {
        // Establece el Layout
        setLayout(null);

        // Crea el Panel
        pnlDemo = new JPanel();
        pnlDemo.setBounds(10,10,360,260);  
        pnlDemo.setLayout(null);  

        // Se establece el Borde con Titulo
        pnlDemo.setBorder(BorderFactory.createTitledBorder("Borde con Titulo"));
        pnlDemo.setBackground(Color.gray);         

        // Creamos los RadioButton
        rbBlackline = new JRadioButton("blackline");
        rbBlackline.setBounds(20,20,150,30);
                
        rbLoweredetched = new JRadioButton("loweredetched");
        rbLoweredetched.setBounds(20,120,150,30);

        rbRaisedetched = new JRadioButton("raisedetched");
        rbRaisedetched.setBounds(20,220,150,30);

        rbLoweredbevel = new JRadioButton("loweredbevel");
        rbLoweredbevel.setBounds(200,20,150,30);

        rbRaisedbevel = new JRadioButton("raisedbevel");
        rbRaisedbevel.setBounds(200,120,150,30);        
        
        rbEmpty = new JRadioButton("empty");
        rbEmpty.setBounds(200,220,150,30);

        // Agrego los Radio al ButtonGroup
        bgBordes = new ButtonGroup();
        bgBordes.add(rbBlackline);
        bgBordes.add(rbRaisedetched);
        bgBordes.add(rbLoweredetched);
        bgBordes.add(rbRaisedbevel);
        bgBordes.add(rbLoweredbevel);
        bgBordes.add(rbEmpty);

        // Agrega los Radio al Panel
        pnlDemo.add(rbBlackline);
        pnlDemo.add(rbRaisedetched);
        pnlDemo.add(rbLoweredetched);
        pnlDemo.add(rbRaisedbevel);
        pnlDemo.add(rbLoweredbevel);
        pnlDemo.add(rbEmpty);
       
        // Eventos
        rbBlackline.addChangeListener(this);
        rbRaisedetched.addChangeListener(this);
        rbLoweredetched.addChangeListener(this);
        rbRaisedbevel.addChangeListener(this);
        rbLoweredbevel.addChangeListener(this);
        rbEmpty.addChangeListener(this);
        
        // Agrega el Panel al Frame
        add(pnlDemo);
    }

    // Método para controlar cambio en los RadioButton
    public void stateChanged(ChangeEvent e)
    {
        // Variable para el borde
        Border borde = null;

        // Verifica el estado de cada checkbox
        if (rbBlackline.isSelected())        
            // Cambia el Borde
            borde = BorderFactory.createLineBorder(Color.black);

        else
        if (rbRaisedetched.isSelected())        
            // Cambia el Borde
            borde = BorderFactory.createEtchedBorder(EtchedBorder.RAISED);

        else
        if (rbLoweredetched.isSelected())        
            // Cambia el Borde
            borde = BorderFactory.createEtchedBorder(EtchedBorder.LOWERED);
        else
        if (rbRaisedbevel.isSelected())        
            // Cambia el Borde
            borde = BorderFactory.createRaisedBevelBorder();            

        else
        if (rbLoweredbevel.isSelected())        
            // Cambia el Borde
            borde = BorderFactory.createLoweredBevelBorder();
        else
        if (rbEmpty.isSelected())        
            borde = BorderFactory.createEmptyBorder();            


        // Cambia el Borde
        if (borde!=null)
           pnlDemo.setBorder(borde);    
        
    }


    public static void main(String[] args) 
    {
        // Crea un objeto JFrame ya con titulo
        programa ventana = new programa();

        // Establece las caracteristicas de la Ventana
        ventana.setTitle("83 JPanel Border BorderFactory TitleBorder EtchedBorder");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setSize(400, 320);
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null); 
    }
}