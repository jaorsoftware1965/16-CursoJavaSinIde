// -----------------------------------------
// Curso de Java desde 0 sin IDE
// Archivo utilizado en Clase programa
// -----------------------------------------
public class personas
{
    // Contador de Personas
    private static int contador = 0;
    String algo;
    
    // Propiedades de la clase
    String nombre     = "Juan Perez";
    String direccion  = "Conocido";
    char   genero     = 'M';
    int    edad       = 20;
    int    indice;

    // Constructor vacío
    personas()
    {
        // Mensaje
        System.out.println("El Objeto se queda con los valores default:");
        System.out.println("");
        // Incrementa el Contador
        contador++;
        indice = contador;
    }

    // Constructor
    personas(String nombre, String direccion, char genero, int edad)
    {
        // Valida que el nombre no esté vacío
        if (nombre.length()==0)
        {
            System.out.println("El Nombre no puede quedar vacio");
            System.out.println("Queda como Juan Perez\n"); 
        }
        else
            // Lo asigna
            this.nombre = nombre;
        
        // Validamos la Direccion
        if (direccion.length()==0)
        {
            System.out.println("La Direccion no puede quedar vacia");
            System.out.println("Queda como Conocido\n");            
        }
        else
            // Lo asigna
            this.direccion = direccion;

        // Valida el genero
        if (genero != 'F' && genero != 'M')
        {
            System.out.println("Error en Genero");
            System.out.println("Se asigna M-Masculino\n");            
        }
        else
           // lo Asigna
           this.genero = genero;

        // Valida la edad
        if (edad < 18)
        {
            System.out.println("La Edad no puede ser menor que 18");
            if (this.genero=='M')
            {
                System.out.println("Se asigna 20\n");            
                this.edad = 20;
            }
            else
            {
                System.out.println("Se asigna 18\n");            
                this.edad = 18;
            }                
        }
        else
            // Lo asigna
            this.edad = edad;
        
        // Incrementamos el Contador
        contador++;
        indice = contador;
    }

    // Métodos
    void fnImprimeInformacion()
    {
        System.out.println("Nombre    :"+nombre);
        System.out.println("Direccion :"+direccion);
        System.out.println("Edad      :"+edad);
        System.out.println("Genero    :"+genero);
        System.out.println("Indice    :"+indice);
        fnImprimeContador();
    }

    // Imprime el contador
    private static void fnImprimeContador()
    {
        System.out.println("Contador:"+contador);
    }
}

