// --------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 37 POO Modificadores de Acceso
// Public Private y Protected
// --------------------------------------------------

// Public. El Atributo y/o Método puede ser accedido
// desde la clase, clases heredadas, y el objeto

// Private. El Atributo y/o Método puede ser
// accedido solo dentro de la clase

// Protected. El Atributo y/o Método puede ser
// accedido desde la misma clase, y desde las clases
// heredadas 

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    { 
        // Creamos un objeto de persona con valores default
        personas oPersona0 = new personas();
        
        // Imprimimos la Información
        oPersona0.fnImprimeInformacion();
        
        // No es posible acceder a una propiedad privada
        //oPersona0.contador = 10;
        oPersona0.nombre="Benito Bodoque";
        //oPersona0.fnImprimeContador();
        //personas.fnImprimeContador();

        // No es posible acceder a una propiedad no estatica
        //personas.nombre="Algo";
        System.out.println("");               
    }   
}