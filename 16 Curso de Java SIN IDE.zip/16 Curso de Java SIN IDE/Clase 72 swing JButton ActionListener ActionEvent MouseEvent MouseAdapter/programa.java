// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 72 swing JButton ActionListener ActionEvent
//                MouseEvent MouseAdapter
// -------------------------------------------------------

// Librería para swing
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;

// Clase se debe llamar igual que el archivo
public class programa extends JFrame implements ActionListener
{   
    // Creamos los objetos
    private  JLabel  lblEtiqueta;    
    private  JButton btnAceptar;
    private  JButton btnCancelar;

    // Constructor
    public programa()
    {
        // Establecemos el Layout
        setLayout(null);

        // Creamos los objetos
        lblEtiqueta = new JLabel ("Click sobre mi");
        btnAceptar  = new JButton("Aceptar");
        btnCancelar = new JButton("Cancelar");

        // Establecemos posición y dimensiones
        lblEtiqueta.setBounds(  20,20,160,30);
        btnAceptar.setBounds(  20,200,160,30);
        btnCancelar.setBounds(400,200,160,30);

        //Establecemos el control de evento 
        lblEtiqueta.addMouseListener(new MouseAdapter()  
        {  
            // El evento mouseClicked
            public void mouseClicked(MouseEvent e)  
            {  
                JOptionPane.showMessageDialog(null, 
                                              "Has hecho Click en la Etiqueta", 
                                              "Java desde 0 sin Ide", 
                                              JOptionPane.OK_OPTION);            

            }              
            // // El evento mousePressed
            // public void mousePressed(MouseEvent e)  
            // {  
            //     JOptionPane.showMessageDialog(null, 
            //                                   "Has hecho MousePressed en la Etiqueta", 
            //                                   "Java desde 0 sin Ide", 
            //                                   JOptionPane.OK_OPTION);            

            // }              
        });

        //lblEtiqueta.addActionListener(this); //No esta defnido
        btnAceptar.addActionListener(this);
        btnCancelar.addActionListener(this);
        //btnCancelar.addMouseListener(this); //Si lo acepta
        
        // Añadimos los Objetos
        add(lblEtiqueta);
        add(btnAceptar);
        add(btnCancelar);

    }

    // Método para controlar los Eventos Action de los Objetos
    public void actionPerformed(ActionEvent e) 
    {
        // Verificamos que objeto hizo el evento
        if (e.getSource()==btnAceptar) 
        {
            // Deshabilita el Boton
            btnAceptar.setEnabled(false);

            // Mensaje
            JOptionPane.showMessageDialog(this, 
                                          "Has Presionado Aceptar", 
                                          "Java desde 0 sin Ide", 
                                          JOptionPane.OK_OPTION);            
            
            // Habilita el Boton
            btnAceptar.setEnabled(true);            
        }
        else
        if (e.getSource()==btnCancelar) 
        {
            // Salida de la Aplicación
            //System.exit(0);
            this.dispose();
        }
    }

                
    // Función main que es obligatorio
    public static void main(String args[])
    {   
        // Creamos el Formulario
        programa ventana = new programa();

        // COlocamos caracteristica
        ventana.setTitle("Clase 72 - Swing JButton");
        ventana.setBounds(10,10,600,300);
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Centramos la ventana
        ventana.setLocationRelativeTo(null);
        ventana.setResizable(false);
    }       
}