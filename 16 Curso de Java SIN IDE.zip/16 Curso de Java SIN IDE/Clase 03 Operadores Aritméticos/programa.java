// -----------------------------------------------------
// Curso de Java sin IDE
// Clase 03 Operadores Aritméticos
// -----------------------------------------------------

// Un operador es un símbolo o mas de uno que se utiliza
// para realizar operaciones.

// En esta clase veremos los operadores aritméticos

// Operador   Nombre          Ejemplo
// +	        Suma	          x + y	
// -	        Resta	          x - y	
// *	        Multiplicacion	x * y	
// /	        Division	      x / y	
// %	        Residuo	        x % y	
// ++	        Incremento	    ++x; x++
// --	        Decremento	    --x; x--


// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
     // Variables
     int x = 10;
     int y = 5;
     int resultado;

     // Desplegamos y usamos los operadores
     resultado = x + y;
     System.out.println("x + y :" + resultado);
     resultado = x - y;
     System.out.println("x - y :" + resultado);
     resultado = x * y;
     System.out.println("x * y :" + resultado);
     resultado = x / y;
     System.out.println("x / y :" + resultado);
     resultado = x % y;
     System.out.println("x % y :" + resultado);
     
     System.out.println("x++ :" + x++); // 10
     System.out.println("x   :" + x); 
     System.out.println("++x :" + ++x); // 12
     System.out.println("x   :" + x); 
     System.out.println("x-- :" + x--); // 12
     System.out.println("x   :" + x);
     System.out.println("--x :" + --x + "\n"); // 10 
  }
}
