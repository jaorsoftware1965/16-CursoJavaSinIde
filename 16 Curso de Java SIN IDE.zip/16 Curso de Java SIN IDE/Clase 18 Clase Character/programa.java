// ---------------------------------
// Curso de Java desde 0 sin IDE
// Clase 18 Clase Character
// ---------------------------------
 
// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
    // Declaramos un array de Enteros
    char      letra  = 'a';
    Character tecla  = ';';
    Character numero = '9';

    // Desplegamos los arreglos
    System.out.println("letra   :" + letra);
    System.out.println("tecla   :" + tecla);
    System.out.println("numero  :" + numero);
    System.out.println();

    // Usando metodos desde el Objeto y la Clase
   	System.out.println("tecla.isLetter :" + tecla.isLetter(letra));
    System.out.println("tecla.isLetter :" + Character.isLetter(letra));
    System.out.println();
    
    System.out.println("tecla.isLetter :" + tecla.isLetter(tecla));
    System.out.println("tecla.isLetter :" + Character.isLetter(tecla));
    System.out.println();

    System.out.println("tecla.isDigit :" + Character.isDigit(numero));
    System.out.println("tecla.isDigit :" + Character.isDigit(tecla));
    System.out.println();

    System.out.println("tecla.isWhitespace :" + Character.isWhitespace(' '));
    System.out.println("tecla.isWhitespace :" + Character.isWhitespace(tecla));
    System.out.println();

    System.out.println("tecla.isUpperCase :" + Character.isUpperCase('a'));
    System.out.println("tecla.isUpperCase :" + Character.isUpperCase('A'));
    System.out.println();

    System.out.println("tecla.isLowerCase :" + Character.isLowerCase('a'));
    System.out.println("tecla.isLowerCase :" + Character.isLowerCase('A'));
    System.out.println();

    System.out.println("tecla.toUpperCase :" + Character.toUpperCase('e'));
    System.out.println("tecla.toLowerCase :" + Character.toLowerCase('X'));
    System.out.println();

    System.out.println("tecla.toString :" + Character.toString('e'));
    System.out.println("tecla.toString :" + Character.toString('X'));
    System.out.println();        

  }
}