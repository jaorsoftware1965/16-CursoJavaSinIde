// ---------------------------------
// Curso de Java desde 0 sin IDE
// Clase 27 Operaciones con Horas
// ---------------------------------

// Importamos las librerias
import java.time.LocalTime; 
import static java.time.temporal.ChronoUnit.HOURS;
import static java.time.temporal.ChronoUnit.MINUTES;
import static java.time.temporal.ChronoUnit.SECONDS;
import static java.time.temporal.ChronoUnit.NANOS;


// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
    System.out.println("Horas Creadas...");
    LocalTime time1 = LocalTime.now();
    LocalTime time2 = LocalTime.parse("11:00:59.759");
    LocalTime time3 = LocalTime.of(11, 00, 59);
    System.out.println(time1);
    System.out.println(time2);
    System.out.println(time3);
    System.out.println();

    // Imprimiendo horas, minutos y segundos separados
    System.out.println("Imprimiendo Separado");
    System.out.println("Hora    :"+time1.getHour());
    System.out.println("Minuto  :"+time1.getMinute());
    System.out.println("Segundo :"+time1.getSecond());
    System.out.println("Nano    :"+time1.getNano());
    System.out.println("Segundo del Dia :"+time1.toSecondOfDay());
    System.out.println("String  :"+time1.toString());
    System.out.println();


    // Sumamos horas
    System.out.println("Sumamos 5 horas:");
    time2 = time1.plusHours(5);
    System.out.println(time2);
    System.out.println();

    System.out.println("Restamos 5 horas:");
    time2 = time1.minusHours(5);
    System.out.println(time2);
    System.out.println();

    // Sumamos Minutos
    System.out.println("Sumamos 5 Minutos:");
    time2 = time1.plusMinutes(5);
    System.out.println(time2);
    System.out.println();

    System.out.println("Restamos 5 Minutos:");
    time2 = time1.minusMinutes(5);
    System.out.println(time2);
    System.out.println();

    // Sumamos Segundos
    System.out.println("Sumamos 25 Segundos:");
    time2 = time1.plusSeconds(25);
    System.out.println(time2);
    System.out.println();

    System.out.println("Restamos 25 Segundos:");
    time2 = time1.minusSeconds(5);
    System.out.println(time2);
    System.out.println();

    System.out.println("Verificando Antes:");
    System.out.println(time1.isBefore(time2));
    System.out.println();

    System.out.println("Verificando Despues:");
    System.out.println(time1.isAfter(time2));
    System.out.println();

    System.out.println("Verificando Igualdad:");
    System.out.println(time1.equals(time2));
    System.out.println();

    System.out.println("Verificando Igualdad:");
    System.out.println(time1.equals(time1));
    System.out.println();

    // Diferencias
    time2 = time1.plusHours(2);
    time2 = time2.plusMinutes(10);
    time2 = time2.plusSeconds(30);
    System.out.println("time1 :"+time1);  
    System.out.println("time2 :"+time2);  
    
    long difHoras = time1.until(time2,HOURS);
    System.out.println("Diferencia en Horas :"+difHoras);  
    
    long difMinutos = time1.until(time2,MINUTES);
    System.out.println("Diferencia en Minutos :"+difMinutos);  

    long difSegundos = time1.until(time2,SECONDS);
    System.out.println("Diferencia en Segundos :"+difSegundos);  
    System.out.println();

    long difNano = time1.until(time2,NANOS);
    System.out.println("Diferencia en Nano :"+difNano);  
    System.out.println();

  }
}