// ------------------------------------------------
// Curso de Java desde 0 sin Ide
// Clase 94 JTree showInputDialog showConfirmDialog
// ------------------------------------------------

// Librerías
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.event.MouseListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JTree;
import javax.swing.tree.TreePath;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;


// Clase Principal
class programa extends JFrame implements ActionListener
{
    // Propiedades de la Clase
    DefaultMutableTreeNode nodoRaiz;
    DefaultMutableTreeNode nodoTiposLenguaje;
    DefaultMutableTreeNode nodoLenguaje;
    DefaultMutableTreeNode node;
    JTree                  arbolLenguajes;
    JButton                btnInsertar;
    JButton                btnEliminar;
    JPanel                 buttonsPanel;
    TreePath               treePath;
    int                    index;

    // Constructor
    programa() 
    {     
        // Crea los nodos para agregarlos al arbol
        nodoRaiz = new DefaultMutableTreeNode("Lenguajes");

        // Creo el Nodo de Lenguajes de Escritorio
        nodoTiposLenguaje = new DefaultMutableTreeNode("Escritorio");

        // Creo el Nodo de Lenguaje C y lo Agrego al Nodo
        nodoLenguaje = new DefaultMutableTreeNode("C");
        nodoTiposLenguaje.add(nodoLenguaje);
        
        // Creo el Nodo de Lenguaje C++ y lo Agrego al Nodo
        nodoLenguaje = new DefaultMutableTreeNode("C++");
        nodoTiposLenguaje.add(nodoLenguaje);

        // Agrego el Nodo a la Raiz
        nodoRaiz.add(nodoTiposLenguaje);

        // Crea el Nodo para los Lenguajes Web
        nodoTiposLenguaje = new DefaultMutableTreeNode("Web");

        // Crea el Nodo para el Lenguaje Php
        nodoLenguaje = new DefaultMutableTreeNode("Php");

        // Agrega el Nodo del Lenguaje a Tipos de Lenguaje
        nodoTiposLenguaje.add(nodoLenguaje);

        // Agrega el Nodo Tipos de Lenguaje a la raiz
        nodoRaiz.add(nodoTiposLenguaje);

        // Agrega el Nodo Raiz al Arbol
        arbolLenguajes = new JTree(nodoRaiz);

        // Asigna evento
        arbolLenguajes.addMouseListener(ml);

        // Evento para controlar el Click
        arbolLenguajes.getSelectionModel().addTreeSelectionListener(new TreeSelectionListener() 
        {
		    // evento del TreeListener
			public void valueChanged(TreeSelectionEvent e) 
            {				
				// Obtenemos y escribimos en pantalla  el path seleccionado
				TreePath path = e.getPath();
				Object [] nodos = path.getPath();
                String ruta="";				
				for (Object nodo: nodos)					
                    ruta+=nodo.toString() + " | ";
				//System.out.println("");
                JOptionPane.showMessageDialog(null, 
                                             "Seleccionaste:\n" +
                                              ruta,
                                              "Java desde 0 sin Ide", 
                                              JOptionPane.OK_OPTION);
				
				// Mirando el ultimo nodo del path, sabemos qué nodo en concreto
				// se ha seleccionado.
				DefaultMutableTreeNode ultimoNodo = 
					(DefaultMutableTreeNode)nodos[nodos.length-1];

				
				// Por ejemplo, para ver si se ha seleccionado el "hijo1"...
                System.out.print("Ultimo Nodo->");
                System.out.println(ultimoNodo.getUserObject());
                //System.out.print("getSource->");
                //System.out.println(e.getSource());                         
			}
		
		});
        
        // Crea los Botons
        btnInsertar = new JButton("Add");
        btnInsertar.addActionListener(this);
        btnEliminar = new JButton("Remove");
        btnEliminar.addActionListener(this);
        buttonsPanel = new JPanel();
        buttonsPanel.add(btnInsertar);
        buttonsPanel.add(btnEliminar);

        // Crea un ScrollPane con el Arbol
        add(new JScrollPane(arbolLenguajes));
        
        // Añade el Panel al Sur
        add(buttonsPanel, BorderLayout.SOUTH);        
    }

    // Captura el Evento del Mouse
    MouseListener ml = new MouseAdapter() 
    {
         public void mousePressed(MouseEvent e) 
        {
             // Se obtiene el path para esa fila. Con el path podemos obtener
            // los nodos.
            TreePath selPath = arbolLenguajes.getPathForLocation(e.getX(), e.getY());

            // Valida
            if (selPath!=null)
            {
                Object nodo = selPath.getLastPathComponent();

                JOptionPane.showMessageDialog(null, 
                "Seleccionaste con MouseListener:\n" +
                 nodo,
                 "Java desde 0 sin Ide", 
                 JOptionPane.OK_OPTION);
            }
            
        }
    };

    // El Evento Click en los Botones
    public void actionPerformed(ActionEvent e) 
    {
        // Verificar el Boton de Insertar
        if (e.getSource() == btnInsertar) 
        {
            // Declara un objeto para Nodo
            DefaultMutableTreeNode nodoSeleccionado;

            // Obtiene la ruta de Seleccionado
            treePath = arbolLenguajes.getSelectionPath();

            // Verifica que haya seleccionado
            if (treePath != null)
            {
                // Obtiene el Nodo Seleccionado
                nodoSeleccionado = (DefaultMutableTreeNode) treePath
                .getLastPathComponent();

                // Obtiene el Indice        
                index = nodoSeleccionado.getIndex(nodoSeleccionado) + 1;

                // Ejecuta un Dialogo de Entrada y captura respuesta
                String NodeStr = JOptionPane.showInputDialog(this,
                        "Captura el Valor del Nodo", 
                        "Curso de Java sin Ide",
                        JOptionPane.QUESTION_MESSAGE);

                // Obtengo el Nodo e Inserto        
                node = new DefaultMutableTreeNode(NodeStr);
                nodoSeleccionado.insert(node, index);

                // Actualiza el Arbol
                arbolLenguajes.updateUI();
            }
            else
            {
                // Mensaje
                JOptionPane.showMessageDialog(this, "Seleccione un Elemento antes de Agregar");
            }
            
        } 
        else 
        // Verifica el botón de Eliminar
        if (e.getSource() == btnEliminar) 
        {
            // Obtiene el elemento seleccionado
            treePath = arbolLenguajes.getSelectionPath();

            // Verifica
            if (treePath!=null)
            {
                // Ejecuta el Diálogo de Confirmación
                int val = JOptionPane.showConfirmDialog(buttonsPanel,
                "Confirma el Borrado ?");
                    
                // Verifica que dió Aceptar
                if (val == JOptionPane.OK_OPTION) 
                {
                    // Crea un Nodo para el Seleccionado
                    DefaultMutableTreeNode nodoSeleccionado;

                    treePath = arbolLenguajes.getSelectionPath();
                    nodoSeleccionado = (DefaultMutableTreeNode) treePath
                            .getLastPathComponent();
                    if (nodoSeleccionado.isLeaf()) 
                    {
                        // Obtengo el padre
                        nodoTiposLenguaje = (DefaultMutableTreeNode) nodoSeleccionado.getParent();
                        // Elimino el Nodo
                        nodoTiposLenguaje.remove(nodoSeleccionado);
                        // Actualizo el arbol
                        arbolLenguajes.updateUI();
                    } 
                    else 
                    {
                        JOptionPane.showMessageDialog(this, "Unable to Remove");
                    }
                }

            }
            else
            {
                // Mensaje
                JOptionPane.showMessageDialog(this, "Seleccione un Elemento antes de Eliminar");
            }

            
        }
    }

    
    public static void main(String args[]) throws Exception 
    {
        // Crea la ventana
        programa ventana = new programa();
        ventana.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        ventana.setTitle("94 JTree showInputDialog showConfirmDialog");   
        ventana.setSize(400, 400);
        ventana.setVisible(true);     
        ventana.setLocationRelativeTo(null);
    }
}