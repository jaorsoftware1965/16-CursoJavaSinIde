// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 77 swing JComboBox ItemListener
// -------------------------------------------------------

// Librería para swing
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

// Clase se debe llamar igual que el archivo
public class programa extends JFrame implements ItemListener,
                                                ActionListener
{   
    // Creamos los objetos
    private JLabel           lblLenguajes;
    private JTextField       txtLenguaje;
    private JButton          btnInsertar;
    private JButton          btnModificar;
    private JButton          btnEliminar;
    private JButton          btnSeleccionar;
    private JButton          btnContar;
    private JButton          btnEliminarTodos;
    private JComboBox<String>cboLenguajes;
    private int posSelAnterior;
    
    // Constructor
    public programa()
    {
        // Establece el Layout
        setLayout(null);

        // Crea los Objetos
        lblLenguajes = new JLabel("Lenguajes:");
        lblLenguajes.setBounds(10,10,100,30);  
        cboLenguajes = new JComboBox<String>();
        cboLenguajes.setBounds(10,50,200,30);  
        txtLenguaje = new JTextField("");
        txtLenguaje.setBounds(250,50,200,30);  

        btnInsertar = new JButton("Insertar");
        btnInsertar.setBounds(10,100,200,30);  
        btnModificar = new JButton("Modificar");
        btnModificar.setBounds(10,140,200,30);  
        btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(10,180,200,30);  

        btnSeleccionar = new JButton("Seleccionar");
        btnSeleccionar.setBounds(250,100,200,30);  
        btnContar = new JButton("Contar");
        btnContar.setBounds(250,140,200,30);  
        btnEliminarTodos = new JButton("Eliminar Todos");
        btnEliminarTodos.setBounds(250,180,200,30);  

        // Agrega datos al Combo
        cboLenguajes.addItem("C");
        cboLenguajes.addItem("C++");
        cboLenguajes.addItem("C#");
        cboLenguajes.addItem("Java");
        cboLenguajes.addItem("Python");

        // No Selecciona
        cboLenguajes.setSelectedIndex(-1);

        // Eventos
        cboLenguajes.addItemListener(this);  
        btnInsertar.addActionListener(this);
        btnModificar.addActionListener(this);
        btnEliminar.addActionListener(this);
        btnSeleccionar.addActionListener(this);
        btnContar.addActionListener(this);
        btnEliminarTodos.addActionListener(this);
                        
        // Añade los Objetos
        add(lblLenguajes);            
        add(cboLenguajes);            
        add(txtLenguaje);
        add(btnInsertar);
        add(btnModificar);
        add(btnEliminar);
        add(btnSeleccionar);
        add(btnContar);
        add(btnEliminarTodos);

        // Inicializamos anterior
        posSelAnterior=-1;
    }

    // Método para controlar el ComboBox
    public void itemStateChanged(ItemEvent e) 
    {
        // Verifica que sea el combo
        if (e.getSource()==cboLenguajes) 
        {
            // Obtenemos el dato Seleccionado
            String seleccionado=(String)cboLenguajes.getSelectedItem();            
            int    posicion    = cboLenguajes.getSelectedIndex();

            if (posicion!=posSelAnterior)
            {
               JOptionPane.showMessageDialog(this, 
                                             "Seleccionaste:\n" +
                                              seleccionado+"\nEn posicion:\n"+
                                              String.valueOf(posicion),                                               
                                              "Java desde 0 sin Ide", 
                                              JOptionPane.OK_OPTION);            
               // Actualiza Anterior                                              
               posSelAnterior = posicion;                               
            }
        }
    }

    // Método para controlar los Eventos Action de los Objetos
    public void actionPerformed(ActionEvent e) 
    {
        if (e.getSource()==btnInsertar) 
        {
            // Deshabilita el Boton
            btnInsertar.setEnabled(false);

            // Verifica que haya un texto capturado
            String dato = txtLenguaje.getText();

            // Verifica que tenga algo
            if (dato.length()>0)
            {
                // Agrega el Elemento
                cboLenguajes.addItem(dato);

                // Selecciona el dato insertado
                cboLenguajes.setSelectedItem(dato);            
            }
            else
            {
                // Mensaje
                JOptionPane.showMessageDialog(this, 
                                              "Capture texto para Insertar", 
                                              "Java desde 0 sin Ide", 
                                              JOptionPane.OK_OPTION);            
                // Manda el Foco al texto
                txtLenguaje.requestFocus();
            }
            
            // Deshabilita el Boton
            btnInsertar.setEnabled(true);
        }
        else
        // Verificamos que objeto hizo el evento
        if (e.getSource()==btnModificar) 
        {
            // Deshabilita el Boton
            btnModificar.setEnabled(false);

            // Verifica que haya uno Seleccionado
            if (cboLenguajes.getSelectedIndex()>=0)
            {
                // Verifica que haya un texto capturado
                String dato = txtLenguaje.getText();

                // Verifica que tenga algo
                if (dato.length()>0)
                {
                    // Obtengo el Index Seleccionado
                    int seleccionado = cboLenguajes.getSelectedIndex();
                    
                    // Elimino el Elemento
                    cboLenguajes.removeItemAt(seleccionado);

                    // Inserto en esa posición el texto
                    cboLenguajes.insertItemAt(dato, seleccionado);

                    // Selecciono
                    cboLenguajes.setSelectedIndex(seleccionado);

                }
                else
                {
                   // Mensaje
                   JOptionPane.showMessageDialog(this, 
                                                 "Capture texto para modificar el elemento seleccionado", 
                                                 "Java desde 0 sin Ide", 
                                                 JOptionPane.OK_OPTION);            
                    // Manda el Foco al texto
                    txtLenguaje.requestFocus();
                }
            }
            else
               // Mensaje
               JOptionPane.showMessageDialog(this, 
                                             "Seleccione un Elemento a Modificar", 
                                             "Java desde 0 sin Ide", 
                                            JOptionPane.OK_OPTION);            
            
            // Habilita el Boton
            btnModificar.setEnabled(true);            
        }
        else
        if (e.getSource()==btnEliminar) 
        {
            // Deshabilita el Boton
            btnEliminar.setEnabled(false);            

            // Verifica que haya uno Seleccionado
            if (cboLenguajes.getSelectedIndex()>=0)
            {
                // Obtengo el Index Seleccionado
                int seleccionado = cboLenguajes.getSelectedIndex();
                    
                // Elimino el Elemento
                cboLenguajes.removeItemAt(seleccionado);
            }
            else
               // Mensaje
               JOptionPane.showMessageDialog(this, 
                                             "Seleccione un Elemento a Eliminar", 
                                             "Java desde 0 sin Ide", 
                                             JOptionPane.OK_OPTION);            

            // Habilita el Boton
            btnEliminar.setEnabled(true);            
        }

        if (e.getSource()==btnSeleccionar) 
        {
            // Deshabilita el Boton
            btnSeleccionar.setEnabled(false);            

            // Verifica que haya un texto capturado
            String dato = txtLenguaje.getText();

            // Verifica que tenga algo
            if (dato.length()>0)
            {                
                // Guarda el Seleccionado
                int seleccionado = cboLenguajes.getSelectedIndex();

                // DesSelecciona
                cboLenguajes.setSelectedIndex(-1);

                // Intenta Seleccionar el dato
                cboLenguajes.setSelectedItem(dato);            

                // Verifica que haya seleccionado
                if (cboLenguajes.getSelectedIndex()<0)
                {
                    // Mensaje
                    JOptionPane.showMessageDialog(this, 
                                                 "No se encontro el elemento", 
                                                 "Java desde 0 sin Ide", 
                                                 JOptionPane.OK_OPTION);            
                   
                    // Restaura el que estaba seleccionado
                    cboLenguajes.setSelectedIndex(seleccionado);
                }
            }
            else
            {
                // Mensaje
                JOptionPane.showMessageDialog(this, 
                                              "Capture texto para Seleccionar", 
                                              "Java desde 0 sin Ide", 
                                              JOptionPane.OK_OPTION);            
                // Manda el Foco al texto
                txtLenguaje.requestFocus();
            }
            
            // Habilita el Boton
            btnSeleccionar.setEnabled(true);            
        }

        // El Boton de Contar
        if (e.getSource()==btnContar) 
        {
            // Deshabilita el Boton
            btnContar.setEnabled(false);            

            // Verifica que haya un texto capturado
            String elementos = String.valueOf(cboLenguajes.getItemCount());

            // Mensaje
            JOptionPane.showMessageDialog(this, 
                                          "Elmentos:"+elementos, 
                                          "Java desde 0 sin Ide", 
                                          JOptionPane.OK_OPTION);            
                              
            // Habilita el Boton
            btnContar.setEnabled(true);            
        }

        // Eliminar Todos
        if (e.getSource()==btnEliminarTodos) 
        {
            // Deshabilita el Boton
            btnEliminarTodos.setEnabled(false);            

            // Verifica que haya elementos a Eliminar
            if (cboLenguajes.getItemCount()>0)
            {
                // Los elimina
                cboLenguajes.removeAllItems();
            }
            else            
                // Mensaje
                JOptionPane.showMessageDialog(this, 
                                              "No hay elementos a Borrar", 
                                              "Java desde 0 sin Ide", 
                                              JOptionPane.OK_OPTION);            
            
            // Habilita el Boton
            btnEliminarTodos.setEnabled(true);            
        }
    }
                
    // Función main que es obligatorio
    public static void main(String args[])
    {   
        // Crea la Ventana
        programa ventana = new programa();
        ventana.setTitle("Clase 77 - JComboBox ItemListener");
        ventana.setBounds(0,0,480,270);
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);        
        ventana.setLocationRelativeTo(null);
        ventana.setResizable(false);
    }       
}