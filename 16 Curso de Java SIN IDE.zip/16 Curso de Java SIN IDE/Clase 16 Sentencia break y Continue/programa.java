// -----------------------------------
// Curso de Java desde 0 sin IDE
// Clase 16 Sentencia break y continue
// -----------------------------------
 
// Clase se debe llamar igual que el archivo
public class programa
{
  // Función main que es obligatorio
  public static void main(String args[])
  {
    // Variable entera
    int i = 0;

    // Ciclo
    System.out.println("Ciclo 1");   
    while (i < 10) 
    {  
       if (i==3)
          break;     
       System.out.println(i);
       i++;       
    }
    System.out.println("Cuanto vale i al terminar."+i);

    // Dejamos una linea en blanco
    System.out.println();

    System.out.println("Ciclo 2");   
    for (i = 10; i > 0; i++) 
    {
        if (i>=20)
            break;
        System.out.println(i);         
    }
    System.out.println("Cuanto vale i al terminar."+i);

    // Dejamos una linea en blanco
    System.out.println();

    // Ciclo
    System.out.println("Ciclo 3");   
    i = 0;
    while (i < 10) 
    {             
       if (++i==3)
          continue;  
       System.out.println(i);            
    }
    System.out.println("Cuanto vale i al terminar."+i);

    // Dejamos una linea en blanco
    System.out.println();


    System.out.println("Ciclo 4");   
    for (i = 10; i > 0; i++) 
    {
        if (i==20)
            continue;
        else
           if (i>25)    
              break;
        System.out.println(i);         
    }
    System.out.println("Cuanto vale i al terminar."+i);
  }
}