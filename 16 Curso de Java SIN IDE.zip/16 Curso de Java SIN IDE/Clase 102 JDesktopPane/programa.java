// ------------------------------------------------------
// Curso de Java desde 0 sin Ide
// Clase 102 JDesktopPane JInternalFrame
// ------------------------------------------------------

// Librerias
import java.awt.BorderLayout;  
import java.awt.Container;  
import javax.swing.JFrame;  
import javax.swing.JLabel;  

import javax.swing.JDesktopPane;  
import javax.swing.JInternalFrame;

// Clase Principal
public class programa extends JFrame  
{  
    // Constructor
    public programa()   
    {  
        // Crea un panel de la clase CustomDesktopPane
        CustomDesktopPane desktopPane = new CustomDesktopPane();  

        // Creamos un contenedor obtentiendolo del Frame
        Container contentPane = getContentPane();  

        // Añadimos al content pane el deskTop centrado
        contentPane.add(desktopPane, BorderLayout.CENTER);  

        // Desplegamos el deskTop
        desktopPane.display(desktopPane);  

    }  
    public static void  main(String args[])  
    {  
        // Crea la VEntana
        programa ventana =  new programa();  

        // Establece las caracteristicas
        ventana.setTitle("102 JDesktopPane JInternalFrame");  
        ventana.setSize(350,350);  
        ventana.setVisible(true);  
        ventana.setLocationRelativeTo(null);
    }  
}  

// Clase extra para el Panel
class CustomDesktopPane extends JDesktopPane  
{  
    // Propiedades
    int numFrames = 3;
    int xPosicion = 30;
    int yPosicion = 30;  

    // Metodo para desplegar los Desktop
    public void display(CustomDesktopPane panelDesktop)   
    {  
        // Ciclo para crear los panel
        for (int indice = 0; indice < numFrames ; ++indice )   
        {  
            JInternalFrame frameInternal = new JInternalFrame("Internal Frame " + indice+1 ,  
                                                       true, // redimensionable
                                                       true, // cerrable
                                                       true, // maximizable
                                                       true);// iconificable  

            // Establece la posición y tamaño del Internal                                           
            frameInternal.setBounds(xPosicion, yPosicion, 250, 85);  
            
            // Creo un contenedor
            Container contenedor = frameInternal.getContentPane();  

            // Añade una Etiqueta
            contenedor.add(new JLabel("Demo JDesktopPane JInternalFrame"));  

            // Agregamos el frameInternal y se hace visible
            panelDesktop.add( frameInternal );  
            frameInternal.setVisible(true); 
            
            // Actualizamos la Posición
            yPosicion += 85;  
        }  
    }  
}