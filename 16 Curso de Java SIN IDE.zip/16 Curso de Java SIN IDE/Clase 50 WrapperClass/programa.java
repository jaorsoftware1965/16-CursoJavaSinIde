// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 50 Wrapper Class
// -------------------------------------------------------

// Una Wrapper Class provee la forma de manejar los tipos
// de datos primitivos de Java; como objetos.

// ------------------------------------------------------
// Tipo de Dato Primitivo	        Wrapper Class
// ------------------------------------------------------
// byte	                            Byte
// short	                        Short
// int	                            Integer
// long	                            Long
// float	                        Float
// double	                        Double
// boolean	                        Boolean
// char	                            Character

// Métodos de cada objeto
// intValue(), byteValue(), shortValue(), longValue(), 
// floatValue(), doubleValue(), charValue(), booleanValue().

// Invalid
// ArrayList<int> myNumbers = new ArrayList<int>(); 
// Valid
// ArrayList<Integer> myNumbers = new ArrayList<Integer>(); 


// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
       // Despliega
       System.out.println("Clase 50 Wrapper Class");

       // Declaramos variable de Wrapper Class
       Integer   myInt    = 5;
       Double    myDouble = 5.99;
       Character myChar   = 'A';

       // Imprimimos los valores
       System.out.println(myInt);
       System.out.println(myDouble);
       System.out.println(myChar);
       System.out.println("");

       System.out.println(myInt.intValue());
       System.out.println(myDouble.doubleValue());
       System.out.println(myChar.charValue());
       System.out.println("");
       
       System.out.println(myInt.toString());
       System.out.println(myDouble.toString());
       System.out.println(myChar.toString());
       System.out.println("");

       System.out.println(myInt.byteValue());
       System.out.println(myInt.floatValue());
       System.out.println(myInt.longValue());
       System.out.println("");
    }       
}