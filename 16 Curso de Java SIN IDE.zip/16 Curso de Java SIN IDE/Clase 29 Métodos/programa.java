// ---------------------------------
// Curso de Java desde 0 sin IDE
// Clase 29 Métodos o Funciones
// ---------------------------------

// Un Método o Función es un bloque de código
// que se encuentra agrupado bajo un nombre y que
// unicamente se ejecuta cuando es llamado

// Los Métodos se definen dentro de las Clases

// Clase se debe llamar igual que el archivo
public class programa
{
  // Definimos un método dentro de la Clase
  static void fnMensajeHolaMundo()
  {
      // Desplegamos el Mensaje
      System.out.println("Hola Mundo");
  }
  
  // Función main que es obligatorio
  public static void main(String args[])
  {   
      // Mensaje de la Clase 
      System.out.println("Clase 29 Métodos");

      // Llamamos al Método de Main
      fnMensajeHolaMundo();

      // Llamamos al Segundo Método
      fnSalidaDelSistema();
  }

  static void fnSalidaDelSistema()
  {
      // Desplegamos el Mensaje
      System.out.println("Saliendo del Sistema");
  }
  
}