// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 46 Iteradores
// -------------------------------------------------------

// Un iterador es un objeto que nos permite realizar loops
// iterando en cada uno de sus elementos

// Se importa la librería
import java.util.ArrayList;
import java.util.Iterator;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Despliega
        System.out.println("Clase 46 Iteradores");
        
        // Definimos un arreglo de String
        ArrayList<String> personas = new ArrayList<String>(); 

        // agregamos elementos al Arreglo
        personas.add("Juan");
        personas.add("Jose");
        personas.add("Maria");

        // Get the iterator
        Iterator<String> it = personas.iterator();
        
        // Ciclo
        while(it.hasNext())
        {
            // recorre los elementos
            System.out.println(it.next());
        }
        

        // Ciclo para eliminar un elemento
        it = personas.iterator();
        while(it.hasNext())
        {
            // recorre los elementos
            String dato = it.next();
            if (dato == "Maria")
               it.remove();
        }
        
        // Imprime
        System.out.println(personas);                      
    }   
}