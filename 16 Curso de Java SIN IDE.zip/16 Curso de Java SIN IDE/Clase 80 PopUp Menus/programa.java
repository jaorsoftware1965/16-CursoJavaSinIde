// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 80 PopUp Menus setMnemonic
// -------------------------------------------------------

// Librerias
import javax.swing.JFrame;
import javax.swing.JPopupMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;


// Clase Principal
public class programa {
 
    public static void main(String[] args) 
    {
        // Crea un objeto JFrame ya con titulo
        JFrame ventana = new JFrame("80 Popup Menus");
 
        // Construye el popMenu
        JPopupMenu mnuEmergente = new JPopupMenu();
        
        // Creamos el primer Item
        JMenuItem menuItem = new JMenuItem("Abrir ...",
                new ImageIcon("icono.png"));

        // Establecemos un atajo para el Item
        menuItem.setMnemonic(KeyEvent.VK_P);

        // Establecemos Control de Eventos para el Menu        
        menuItem.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                // Mensaje
                JOptionPane.showMessageDialog(ventana, "Abrir clicked");
            }
        });

        // Añade el Item al Menu Emergente
        mnuEmergente.add(menuItem);

        // Crea un nuevo item con el mismo objeto
        menuItem = new JMenuItem("Nuevo ...",
                   new ImageIcon("icono.png"));
        
        // Establece el Atajo
        menuItem.setMnemonic(KeyEvent.VK_F);

        // Establece el Evento
        menuItem.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                JOptionPane.showMessageDialog(ventana, "Nuevo clicked");
            }
        });

        // Añade el Item al Menu
        mnuEmergente.add(menuItem);
        
        // Si deshabilito lo hago con el Segundo
        //menuItem.setEnabled(false);
 
        // Controlo el Evento para el Frame
        ventana.addMouseListener(new MouseAdapter() 
        {  
            @Override
            public void mouseReleased(MouseEvent e) 
            {
                if (e.isPopupTrigger()) 
                {
                    // Muestra el Menu en donde se hace click
                    mnuEmergente.show(e.getComponent(),
                                      e.getX(), 
                                      e.getY());
                }          
            }
        });
 
        // Establece las caracteristicas de la Ventana
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setSize(300, 200);
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);
 
    }
}