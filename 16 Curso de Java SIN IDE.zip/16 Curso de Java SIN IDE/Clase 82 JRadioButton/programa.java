// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 82 swing JRadioButton ButtonGroup
// -------------------------------------------------------

// Librerias
import javax.swing.JFrame;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.Color;


// Clase Principal
public class programa extends JFrame implements ChangeListener
{
    // Objetos de la Clase
    private JRadioButton rb640x480;
    private JRadioButton rb800x600;
    private JRadioButton rb1024x768;    
    private JRadioButton rbRojo;
    private JRadioButton rbVerde;
    private JRadioButton rbAzul;    
    private ButtonGroup  bgDimensiones;
    private ButtonGroup  bgColor;
    
    // Constructor
    public programa()
    {
        // Establece el Layout
        setLayout(null);

        // Crea un ButtonGroup
        bgDimensiones = new ButtonGroup();

        // Crea los Radio Button para las Dimensiones
        rb640x480=new JRadioButton("640*480");
        rb640x480.setBounds(10,20,100,30);        

        rb800x600=new JRadioButton("800*600");
        rb800x600.setBounds(10,70,100,30);

        rb1024x768=new JRadioButton("640*480");
        rb1024x768.setBounds(10,120,100,30);
        
        // Agrega al ButtonGroup los RadioButton
        bgDimensiones.add(rb640x480);
        bgDimensiones.add(rb800x600);
        bgDimensiones.add(rb1024x768);

        // Crea un ButtonGroup
        bgColor = new ButtonGroup();

        // Crea los Radio Button para las Dimensiones
        rbRojo=new JRadioButton("Rojo");
        rbRojo.setBounds(200,20,100,30);

        rbVerde=new JRadioButton("Verde");
        rbVerde.setBounds(200,70,100,30);

        rbAzul=new JRadioButton("Azul");
        rbAzul.setBounds(200,120,100,30);
        
        // Agrega al ButtonGroup los RadioButton
        bgColor.add(rbRojo);
        bgColor.add(rbVerde);
        bgColor.add(rbAzul);

        // Agrega al frame el ButtonGroup
        add(rb640x480);
        add(rb800x600);
        add(rb1024x768);
        add(rbRojo);
        add(rbVerde);
        add(rbAzul);

        // Eventos
        rb640x480.addChangeListener(this);        
        rb800x600.addChangeListener(this);        
        rb1024x768.addChangeListener(this);

        rbRojo.addChangeListener(this);        
        rbVerde.addChangeListener(this);        
        rbAzul.addChangeListener(this);
    }

    public void stateChanged(ChangeEvent e)
    {
        // Verifica
        if (rb640x480.isSelected())
        {
            // Dimensiona
            setSize(640,480);
            // Centra
            setLocationRelativeTo(null);
        }
        else
        if (rb800x600.isSelected())
        {
            // Dimensiona
            setSize(800,600);    
            // Centra
            setLocationRelativeTo(null);
        }
        else
        if (rb1024x768.isSelected())
        {
            // Dimensiona
            setSize(1024,768);    
            // Centra
            setLocationRelativeTo(null);
        }

        // Verifica el Color
        if (rbRojo.isSelected())
            // Establece el Color                     R  G B
            getContentPane().setBackground(new Color(255,0,0));
        else
        if (rbVerde.isSelected())
            // Establece el Color                     R  G B
            getContentPane().setBackground(new Color(0,255,0));
        else    
        if (rbAzul.isSelected())
            // Establece el Color                     R  G B
            getContentPane().setBackground(new Color(0,0,255));        
    }

    public static void main(String[] args) 
    {
        // Crea un objeto JFrame ya con titulo
        programa ventana = new programa();

        // Establece las caracteristicas de la Ventana
        ventana.setTitle("82 JRadioButton ButtonGroup");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setSize(350, 200);
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null); 
    }
}