// ------------------------------------------------
// Curso de Java desde 0 sin Ide
// Clase 96 JSpinner BorderFactory.createEmptyBorder
// ------------------------------------------------

// Librerías
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeListener;  
import javax.swing.event.ChangeEvent;  
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.border.EtchedBorder;
import java.awt.Color;

// La Clase Principal
public class programa extends JFrame
{  
    // Propiedades
    JLabel   lblRed;
    JLabel   lblGreen;
    JLabel   lblBlue;
    JSpinner spnRed;
    JSpinner spnGreen;
    JSpinner spnBlue;
    SpinnerModel valRed;
    SpinnerModel valGreen;
    SpinnerModel valBlue;

    // Constructor
    public programa()
    {
        // Establece el Layout del Frame
        setLayout(new GridLayout(3,2));       

        // Crea las Etiquetas
        lblRed   = new JLabel("Rojo");                    
        lblRed.setHorizontalAlignment(JLabel.RIGHT);    
        lblRed.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        lblGreen = new JLabel("Verde");                 
        lblGreen.setHorizontalAlignment(JLabel.RIGHT);       
        lblGreen.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        lblBlue  = new JLabel("Azul");                  
        lblBlue.setHorizontalAlignment(JLabel.RIGHT);      
        lblBlue.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
                
        // Modelo para Controlar el Spinner
        valRed = new SpinnerNumberModel(  0,  //initial value  
                                          0,  //minimum value  
                                        255,  //maximum value  
                                          1); //step  

        valGreen = new SpinnerNumberModel( 0,  //initial value  
                                           0,  //minimum value  
                                         255,  //maximum value  
                                           1); //step  

        valBlue = new SpinnerNumberModel( 0,  //initial value  
                                          0,  //minimum value  
                                        255,  //maximum value  
                                          1); //step                                    
        
        // Crea los Spinner
        spnRed   = new JSpinner(valRed);   
        spnRed.setBorder(new EtchedBorder());

        spnGreen = new JSpinner(valGreen);   
        spnGreen.setBorder(new EtchedBorder());

        spnBlue  = new JSpinner(valBlue);   
        spnBlue.setBorder(new EtchedBorder());                

        // Agregamos las Etiquetas y Spinner's al Frame
        add(lblRed);
        add(spnRed);  
        add(lblGreen);
        add(spnGreen);  
        add(lblBlue);
        add(spnBlue);  
        
        // Obtiene el Color
        Color color = getBackground();

        // Obtiene los colores por separado
        int rojo  = color.getRed();
        int verde = color.getGreen();
        int azul  = color.getBlue();

        // Coloca los valores en spinner
        spnRed.setValue(rojo);
        spnGreen.setValue(verde);
        spnBlue.setValue(azul);

        // Captura el Evento del Spinner
        spnRed.addChangeListener(new ChangeListener() 
        {  
            // Evento que se dispara en el Spinner
            public void stateChanged(ChangeEvent e) 
            {  
                 // Variables para los colores
                 int rojo;
                 int verde;
                 int azul;

                 // Obtiene el Color
                 rojo  = Integer.valueOf(spnRed.getValue().toString());
                 verde = Integer.valueOf(spnGreen.getValue().toString());
                 azul  = Integer.valueOf(spnBlue.getValue().toString());

                 // Cambia el Color
                 getContentPane().setBackground(new Color(rojo,verde,azul));
            }  
        });  

        spnGreen.addChangeListener(new ChangeListener() 
        {  
            // Evento que se dispara en el Spinner
            public void stateChanged(ChangeEvent e) 
            {  
                 // Variables para los colores
                 int rojo;
                 int verde;
                 int azul;

                 // Obtiene el Color
                 rojo  = Integer.valueOf(spnRed.getValue().toString());
                 verde = Integer.valueOf(spnGreen.getValue().toString());
                 azul  = Integer.valueOf(spnBlue.getValue().toString());

                 // Cambia el Color
                 getContentPane().setBackground(new Color(rojo,verde,azul));
            }  
        });  

        // Evento que se dispara en el Spinner
        spnBlue.addChangeListener(new ChangeListener() 
        {  
            public void stateChanged(ChangeEvent e) 
            {  
                // Variables para el Color
                int rojo;
                int verde;
                int azul;

                // Obtien el Color
                rojo  = Integer.valueOf(spnRed.getValue().toString());
                verde = Integer.valueOf(spnGreen.getValue().toString());
                azul  = Integer.valueOf(spnBlue.getValue().toString());

                 // Cambia el Color
                 getContentPane().setBackground(new Color(rojo,verde,azul));
            }  
        });  

        // Ajusta
        pack();

    }
    public static void main(String[] args) 
    {    
       // Crea la Ventana y Establece sus características 
       programa ventana = new programa();    
       ventana.setTitle("96 JSpinner");
       ventana.setSize(300,150);
       ventana.setLocationRelativeTo(null);
       ventana.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
       ventana.setVisible(true);       
    }  
}

