// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 74 swing KeyListener KeyEvent Override consume
// -------------------------------------------------------

// Librería para swing
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

// Clase se debe llamar igual que el archivo
public class programa extends JFrame implements ActionListener,
                                                KeyListener
{   
    // Creamos los objetos
    private JTextField     txtUsuario;
    private JPasswordField txtClave;
    private JLabel         lblUsuario;
    private JLabel         lblClave;
    private JButton        btnAceptar;
    private JButton        btnCancelar;

    // Constructor
    public programa()
    {
        // Establece el Layout
        setLayout(null);

        // Crea los Objetos
        lblUsuario = new JLabel("Usuario:");
        lblUsuario.setBounds(20,10,100,30);
        lblClave   = new JLabel("Clave:");
        lblClave.setBounds(20,50,100,30);

        txtUsuario = new JTextField();
        txtUsuario.setBounds(200,10,100,20);
        txtClave   = new JPasswordField();
        txtClave.setBounds(200,50,100,20);
        
        btnAceptar = new JButton("Aceptar");
        btnAceptar.setBounds(20,100,100,30);
        btnCancelar = new JButton("Cancelar");
        btnCancelar.setBounds(200,100,100,30);

        // Añade los Objetos
        add(lblUsuario);    
        add(lblClave);    
        add(txtUsuario);    
        add(txtClave);                
        add(btnAceptar);
        add(btnCancelar);

        // Eventos
        btnAceptar.addActionListener(this);  
        btnCancelar.addActionListener(this); 
        txtUsuario.addActionListener(this); 
        txtClave.addActionListener(this); 

        // Eventos para los JText
        txtUsuario.addKeyListener(this);
        txtClave.addKeyListener(this);

    }

    public void actionPerformed(ActionEvent e) 
    {
        if (e.getSource()==btnAceptar) 
        {
            // Obtiene los datos de Usuario y Clave
            String sUsuario=txtUsuario.getText();
            String sClave = String.valueOf(txtClave.getPassword());
            
            // Despliega el Mensaje
            JOptionPane.showMessageDialog(this, 
                                          "Los Datos Capturados son:\n" +
                                          "Usuario:"+sUsuario+"\n"+
                                          "Clave:"+sClave, 
                                          "Java desde 0 sin Ide", 
                                          JOptionPane.OK_OPTION);            
            
        }
        else
        if (e.getSource()==btnCancelar) 
        {
            // Finaliza la Ventana
            this.dispose();
        }
        else
        if (e.getSource()==txtUsuario) 
        {
            // Pasa el Control del Foco a la Clave
            txtClave.requestFocus();
        }
        else
        if (e.getSource()==txtClave) 
        {
            // Pasa el Control del Foco a la Clave
            btnAceptar.requestFocus();
        }


    }

    // Implementando los métodos obligatorios de KeyListener
    @Override
    public void keyPressed(KeyEvent e) 
    {
        // Despliega el Mensaje
        System.out.println("KeyPressed:"+e.getKeyCode());            
        //e.consume();//No Funciona
    }
 
    public void keyReleased(KeyEvent e) 
    {
        System.out.println("KeyReleased:"+e.getKeyCode());            
        //e.consume();//No Funciona
    }
 
    public void keyTyped(KeyEvent e) 
    {
        System.out.println("KeyTyped:"+e.getKeyCode()+"-"+e.getKeyChar());            
        //e.consume();// Aca es donde funciona
        
        // Verifica que sea el usuario
        if (e.getSource()==txtUsuario)
        {
            // Valida la longitud
            if (txtUsuario.getText().length()>=10)
            {
                // Consume
                e.consume();

                // Recorta
                String dato = txtUsuario.getText().substring(0,10);
                txtUsuario.setText(dato);                
            }
        }
        
        if (e.getSource()==txtClave)
        {   
            // Obtiene el dato    
            String dato = String.valueOf(txtClave.getPassword());

            // Valida la longitud
            if (dato.length()>=5)
            {
                // Consume
                e.consume();     
                
                // Recorta
                dato = txtUsuario.getText().substring(0,5);
                txtClave.setText(dato);
            }
        }
    }

                
    // Función main que es obligatorio
    public static void main(String args[])
    {   
        // Crea la Ventana
        programa ventana = new programa();
        ventana.setTitle("Clase 74 - KeyListener KeyEvent Override");
        ventana.setBounds(0,0,340,180);
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);        
        ventana.setLocationRelativeTo(null);
        ventana.setResizable(false);
    }       
}