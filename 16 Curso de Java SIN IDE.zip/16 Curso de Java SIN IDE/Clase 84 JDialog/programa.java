// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 84 swing JDialog
// -------------------------------------------------------

// Librerias
import javax.swing.JDialog;
import javax.swing.JLabel;

// Clase Principal
public class programa extends JDialog
{
    // Objetos de la Clase
    private JLabel lblHolaMundo;
        
    // Constructor
    public programa()
    {
        // Establece el Layout
        setLayout(null);

        // Crea la Etiqueta
        lblHolaMundo = new JLabel("Hola Mundo");
        lblHolaMundo.setBounds(10, 10, 100, 30);

        // Agrega el Label al Dialogo
        add(lblHolaMundo);    
    }


    public static void main(String[] args) 
    {
        // Crea un objeto JFrame ya con titulo
        programa dialogo = new programa();

        // Establece las caracteristicas de la Ventana
        dialogo.setTitle("90 JDialog");
        dialogo.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialogo.setSize(600, 400);
        dialogo.setVisible(true);
        dialogo.setLocationRelativeTo(null); 
    }
}