// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 84 swing JDialog 2
// -------------------------------------------------------

// Librerias
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JDialog;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


// Clase Principal
public class programa2 extends JFrame implements ActionListener
{
    // Objetos de la Clase
    private JButton btnAbrirDialogo;
    private JDialog dlgModal;
        
    // Constructor
    public programa2()
    {
        // Establece el Layout
        setLayout(null);

        // Crea el Boton
        btnAbrirDialogo = new JButton("Abrir Dialogo");
        btnAbrirDialogo.setBounds(10, 10, 150, 30);

        // Eventos
        btnAbrirDialogo.addActionListener(this);

        // Agrega el Label al Dialogo
        add(btnAbrirDialogo);    
    }

    // Método para controlar el click
    public void actionPerformed(ActionEvent e)
    {        
        // Verifica si es el botón de abrir
        if (e.getSource()==btnAbrirDialogo)
        {
           // Crea el Dialogo
           dlgModal = new JDialog(this,"Dialogo Modal",false);

           // Caracteristicas del Dialogo
           dlgModal.setBounds(10,10,200,200);
           dlgModal.setLocationRelativeTo(this);
           
           // Lo Despliega al hacerlo Visible
           dlgModal.setVisible(true); 
           dlgModal.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        }
    }


    public static void main(String[] args) 
    {
        // Crea un objeto JFrame ya con titulo
        programa2 dialogo = new programa2();

        // Establece las caracteristicas de la Ventana
        dialogo.setTitle("84 JDialog 2");
        dialogo.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialogo.setSize(600, 400);
        dialogo.setVisible(true);
        dialogo.setLocationRelativeTo(null); 
    }
}