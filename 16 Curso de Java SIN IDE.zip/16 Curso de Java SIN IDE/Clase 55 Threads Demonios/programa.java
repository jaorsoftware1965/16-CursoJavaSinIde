// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 55 Threads Demonios
// -------------------------------------------------------

// Un Thread Daemon es un hilo que finaliza junto con su
// proceso padre
// Se debe establecer que un Thread es un Demonio antes
// de iniciarlo

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
       // Despliega
       System.out.println("Clase 55 Threads Demonios");
       
       // Creando un thread de la tabla del 5
       Contador contador = new Contador();

       // Establezco que es un Demonio
       contador.setDaemon(true);
       // Lo inicio
       contador.start();       
       System.out.println("Id:"+contador.getId()+" Name:"+contador.getName());
       
       // Cuenta segundos
       int iCuentaSegundos=0;

       // Monitoreando
       while (iCuentaSegundos < 5)
       {                       
           // Incrementa el Contador de Segundos
           iCuentaSegundos++;

           try
           {
              //Espera 1 segundos
              Thread.sleep(1000);
           }

           catch (Exception e) 
           {
              System.out.println("Error Inesperado:"+e.getMessage());           
           }           
       }

       // El programa finalizara
       System.out.println("Programa Terminado");
    }       
}