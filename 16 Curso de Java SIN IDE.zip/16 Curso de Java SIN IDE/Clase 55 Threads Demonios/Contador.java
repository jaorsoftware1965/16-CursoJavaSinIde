// -------------------------------------------------------
// Clase Contador
// -------------------------------------------------------

// Clase se debe llamar igual que el archivo
public class Contador extends Thread
{   
    // Propiedades para controlar el Thread
    private int     contador = 0;
    private boolean activo   = true;
    private boolean pausado  = false;
    
    public void run() 
    {
        // Verifica que esté activo
        while (activo)
        {       
            // Verifica que no esté pausado
            if (!pausado)     
            {
               contador++; 
               System.out.println("Contador:"+contador);
            }
            else   
               System.out.println("Pausado:"+contador);     

            try
            {
                //Espera 1 segundos
                sleep(1000);
            }
            catch (Exception e) 
            {
                System.out.println("Error Inesperado:"+e.getMessage());           
            }             
                                    
            // Verifica si es 20
            if (contador == 20)
            {
               // Finalizamos
               activo = false;
               contador = 0;
            }
        }
        System.out.println("El Contador ha finalizado:"+ contador);           
    }

    public void detener()
    {
        // Verifica que esté activo
        if (activo)
        {
           System.out.println("Contador detenido:"+contador);
           activo = false;
        }
    }

    public void pausar()
    {
        // Verifica que esté pausado
        if (!pausado)
        {
            System.out.println("Contador Pausado:"+contador);
            pausado = true;
        }
    }

    public void reanudar()
    {
        // Verifica que esta pausado
        if (pausado)
        {
            System.out.println("Contador reanudado:"+contador);
            pausado = false;
        }
    }
}