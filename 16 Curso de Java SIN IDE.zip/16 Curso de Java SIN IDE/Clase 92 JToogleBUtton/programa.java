// --------------------------------------
// Curso de Java desde 0 sin IDE
// 92 JToogleButton
// --------------------------------------

// Libreria
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JToggleButton;


// Clase Principal
public class programa extends JFrame
{
        // Propiedades
        JToggleButton toggleButton;
        JLabel        lblMensaje;

        // Constructor
	public programa() 
        {		
            // Crea el toggleButton    
	    JToggleButton tbBoton = new JToggleButton("Boton Toggle");
	    tbBoton.setBounds(0, 0, 300, 30);
		
	    JLabel lblMensaje = new JLabel("");
	    lblMensaje.setHorizontalAlignment(JLabel.CENTER);
	    lblMensaje.setBounds(0, 30, 300, 30);
		
            // Controla el Evento
	    tbBoton.addItemListener(new ItemListener() 
            {	
	        @Override
	        public void itemStateChanged(ItemEvent itemEvent) 
                {
		    int estado = itemEvent.getStateChange();
		    if (estado == ItemEvent.SELECTED)
                    {
			lblMensaje.setText("Boton seleccionado");
		    } 
                    else 
                    {
			lblMensaje.setText("Boton deseleccionado");
		    }
		}
	    });

            // Agrega los objetos
            add(tbBoton);
            add(lblMensaje);
		
		
	}

	public static void main(String[] args) 
        {
            // Esablecer las Caracteristicas de la Ventana
            programa ventana = new programa(); 
            ventana.setTitle("92 JToggleBUtton");
	    ventana.setLayout(null);
	    ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    ventana.setVisible(true);
	    ventana.setSize(300, 100);
            ventana.setVisible(true);
            ventana.setLocationRelativeTo(null);	
	}

}

