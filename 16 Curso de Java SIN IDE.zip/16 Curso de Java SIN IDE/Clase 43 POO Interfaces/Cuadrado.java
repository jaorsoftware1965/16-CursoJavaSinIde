// --------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase Cuadrado
// --------------------------------------------------

// Defino la clase abstracta
public class Cuadrado implements Figura
{
    // Propiedad Color Privada
    private double lado;

    // Constructor
    public Cuadrado(double lado)
    {
        // Asigna el lado
        this.lado = lado;
    }

    // Obtiene el Color
    public String getColor()
    {
        // Devuelve el Color
        return color;
    }

    // Define el metodo abstracto 
    public double calcularArea()
    {
        return lado * lado;
    }

    // Define el Metodo Abstracto que calcular el perimetro
    public double calcularPerimetro()
    {
        // retorna el perimetro
        return lado * 4;
    }
    
}