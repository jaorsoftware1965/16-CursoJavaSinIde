// --------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase Circulo
// --------------------------------------------------

// Defino la clase que implementa
public class Circulo implements Figura
{
    // Propiedad Color Privada
    private double radio;

    // Constructor
    public Circulo(double radio)
    {
        // Base y altura
        this.radio = radio;
    }

    // Obtiene el Color
    public String getColor()
    {
        // Devuelve el Color
        return color;
    }

    // Define el Metodo de la Interfaz
    public double calcularArea()
    {
         // Calcula el area y lo devuelve
         return (3.1416 * (radio*radio));
    }

    // Define el Método de la interfaz
    public double calcularPerimetro()
    {
         // Calcula el area y lo devuelve
         return (3.1416 * (radio * 2));
    }
}