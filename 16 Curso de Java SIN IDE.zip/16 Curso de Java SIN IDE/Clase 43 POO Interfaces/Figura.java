// --------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase Figura
// --------------------------------------------------

// Defino la Interfase
public interface Figura
{    
    // Todos los atributos son Public, static y final 
    public static String color = "blue";

    // No puede tener Constructor
    //public Figura(String color)
    //{
    //    // Asigna el Color
    //    this.color = color;
    //}

    // Obtiene el Color
    public abstract String getColor();
    
    // Define el Metodo Abstracto que calcular el area
    public double calcularArea();

    // Define el Metodo Abstracto que calcular el perimetro
    double calcularPerimetro();
}