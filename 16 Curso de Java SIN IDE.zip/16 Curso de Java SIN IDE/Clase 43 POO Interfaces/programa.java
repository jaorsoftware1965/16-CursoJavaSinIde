// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 43 POO Interfaces
// -------------------------------------------------------

// Son un Tipo de Clase Abstracta que no tiene constructor
// y donde todos sus metodos son abstractos, sin tener que 
// especificarlos como tal

// Las interfaces no se heredan; se implementan

// Todos los metodos son public abstract
// Todas las propiedades son public, static, final


// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // No podemos crear objeto de Figura
        Figura x;

        // creamos un objeto del Cuadrado
        Cuadrado cuadrado = new Cuadrado(2.5);
        System.out.printf("El Color     del Cuadrado es: %s\n", cuadrado.getColor());
        System.out.printf("El Area      del Cuadrado es: %f\n", cuadrado.calcularArea());
        System.out.printf("El Perimetro del Cuadrado es: %f\n\n", cuadrado.calcularPerimetro());

        // creamos un objeto del Circulo
        Circulo circulo = new Circulo(3);
        System.out.printf("El Color del Circulo es: %s\n", circulo.getColor());
        System.out.printf("El Area  del Circulo es: %f\n", circulo.calcularArea());    
        System.out.printf("El Perimetro del Circulo es: %f\n", circulo.calcularPerimetro());    

        // Accediendo al color desde la Clase Figura
        System.out.printf(Figura.color + "\n");    
        System.out.printf(circulo.color + "\n");    
        System.out.printf(x.color + "\n");    
    }   
}