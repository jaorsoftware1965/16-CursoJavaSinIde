// -------------------------------------------------------
// Curso de Java desde 0 sin IDE
// Clase 81 swing JCheckBox ChangeEvent ChangeListener
// -------------------------------------------------------

// Librerias
import javax.swing.JFrame;
import javax.swing.JCheckBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;



// Clase Principal
public class programa extends JFrame implements ChangeListener
{
    // Objetos de la Clase
    private JTextField txtTexto;
    private JButton    btnAceptar;
    private JCheckBox  chkTexto;
    private JCheckBox  chkBoton;

    // Constructor
    public programa()
    {
        // Establece el Layout
        setLayout(null);

        // Crea el TextField
        txtTexto = new JTextField("");
        txtTexto.setBounds(10, 10, 150, 30);

        // Crea el Boton
        btnAceptar = new JButton("Aceptar");
        btnAceptar.setBounds(10, 50, 150, 30);
        btnAceptar.setEnabled(false);

        // Crea los CheckBox
        chkTexto = new JCheckBox("Habilitar Texto");
        chkTexto.setBounds(250,10,150,30);
        chkTexto.setSelected(true);
        
        chkBoton = new JCheckBox("Habilitar Boton");
        chkBoton.setBounds(250,50,150,30);
       
        // Añade los objetos al Frame
        add(txtTexto);
        add(btnAceptar);
        add(chkTexto);
        add(chkBoton);

        // Eventos
        chkBoton.addChangeListener(this);
        chkTexto.addChangeListener(this);
        
    }

    public void stateChanged(ChangeEvent e)
    {
        // Establece el estado del Texto y
        txtTexto.setEnabled((chkTexto.isSelected()));
        btnAceptar.setEnabled((chkBoton.isSelected()));        
    }

    public static void main(String[] args) 
    {
        // Crea un objeto JFrame ya con titulo
        programa ventana = new programa();

        // Establece las caracteristicas de la Ventana
        ventana.setTitle("81 JCheckBox ChangeListener");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setSize(400, 130);
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null); 
    }
}