// ------------------------------------------------------
// Curso de Java desde 0 sin Ide
// Clase 100 JLayeredPane
// ------------------------------------------------------

// Librerias
import javax.swing.JLayeredPane;  
import javax.swing.JButton;  
import javax.swing.JFrame;  
import java.awt.Color;  

// Se extiende de Frame
public class programa extends JFrame 
{  
    public programa() 
    {          
        // Se crea el Panel 
        JLayeredPane pane = getLayeredPane();  

        //creating buttons  
        JButton top = new JButton();  
        top.setBackground(Color.white);  
        top.setBounds(20, 20, 50, 50);  
        
        // Medio
        JButton middle = new JButton();  
        middle.setBackground(Color.red);  
        middle.setBounds(40, 40, 50, 50);  

        // Fondo
        JButton bottom = new JButton();  
        bottom.setBackground(Color.cyan);  
        bottom.setBounds(60, 60, 50, 50);  

        //Se añaden los objetos al Panel
        // pane.add(bottom, new Integer(1));  
        // pane.add(middle, new Integer(2));  
        // pane.add(top,    new Integer(3)); 

        // Integer uno = 1;
        // Integer dos = 2;
        // Integer tres = 3;
        // pane.add(bottom, uno);  
        // pane.add(middle, dos);  
        // pane.add(top   , tres);  
        pane.add(bottom, 1);  
        pane.add(middle, 2);  
        pane.add(top   , 3);  
    }  
    public static void main(String[] args) 
    {  
        // Crea la Ventana
        programa ventana = new  programa();  
        ventana.setTitle("100 JLayeredPane");
        ventana.setSize(300, 300);  
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);  
    }  
}  